

import { Language, Badge, SocialPost, LeaderboardEntry } from './types';

export const DIETARY_OPTIONS = ['Vegetarian', 'Vegan', 'Gluten-Free', 'Dairy-Free', 'Nut-Free', 'Low-Carb', 'Keto', 'Paleo', 'Halal', 'Kosher', 'Pescatarian', 'Whole30', 'FODMAP'];
export const CUISINE_OPTIONS = ['Italian', 'Mexican', 'Indian', 'Chinese', 'Japanese', 'French', 'American', 'Thai', 'Spanish', 'Turkish', 'German', 'Russian', 'Middle Eastern', 'Greek', 'Korean', 'Vietnamese', 'Brazilian', 'Caribbean', 'African', 'Mediterranean'];
export const TIME_OPTIONS = ['Under 15 min', 'Under 30 min', 'Under 1 hour', 'Over 1 hour'];
export const DIFFICULTY_OPTIONS = ['Easy', 'Medium', 'Hard'];

export const LANGUAGES: { code: string; label: string; flag: string }[] = [
  { code: 'en', label: 'English', flag: '🇺🇸' },
  { code: 'tr', label: 'Türkçe', flag: '🇹🇷' },
  { code: 'ar', label: 'العربية', flag: '🇸🇦' },
  { code: 'zh', label: '中文 (Chinese)', flag: '🇨🇳' },
  { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
  { code: 'ru', label: 'Русский', flag: '🇷🇺' },
  { code: 'es', label: 'Español', flag: '🇪🇸' },
  { code: 'fr', label: 'Français', flag: '🇫🇷' },
  { code: 'it', label: 'Italiano', flag: '🇮🇹' },
  { code: 'ja', label: '日本語 (Japanese)', flag: '🇯🇵' },
  { code: 'pt', label: 'Português', flag: '🇵🇹' },
  { code: 'hi', label: 'हिन्दी (Hindi)', flag: '🇮🇳' },
  { code: 'ko', label: '한국어 (Korean)', flag: '🇰🇷' },
];

export const BADGES: Badge[] = [
    // Cooking Basics
    { id: 'b1', name: 'First Flame', description: 'Cooked your first meal', icon: 'local_fire_department', requirement: '1 Meal', xpReward: 50, category: 'cooking' },
    { id: 'b2', name: 'Sous Chef', description: 'Cooked 10 meals', icon: 'restaurant_menu', requirement: '10 Meals', xpReward: 200, category: 'cooking' },
    { id: 'b3', name: 'Kitchen Master', description: 'Cooked 50 meals', icon: 'military_tech', requirement: '50 Meals', xpReward: 1000, category: 'cooking' },
    { id: 'b4', name: 'Iron Chef', description: 'Cooked 100 meals', icon: 'workspace_premium', requirement: '100 Meals', xpReward: 5000, category: 'cooking' },
    
    // Times of Day
    { id: 'b5', name: 'Early Bird', description: 'Cooked breakfast 5 times', icon: 'wb_sunny', requirement: '5 Breakfasts', xpReward: 100, category: 'cooking' },
    { id: 'b6', name: 'Lunch Break', description: 'Cooked lunch 5 times', icon: 'wb_twilight', requirement: '5 Lunches', xpReward: 100, category: 'cooking' },
    { id: 'b7', name: 'Night Owl', description: 'Cooked dinner after 9PM', icon: 'bedtime', requirement: 'Late Dinner', xpReward: 150, category: 'cooking' },

    // Cuisines
    { id: 'b8', name: 'Global Taster', description: 'Tried 5 different cuisines', icon: 'public', requirement: '5 Cuisines', xpReward: 300, category: 'collection' },
    { id: 'b9', name: 'Pasta Pro', description: 'Cooked 5 Italian dishes', icon: 'restaurant', requirement: '5 Italian', xpReward: 250, category: 'cooking' },
    { id: 'b10', name: 'Spice Master', description: 'Cooked 5 Indian dishes', icon: 'local_dining', requirement: '5 Indian', xpReward: 250, category: 'cooking' },
    { id: 'b11', name: 'Wok Star', description: 'Cooked 5 Chinese dishes', icon: 'rice_bowl', requirement: '5 Chinese', xpReward: 250, category: 'cooking' },
    { id: 'b12', name: 'Taco Titan', description: 'Cooked 5 Mexican dishes', icon: 'tapas', requirement: '5 Mexican', xpReward: 250, category: 'cooking' },

    // Sustainability
    { id: 'b13', name: 'Waste Warrior', description: 'Saved 5kg of food waste', icon: 'recycling', requirement: '5kg Saved', xpReward: 500, category: 'sustainability' },
    { id: 'b14', name: 'Fridge Cleaner', description: 'Used 10 items nearing expiry', icon: 'inventory', requirement: '10 Saved Items', xpReward: 300, category: 'sustainability' },
    { id: 'b15', name: 'Eco Hero', description: 'Maintained a 0-waste week', icon: 'eco', requirement: '0 Waste Week', xpReward: 1000, category: 'sustainability' },

    // Social
    { id: 'b16', name: 'Social Butterfly', description: 'Shared 5 recipes', icon: 'share', requirement: '5 Shares', xpReward: 150, category: 'social' },
    { id: 'b17', name: 'Trendsetter', description: 'Got 50 likes on a post', icon: 'favorite', requirement: '50 Likes', xpReward: 500, category: 'social' },
    { id: 'b18', name: 'Community Pillar', description: 'Commented on 20 posts', icon: 'forum', requirement: '20 Comments', xpReward: 300, category: 'social' },
    { id: 'b19', name: 'Influencer', description: 'Gained 10 followers', icon: 'group_add', requirement: '10 Followers', xpReward: 1000, category: 'social' },

    // Health
    { id: 'b20', name: 'Health Nut', description: 'Cooked 5 healthy meals', icon: 'monitor_heart', requirement: '5 Healthy', xpReward: 250, category: 'cooking' },
    { id: 'b21', name: 'Protein Packer', description: 'Ate high protein for 3 days', icon: 'fitness_center', requirement: 'High Protein', xpReward: 300, category: 'cooking' },
    { id: 'b22', name: 'Green Giant', description: 'Cooked 5 Vegan meals', icon: 'grass', requirement: '5 Vegan', xpReward: 300, category: 'cooking' },

    // Techniques
    { id: 'b23', name: 'Slow & Steady', description: 'Cooked a recipe > 2 hours', icon: 'hourglass_bottom', requirement: 'Long Cook', xpReward: 400, category: 'cooking' },
    { id: 'b24', name: 'Speed Demon', description: 'Cooked a recipe < 15 mins', icon: 'timer', requirement: 'Fast Cook', xpReward: 150, category: 'cooking' },
    { id: 'b25', name: 'Baker', description: 'Baked 5 items', icon: 'cake', requirement: '5 Bakes', xpReward: 300, category: 'cooking' },
    
    // Streaks
    { id: 'b26', name: 'Weekender', description: 'Cooked Sat & Sun for 4 weeks', icon: 'calendar_view_week', requirement: '4 Weekends', xpReward: 500, category: 'cooking' },
    { id: 'b27', name: 'Daily Grinder', description: '7 day cooking streak', icon: 'local_fire_department', requirement: '7 Day Streak', xpReward: 1000, category: 'cooking' },
    { id: 'b28', name: 'Monthly Master', description: '30 day cooking streak', icon: 'event_available', requirement: '30 Day Streak', xpReward: 5000, category: 'cooking' },

    // Fun
    { id: 'b29', name: 'Experimental', description: 'Created a custom recipe', icon: 'science', requirement: '1 Custom', xpReward: 200, category: 'collection' },
    { id: 'b30', name: 'Midnight Snack', description: 'Scanned food at 2AM', icon: 'bedtime_off', requirement: '2AM Scan', xpReward: 500, category: 'collection' },
];

export const RANKS = [
    { level: 1, name: 'Dishwasher', xp: 0 },
    { level: 5, name: 'Line Cook', xp: 500 },
    { level: 10, name: 'Sous Chef', xp: 2000 },
    { level: 20, name: 'Head Chef', xp: 5000 },
    { level: 35, name: 'Executive Chef', xp: 12000 },
    { level: 50, name: 'Michelin Star', xp: 20000 },
    { level: 100, name: 'Culinary Legend', xp: 100000 },
];

export const LEADERBOARD_DATA: LeaderboardEntry[] = [
    { id: 'u1', name: 'Gordon R.', rank: 1, xp: 45000, avatar: 'https://i.pravatar.cc/150?u=gordon', badges: 42, streak: 125 },
    { id: 'u2', name: 'Jamie O.', rank: 2, xp: 42300, avatar: 'https://i.pravatar.cc/150?u=jamie', badges: 38, streak: 89 },
    { id: 'u3', name: 'Nigella L.', rank: 3, xp: 38900, avatar: 'https://i.pravatar.cc/150?u=nigella', badges: 35, streak: 45 },
    { id: 'u4', name: 'You', rank: 4, xp: 3450, avatar: 'https://storage.googleapis.com/aai-web-template-assets/stitch/profile-pic.png', badges: 8, streak: 12 },
    { id: 'u5', name: 'Massimo B.', rank: 5, xp: 3100, avatar: 'https://i.pravatar.cc/150?u=massimo', badges: 6, streak: 5 },
    { id: 'u6', name: 'David C.', rank: 6, xp: 2800, avatar: 'https://i.pravatar.cc/150?u=david', badges: 5, streak: 3 },
    { id: 'u7', name: 'Claire S.', rank: 7, xp: 2500, avatar: 'https://i.pravatar.cc/150?u=claire', badges: 4, streak: 8 },
    { id: 'u8', name: 'Joshua W.', rank: 8, xp: 2100, avatar: 'https://i.pravatar.cc/150?u=joshua', badges: 3, streak: 2 },
    { id: 'u9', name: 'Babish', rank: 9, xp: 1900, avatar: 'https://i.pravatar.cc/150?u=babish', badges: 2, streak: 1 },
    { id: 'u10', name: 'Kenji L.', rank: 10, xp: 1500, avatar: 'https://i.pravatar.cc/150?u=kenji', badges: 1, streak: 0 },
];

export const MOCK_POSTS: SocialPost[] = [
    {
        id: 'p1',
        userId: 'u1',
        userName: 'Gordon R.',
        userAvatar: 'https://i.pravatar.cc/150?u=gordon',
        imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop',
        caption: 'Finally perfected my Beef Wellington! The crust is absolutely exquisite. 🥩🥐 #cooking #dinner',
        likes: 1240,
        comments: [
            { id: 'c1', userId: 'u2', userName: 'Jamie O.', text: 'Looks smashing mate!', timestamp: '2h ago' }
        ],
        timestamp: '4h ago',
        tags: ['Beef', 'Dinner', 'Gourmet']
    },
    {
        id: 'p2',
        userId: 'u3',
        userName: 'Nigella L.',
        userAvatar: 'https://i.pravatar.cc/150?u=nigella',
        imageUrl: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop',
        caption: 'Late night pasta cravings. Simple, spicy, and satisfying. 🍝🌶️',
        likes: 856,
        comments: [],
        timestamp: '6h ago',
        tags: ['Pasta', 'Italian', 'ComfortFood']
    },
    {
        id: 'p3',
        userId: 'u8',
        userName: 'Joshua W.',
        userAvatar: 'https://i.pravatar.cc/150?u=joshua',
        imageUrl: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop',
        caption: 'Homemade pizza night! Sourdough crust fermented for 48 hours. 🍕',
        likes: 2100,
        comments: [
            { id: 'c2', userId: 'u9', userName: 'Babish', text: 'That crumb structure looks decent.', timestamp: '1h ago' }
        ],
        timestamp: '12h ago',
        tags: ['Pizza', 'Sourdough', 'Baking']
    },
    {
        id: 'p4',
        userId: 'u5',
        userName: 'Massimo B.',
        userAvatar: 'https://i.pravatar.cc/150?u=massimo',
        imageUrl: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=800&auto=format&fit=crop',
        caption: 'Dessert is an emotion. Tiramisu deconstructed. ☕🍰',
        likes: 1500,
        comments: [],
        timestamp: '1d ago',
        tags: ['Dessert', 'Art', 'Italian']
    }
];

export const TRANSLATIONS: any = {
  en: {
    home: "Home",
    shop: "Shop",
    scan: "Scan",
    profile: "Profile",
    planner: "Planner",
    stores: "Stores",
    saved: "Saved",
    appSettings: "App Settings",
    scanFood: "Scan Food",
    welcome: "Welcome Back",
    greetingMorning: "Good Morning",
    greetingAfternoon: "Good Afternoon",
    greetingEvening: "Good Evening",
    whatsInFridge: "What's in Your Fridge?",
    aiChefReady: "AI Chef Ready",
    getRecipes: "Get Recipes",
    quickAccess: "Quick Access",
    freshForYou: "Fresh for You",
    fridge: "Your Fridge",
    create: "Create Recipes",
    ingredients: "Ingredients",
    dietary: "Dietary",
    checkStock: "Check Stock",
    findStores: "Find Stores",
    nearMe: "Near Me",
    manualSearch: "Manual Search",
    analyzing: "Analyzing...",
    scanMeal: "Scan Meal",
    scanFridge: "Scan Fridge",
    startCooking: "Start Cooking",
    steps: "Steps",
    email: "Email",
    password: "Password",
    signIn: "Sign In",
    signUp: "Sign Up",
    guest: "Continue as Guest",
    haveAccount: "Already have an account?",
    noAccount: "Don't have an account?",
    or: "Or",
    subtitleLogin: "Enter your details to sign in.",
    subtitleSignup: "Join the future of cooking.",
    logOut: "Log Out",
    language: "Language",
    notifications: "Notifications",
    cookingProfile: "Cooking Profile",
    history: "History",
    directions: "Directions",
    searchPlaceholder: "What do you want to cook?",
    pantry: "Pantry",
    community: "Community",
    gamification: "Awards",
    analytics: "Stats",
    leaderboard: "Leaderboard",
    createPost: "Create Post",
    post: "Post",
    captionPlaceholder: "Write a caption...",
    location: "Location",
    tagRecipe: "Tag Recipe"
  },
  tr: {
    home: "Ana Sayfa",
    shop: "Alışveriş",
    scan: "Tara",
    profile: "Profil",
    planner: "Planlayıcı",
    stores: "Mağazalar",
    saved: "Kaydedilenler",
    appSettings: "Ayarlar",
    scanFood: "Yemek Tara",
    welcome: "Hoşgeldiniz",
    greetingMorning: "Günaydın",
    greetingAfternoon: "Tünaydın",
    greetingEvening: "İyi Akşamlar",
    whatsInFridge: "Dolabında Ne Var?",
    aiChefReady: "AI Şef Hazır",
    getRecipes: "Tarif Al",
    quickAccess: "Hızlı Erişim",
    freshForYou: "Sizin İçin Taze",
    fridge: "Dolabınız",
    create: "Oluştur",
    ingredients: "Malzemeler",
    dietary: "Diyet",
    checkStock: "Stok Kontrol",
    findStores: "Mağaza Bul",
    nearMe: "Yakınımda",
    manualSearch: "Manuel Ara",
    analyzing: "Analiz ediliyor...",
    scanMeal: "Yemek Tara",
    scanFridge: "Dolap Tara",
    startCooking: "Pişirmeye Başla",
    steps: "Adımlar",
    email: "E-posta",
    password: "Şifre",
    signIn: "Giriş Yap",
    signUp: "Kayıt Ol",
    guest: "Misafir Girişi",
    haveAccount: "Hesabınız var mı?",
    noAccount: "Hesabınız yok mu?",
    or: "Veya",
    subtitleLogin: "Giriş yapmak için bilgilerinizi girin.",
    subtitleSignup: "Geleceğin mutfağına katılın.",
    logOut: "Çıkış Yap",
    language: "Dil",
    notifications: "Bildirimler",
    cookingProfile: "Pişirme Profili",
    history: "Geçmiş",
    directions: "Yol Tarifi",
    searchPlaceholder: "Ne pişirmek istersin?",
    pantry: "Kiler",
    community: "Topluluk",
    gamification: "Ödüller",
    analytics: "İstatistik",
    leaderboard: "Sıralama",
    createPost: "Gönderi Oluştur",
    post: "Paylaş",
    captionPlaceholder: "Bir başlık yazın...",
    location: "Konum",
    tagRecipe: "Tarif Etiketle"
  },
  // Default fallbacks for other languages
  ar: { home: "الرئيسية", shop: "تسوّق", scan: "مسح", profile: "الملف", planner: "المخطط", stores: "المتاجر", saved: "المحفوظات", appSettings: "الإعدادات", pantry: "المخزن", community: "المجتمع", gamification: "الجوائز", analytics: "الإحصائيات", leaderboard: "لائحة المتصدرين", createPost: "إنشاء منشور", post: "نشر" },
  zh: { home: "首页", shop: "购物", scan: "扫描", profile: "我的", planner: "计划", stores: "商店", saved: "收藏", appSettings: "设置", pantry: "储藏室", community: "社区", gamification: "成就", analytics: "分析", leaderboard: "排行榜", createPost: "发帖", post: "发布" },
  de: { home: "Start", shop: "Einkaufen", scan: "Scannen", profile: "Profil", planner: "Planer", stores: "Läden", saved: "Gespeichert", appSettings: "Einstellungen", pantry: "Speisekammer", community: "Community", gamification: "Auszeichnungen", analytics: "Statistik", leaderboard: "Bestenliste", createPost: "Beitrag erstellen", post: "Posten" },
  ru: { home: "Главная", shop: "Покупки", scan: "Скан", profile: "Профиль", planner: "План", stores: "Магазины", saved: "Сохр.", appSettings: "Настройки", pantry: "Кладовая", community: "Сообщество", gamification: "Награды", analytics: "Аналитика", leaderboard: "Лидеры", createPost: "Создать", post: "Публикация" },
  es: { home: "Inicio", shop: "Tienda", scan: "Escanear", profile: "Perfil", planner: "Planificador", stores: "Tiendas", saved: "Guardado", appSettings: "Ajustes", pantry: "Despensa", community: "Comunidad", gamification: "Logros", analytics: "Estadísticas", leaderboard: "Clasificación", createPost: "Crear Post", post: "Publicar" },
  fr: { home: "Accueil", shop: "Achats", scan: "Scan", profile: "Profil", planner: "Planning", stores: "Magasins", saved: "Enregistré", appSettings: "Paramètres", pantry: "Garde-manger", community: "Communauté", gamification: "Récompenses", analytics: "Analytique", leaderboard: "Classement", createPost: "Créer", post: "Publier" },
  it: { home: "Home", shop: "Spesa", scan: "Scansiona", profile: "Profilo", planner: "Pianif.", stores: "Negozi", saved: "Salvati", appSettings: "Impostazioni", pantry: "Dispensa", community: "Comunità", gamification: "Premi", analytics: "Analisi", leaderboard: "Classifica", createPost: "Crea Post", post: "Pubblica" },
  ja: { home: "ホーム", shop: "買い物", scan: "スキャン", profile: "プロフィール", planner: "計画", stores: "店舗", saved: "保存", appSettings: "設定", pantry: "パントリー", community: "コミュニティ", gamification: "アワード", analytics: "分析", leaderboard: "リーダーボード", createPost: "投稿作成", post: "投稿" },
  pt: { home: "Início", shop: "Compras", scan: "Escanear", profile: "Perfil", planner: "Plano", stores: "Lojas", saved: "Salvos", appSettings: "Config.", pantry: "Despensa", community: "Comunidade", gamification: "Prêmios", analytics: "Análise", leaderboard: "Classificação", createPost: "Criar Post", post: "Publicar" },
  hi: { home: "होम", shop: "खरीदारी", scan: "स्कैन", profile: "प्रोफ़ाइल", planner: "योजना", stores: "दुकानें", saved: "सहेजा गया", appSettings: "सेटिंग्स", pantry: "पेंट्री", community: "समुदाय", gamification: "पुरस्कार", analytics: "विश्लेषण", leaderboard: "लीडरबोर्ड", createPost: "पोस्ट बनाएँ", post: "पोस्ट" },
  ko: { home: "홈", shop: "쇼핑", scan: "스캔", profile: "프로필", planner: "플래너", stores: "상점", saved: "저장됨", appSettings: "설정", pantry: "팬트리", community: "커뮤니티", gamification: "어워드", analytics: "분석", leaderboard: "순위표", createPost: "포스트 작성", post: "게시" }
};

export const getTranslation = (lang: Language, key: string): string => {
  const langData = TRANSLATIONS[lang] || TRANSLATIONS['en'];
  return langData[key] || TRANSLATIONS['en'][key] || key;
};
