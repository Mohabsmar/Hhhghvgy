
import React, { useState, useEffect, Suspense } from 'react';
import BottomNav from './components/BottomNav';
import { useCookbook } from './components/common/useCookbook';
import { Recipe, AppScreen, User, UserPreferences, Language, AppAction } from './types';
import Spinner from './components/common/Spinner';

// Lazy Load All Screens
const HomeScreen = React.lazy(() => import('./screens/HomeScreen'));
const DiscoverScreen = React.lazy(() => import('./screens/DiscoverScreen'));
const ProfileScreenModule = React.lazy(() => import('./components/common/screens/ProfileScreen').then(m => ({ default: m.ProfileScreen })));
const CookingModeScreen = React.lazy(() => import('./screens/CookingModeScreen'));
const RecipeDetailScreen = React.lazy(() => import('./components/common/screens/RecipeDetailScreen'));
const MealPlannerScreen = React.lazy(() => import('./components/common/screens/MealPlannerScreen'));
const ShoppingListScreen = React.lazy(() => import('./screens/ShoppingListScreen'));
const StoreLocatorScreen = React.lazy(() => import('./screens/StoreLocatorScreen'));
const FoodScannerScreen = React.lazy(() => import('./components/common/screens/FoodScannerScreen'));
const FavoritesScreen = React.lazy(() => import('./screens/FavoritesScreen'));
const LoginScreen = React.lazy(() => import('./components/common/screens/LoginScreen'));
const ChatBotScreen = React.lazy(() => import('./screens/ChatBotScreen'));
const NavBarEditorScreen = React.lazy(() => import('./screens/NavBarEditorScreen'));
const PantryScreen = React.lazy(() => import('./screens/PantryScreen'));
const CommunityScreen = React.lazy(() => import('./screens/CommunityScreen'));
const GamificationScreen = React.lazy(() => import('./screens/GamificationScreen'));
const AnalyticsScreen = React.lazy(() => import('./screens/AnalyticsScreen'));
const LeaderboardScreen = React.lazy(() => import('./screens/LeaderboardScreen'));
const CreatePostScreen = React.lazy(() => import('./screens/CreatePostScreen'));
const ChefProfileScreen = React.lazy(() => import('./screens/ChefProfileScreen'));
const LabsScreen = React.lazy(() => import('./screens/LabsScreen'));

// Feature Screens
const UnitConverterScreen = React.lazy(() => import('./screens/UnitConverterScreen'));
const KitchenTimersScreen = React.lazy(() => import('./screens/KitchenTimersScreen'));
const WinePairingScreen = React.lazy(() => import('./screens/WinePairingScreen'));
const MixologyScreen = React.lazy(() => import('./screens/MixologyScreen'));
const CoffeeBarScreen = React.lazy(() => import('./screens/CoffeeBarScreen'));
const SeasonalGuideScreen = React.lazy(() => import('./screens/SeasonalGuideScreen'));
const SubstitutionsScreen = React.lazy(() => import('./screens/SubstitutionsScreen'));
const CookingSchoolScreen = React.lazy(() => import('./screens/CookingSchoolScreen'));
const DictionaryScreen = React.lazy(() => import('./screens/DictionaryScreen'));
const LeftoverMagicScreen = React.lazy(() => import('./screens/LeftoverMagicScreen'));
const TasteProfilerScreen = React.lazy(() => import('./screens/TasteProfilerScreen'));
const FermentationLogScreen = React.lazy(() => import('./screens/FermentationLogScreen'));
const PartyPlannerScreen = React.lazy(() => import('./screens/PartyPlannerScreen'));
const DietaryReportScreen = React.lazy(() => import('./components/common/screens/DietaryReportScreen'));
const FamilySyncScreen = React.lazy(() => import('./screens/FamilySyncScreen'));
const MealPrepScreen = React.lazy(() => import('./screens/MealPrepScreen'));
const PriceCompareScreen = React.lazy(() => import('./screens/PriceCompareScreen'));
const FarmersMarketScreen = React.lazy(() => import('./screens/FarmersMarketScreen'));
const MolecularGastronomyScreen = React.lazy(() => import('./screens/MolecularGastronomyScreen'));
const FoodPhotographyScreen = React.lazy(() => import('./screens/FoodPhotographyScreen'));
const TeaLoungeScreen = React.lazy(() => import('./screens/TeaLoungeScreen'));
const SpiceBlenderScreen = React.lazy(() => import('./screens/SpiceBlenderScreen'));
const CheeseBoardScreen = React.lazy(() => import('./screens/CheeseBoardScreen'));
const SourdoughCalcScreen = React.lazy(() => import('./screens/SourdoughCalcScreen'));
const HomeBrewScreen = React.lazy(() => import('./screens/HomeBrewScreen'));
const CanningGuideScreen = React.lazy(() => import('./screens/CanningGuideScreen'));
const ForagingScreen = React.lazy(() => import('./screens/ForagingScreen'));
const ButcheryGuideScreen = React.lazy(() => import('./screens/ButcheryGuideScreen'));
const KnifeCareScreen = React.lazy(() => import('./screens/KnifeCareScreen'));
const ApplianceTrackerScreen = React.lazy(() => import('./screens/ApplianceTrackerScreen'));
const GardenTrackerScreen = React.lazy(() => import('./screens/GardenTrackerScreen'));
const HalalScannerScreen = React.lazy(() => import('./screens/HalalScannerScreen'));
const AllergyRadarScreen = React.lazy(() => import('./screens/AllergyRadarScreen'));
const SommelierChatScreen = React.lazy(() => import('./screens/SommelierChatScreen'));
const NutritionLabelDecoderScreen = React.lazy(() => import('./components/common/screens/NutritionLabelDecoderScreen'));

// Fix: Cannot find name 'ViewState'.
type ViewState = 
  | { type: 'tabs' }
  | { type: 'recipeDetail', recipe: Recipe }
  | { type: 'cooking', recipe: Recipe };

const defaultPreferences: UserPreferences = {
    dietary: [], cuisine: [], difficulty: 'Medium', notifications: true, language: 'en',
    nutritionDisplay: 'percentage', nutritionUnit: 'weight', nutritionChartType: 'donut',
    dataSaver: false, incognito: false, themeMode: 'dark',
    quickAccess: ['scanner', 'chat', 'shopping', 'favorites'],
    navBar: {
        style: 'floating', width: 90, height: 70, borderRadius: 40, bottomOffset: 24, horizontalOffset: 0,
        backgroundColor: '#0f172a', backgroundOpacity: 85, iconColor: '#94A3B8', activeIconColor: '#10B981',
        showLabels: false, blurEffect: true, borderColor: 'rgba(255,255,255,0.1)', borderWidth: 1,
        containerPosition: 'center', verticalPosition: 'bottom'
    }
};

const LoadingScreen = () => (
    <div className="fixed inset-0 bg-black flex items-center justify-center z-50">
        <div className="flex flex-col items-center gap-4">
            <Spinner className="size-10 text-primary" />
            <p className="text-white/50 text-sm font-bold animate-pulse">Entering Kitchen...</p>
        </div>
    </div>
);

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [activeScreen, setActiveScreen] = useState<AppScreen>('home');
  const [currentView, setCurrentView] = useState<ViewState>({ type: 'tabs' });
  const [scannedIngredients, setScannedIngredients] = useState<string[]>([]);
  const [cookingHistory, setCookingHistory] = useState<Recipe[]>([]);
  const [guestLanguage, setGuestLanguage] = useState<Language>('en'); 
  const [chatInitialQuery, setChatInitialQuery] = useState<string | undefined>(undefined);
  
  const { savedRecipes, addRecipe, removeRecipe, isRecipeSaved } = useCookbook();
  const currentLanguage = user?.preferences.language || guestLanguage;

  useEffect(() => {
    const stored = localStorage.getItem('stitch_user');
    if (stored) setUser(JSON.parse(stored));
  }, []);

  const handleLogin = (userProfile: User) => {
      setUser(userProfile);
      localStorage.setItem('stitch_user', JSON.stringify(userProfile));
  };

  const handleLogout = () => {
      localStorage.removeItem('stitch_user');
      setUser(null);
      setActiveScreen('home');
  };

  const handleUpdateUser = (updatedFields: Partial<User>) => {
      if (user) {
          const updatedUser = { ...user, ...updatedFields };
          setUser(updatedUser);
          localStorage.setItem('stitch_user', JSON.stringify(updatedUser));
      }
  };
  
  const handleAppAction = (action: AppAction) => {
      switch(action.type) {
          case 'NAVIGATE':
              if (action.payload) setActiveScreen(action.payload as AppScreen);
              setCurrentView({ type: 'tabs' });
              break;
          case 'GENERATE_RECIPE':
              setActiveScreen('discover');
              if (action.payload) setScannedIngredients([action.payload]); 
              break;
          case 'OPEN_SCANNER':
              setActiveScreen('scanner');
              break;
          case 'VIEW_RECIPE':
              if (action.payload) setCurrentView({ type: 'recipeDetail', recipe: action.payload });
              break;
          case 'START_COOKING':
              if (action.payload) {
                   setCookingHistory(prev => [action.payload, ...prev]);
                   setCurrentView({ type: 'cooking', recipe: action.payload });
              }
              break;
          case 'OPEN_CHAT':
              setChatInitialQuery(action.payload);
              setActiveScreen('chat');
              break;
      }
  };

  if (!user) {
    return (
        <Suspense fallback={<LoadingScreen />}>
            <LoginScreen onLogin={handleLogin} onGuestLogin={() => handleLogin({ 
                name: "Guest Chef", email: "guest@feast.app", photoUrl: "", preferences: defaultPreferences, 
                xp: 0, level: 1, rank: "Beginner", badges: [], stats: { recipesCooked: 0, streakDays: 0, moneySaved: 0, wasteReduced: 0, cuisinesExplored: [], totalCaloriesCooked: 0, weeklyActivity: [0,0,0,0,0,0,0] }
            })} selectedLanguage={guestLanguage} onLanguageChange={setGuestLanguage} />
        </Suspense>
    );
  }

  const renderScreen = () => (
    <Suspense fallback={<LoadingScreen />}>
        {(() => {
            switch (activeScreen) {
                case 'home': return <HomeScreen user={user} onNavigateToShopping={() => setActiveScreen('shopping')} onNavigateToPlanner={() => setActiveScreen('mealPlan')} onNavigateToFavorites={() => setActiveScreen('favorites')} onNavigateToScanner={() => setActiveScreen('scanner')} onNavigateToChat={() => setActiveScreen('chat')} onNavigateToProfile={() => setActiveScreen('profile')} onNavigateToStores={() => setActiveScreen('stores')} onNavigateToDiscover={() => setActiveScreen('discover')} onSelectRecipe={(recipe) => setCurrentView({ type: 'recipeDetail', recipe })} onSearch={(q) => { setActiveScreen('chat'); setChatInitialQuery(`Help me make ${q}`); }} lang={currentLanguage} onNavigate={setActiveScreen} />;
                case 'discover': return <DiscoverScreen onSelectRecipe={(recipe) => setCurrentView({ type: 'recipeDetail', recipe })} savedRecipes={savedRecipes} onToggleSave={(recipe) => isRecipeSaved(recipe.id) ? removeRecipe(recipe.id) : addRecipe(recipe)} initialIngredients={scannedIngredients} onIngredientsProcessed={() => setScannedIngredients([])} lang={currentLanguage} />;
                case 'pantry': return <PantryScreen onExit={() => setActiveScreen('home')} lang={currentLanguage} />;
                case 'community': return <CommunityScreen onExit={() => setActiveScreen('home')} lang={currentLanguage} onNavigate={setActiveScreen} />;
                case 'gamification': return <GamificationScreen user={user} onExit={() => setActiveScreen('profile')} lang={currentLanguage} onNavigate={setActiveScreen} />;
                case 'leaderboard': return <LeaderboardScreen onExit={() => setActiveScreen('gamification')} lang={currentLanguage} currentUser={user} />;
                case 'createPost': return <CreatePostScreen onExit={() => setActiveScreen('community')} lang={currentLanguage} />;
                case 'chefProfile': return <ChefProfileScreen chefId="u1" onExit={() => setActiveScreen('community')} />;
                case 'analytics': return <AnalyticsScreen user={user} onExit={() => setActiveScreen('profile')} lang={currentLanguage} />;
                case 'mealPlan': return <MealPlannerScreen onSelectRecipe={(recipe) => setCurrentView({ type: 'recipeDetail', recipe })} savedRecipes={savedRecipes} lang={currentLanguage} />;
                case 'shopping': return <ShoppingListScreen onExit={() => setActiveScreen('home')} lang={currentLanguage} />;
                case 'favorites': return <FavoritesScreen savedRecipes={savedRecipes} onSelectRecipe={(recipe) => setCurrentView({ type: 'recipeDetail', recipe })} onToggleSave={(recipe) => isRecipeSaved(recipe.id) ? removeRecipe(recipe.id) : addRecipe(recipe)} lang={currentLanguage} />;
                case 'stores': return <StoreLocatorScreen lang={currentLanguage} />;
                case 'scanner': return <FoodScannerScreen onExit={() => setActiveScreen('home')} onIngredientsFound={(ingredients) => { setScannedIngredients(ingredients); setActiveScreen('discover'); }} lang={currentLanguage} preferences={user.preferences} onUpdatePreferences={(prefs) => handleUpdateUser({ preferences: { ...user.preferences, ...prefs } })} onAction={handleAppAction} />;
                case 'chat': return <ChatBotScreen onExit={() => setActiveScreen('home')} lang={currentLanguage} onAction={handleAppAction} initialQuery={chatInitialQuery} />;
                case 'profile': return <ProfileScreenModule user={user} savedRecipes={savedRecipes} cookingHistory={cookingHistory} onSelectRecipe={(recipe) => setCurrentView({ type: 'recipeDetail', recipe })} onToggleSave={(recipe) => isRecipeSaved(recipe.id) ? removeRecipe(recipe.id) : addRecipe(recipe)} onLogout={handleLogout} onUpdateUser={handleUpdateUser} lang={currentLanguage} onNavigate={setActiveScreen} />;
                case 'navBarEditor': return <NavBarEditorScreen user={user} onUpdateUser={handleUpdateUser} onExit={() => setActiveScreen('profile')} />;
                case 'labs': return <LabsScreen onExit={() => setActiveScreen('profile')} onNavigate={setActiveScreen} />;
                // Labs feature fallback mapping
                case 'unitConverter': return <UnitConverterScreen onExit={() => setActiveScreen('labs')} />;
                case 'kitchenTimers': return <KitchenTimersScreen onExit={() => setActiveScreen('labs')} />;
                case 'winePairing': return <WinePairingScreen onExit={() => setActiveScreen('labs')} />;
                case 'mixology': return <MixologyScreen onExit={() => setActiveScreen('labs')} />;
                case 'coffeeBar': return <CoffeeBarScreen onExit={() => setActiveScreen('labs')} />;
                case 'seasonalGuide': return <SeasonalGuideScreen onExit={() => setActiveScreen('labs')} />;
                case 'substitutions': return <SubstitutionsScreen onExit={() => setActiveScreen('labs')} />;
                case 'cookingSchool': return <CookingSchoolScreen onExit={() => setActiveScreen('labs')} />;
                case 'dictionary': return <DictionaryScreen onExit={() => setActiveScreen('labs')} />;
                case 'leftoverMagic': return <LeftoverMagicScreen onExit={() => setActiveScreen('labs')} />;
                case 'tasteProfiler': return <TasteProfilerScreen onExit={() => setActiveScreen('labs')} />;
                case 'fermentationLog': return <FermentationLogScreen onExit={() => setActiveScreen('labs')} />;
                case 'partyPlanner': return <PartyPlannerScreen onExit={() => setActiveScreen('labs')} />;
                case 'dietaryReport': return <DietaryReportScreen onExit={() => setActiveScreen('labs')} />;
                case 'familySync': return <FamilySyncScreen onExit={() => setActiveScreen('labs')} />;
                case 'mealPrep': return <MealPrepScreen onExit={() => setActiveScreen('labs')} />;
                case 'priceCompare': return <PriceCompareScreen onExit={() => setActiveScreen('labs')} />;
                case 'farmersMarket': return <FarmersMarketScreen onExit={() => setActiveScreen('labs')} />;
                case 'molecularGastronomy': return <MolecularGastronomyScreen onExit={() => setActiveScreen('labs')} />;
                case 'foodPhotography': return <FoodPhotographyScreen onExit={() => setActiveScreen('labs')} />;
                case 'teaLounge': return <TeaLoungeScreen onExit={() => setActiveScreen('labs')} />;
                case 'spiceBlender': return <SpiceBlenderScreen onExit={() => setActiveScreen('labs')} />;
                case 'cheeseBoard': return <CheeseBoardScreen onExit={() => setActiveScreen('labs')} />;
                case 'sourdoughCalc': return <SourdoughCalcScreen onExit={() => setActiveScreen('labs')} />;
                case 'homeBrew': return <HomeBrewScreen onExit={() => setActiveScreen('labs')} />;
                case 'canningGuide': return <CanningGuideScreen onExit={() => setActiveScreen('labs')} />;
                case 'foraging': return <ForagingScreen onExit={() => setActiveScreen('labs')} />;
                case 'butcheryGuide': return <ButcheryGuideScreen onExit={() => setActiveScreen('labs')} />;
                case 'knifeCare': return <KnifeCareScreen onExit={() => setActiveScreen('labs')} />;
                case 'applianceTracker': return <ApplianceTrackerScreen onExit={() => setActiveScreen('labs')} />;
                case 'gardenTracker': return <GardenTrackerScreen onExit={() => setActiveScreen('labs')} />;
                case 'halalScanner': return <HalalScannerScreen onExit={() => setActiveScreen('labs')} />;
                case 'allergyRadar': return <AllergyRadarScreen onExit={() => setActiveScreen('labs')} />;
                case 'sommelierChat': return <SommelierChatScreen onExit={() => setActiveScreen('labs')} />;
                case 'labelDecoder': return <NutritionLabelDecoderScreen onExit={() => setActiveScreen('labs')} />;
                default: return <div className="p-10 text-white">Screen not found</div>;
            }
        })()}
    </Suspense>
  );

  const isFullScreen = [
      'scanner', 'navBarEditor', 'leaderboard', 'createPost', 'chefProfile', 'labs', 'cooking',
      'unitConverter', 'kitchenTimers', 'winePairing', 'mixology', 'coffeeBar', 'substitutions', 'seasonalGuide', 
      'cookingSchool', 'dictionary', 'leftoverMagic', 'tasteProfiler', 'fermentationLog', 'partyPlanner', 
      'dietaryReport', 'familySync', 'mealPrep', 'priceCompare', 'farmersMarket', 'molecularGastronomy', 
      'foodPhotography', 'teaLounge', 'spiceBlender', 'cheeseBoard', 'sourdoughCalc', 'homeBrew', 'canningGuide', 
      'foraging', 'butcheryGuide', 'knifeCare', 'applianceTracker', 'gardenTracker', 'halalScanner', 'allergyRadar', 
      'sommelierChat', 'labelDecoder'
  ].includes(activeScreen);

  return (
    <>
      {currentView.type === 'tabs' && (
          <div className="min-h-screen bg-black">
            {renderScreen()}
            {!isFullScreen && (
                <BottomNav 
                    activeScreen={activeScreen} 
                    onNavigate={setActiveScreen} 
                    lang={currentLanguage} 
                    config={user.preferences.navBar}
                />
            )}
          </div>
      )}

      {currentView.type === 'recipeDetail' && (
        <Suspense fallback={<LoadingScreen />}>
            <RecipeDetailScreen recipe={currentView.recipe} onStartCooking={(recipe) => setCurrentView({ type: 'cooking', recipe })} onExit={() => setCurrentView({ type: 'tabs' })} lang={currentLanguage} chartMode={user.preferences.nutritionUnit === 'calories' ? 'calories' : 'weight'} />
        </Suspense>
      )}

      {currentView.type === 'cooking' && (
        <Suspense fallback={<LoadingScreen />}>
            <CookingModeScreen recipe={currentView.recipe} onExit={() => setCurrentView({ type: 'recipeDetail', recipe: currentView.recipe })} onFinish={() => { setCurrentView({ type: 'tabs' }); setActiveScreen('home'); }} lang={currentLanguage} />
        </Suspense>
      )}
    </>
  );
};

export default App;
