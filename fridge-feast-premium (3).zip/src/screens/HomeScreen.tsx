
import React, { useState } from 'react';
import { Recipe, User, Language, QuickAccessId, AppScreen } from '../types';
import { getTranslation } from '../constants';

interface HomeScreenProps {
    user: User | null;
    onNavigateToShopping: () => void;
    onNavigateToPlanner: () => void;
    onNavigateToFavorites: () => void;
    onNavigateToScanner: () => void;
    onNavigateToChat: () => void;
    onNavigateToProfile: () => void;
    onNavigateToStores: () => void;
    onSelectRecipe: (recipe: Recipe) => void;
    onNavigateToDiscover: () => void;
    onSearch: (query: string) => void;
    lang: Language;
    onNavigate: (screen: AppScreen) => void;
}

const mockSuggestedRecipes: Recipe[] = [
    { 
        id: 'h1', recipeName: 'Lemon Butter Salmon', description: 'Quick and fresh pan-seared salmon.', 
        prepTime: '5m', cookTime: '10m', calories: 420, protein: 34, carbs: 2, fat: 28, difficulty: 'Easy', 
        ingredients: [{ name: "Salmon", amount: "2 fillets" }, { name: "Lemon", amount: "1" }], 
        instructions: ["Sear salmon...", "Drizzle lemon..."], servings: 2, 
        imageUrl: `https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=800` 
    },
    { 
        id: 'h2', recipeName: 'Avocado Toast Elite', description: 'Sourdough with poached egg and seeds.', 
        prepTime: '5m', cookTime: '5m', calories: 310, protein: 12, carbs: 22, fat: 18, difficulty: 'Easy', 
        ingredients: [{ name: "Sourdough", amount: "2 slices" }], 
        instructions: ["Toast bread...", "Mash avocado..."], servings: 1, 
        imageUrl: `https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800` 
    },
    { 
        id: 'h3', recipeName: 'Filet Mignon au Poivre', description: 'Tender beef with a classic peppercorn sauce.', 
        prepTime: '10m', cookTime: '15m', calories: 580, protein: 45, carbs: 4, fat: 42, difficulty: 'Medium', 
        ingredients: [{ name: "Filet Mignon", amount: "2" }], 
        instructions: ["Sear beef...", "Deglaze pan..."], servings: 2, 
        imageUrl: `https://images.unsplash.com/photo-1558030006-450675393462?w=800` 
    }
];

const HomeScreen: React.FC<HomeScreenProps> = ({ user, onNavigateToShopping, onNavigateToPlanner, onNavigateToFavorites, onNavigateToScanner, onNavigateToChat, onNavigateToProfile, onNavigateToStores, onSelectRecipe, onNavigateToDiscover, onSearch, lang, onNavigate }) => {
    const [query, setQuery] = useState('');
    const t = (key: any) => getTranslation(lang, key);

    const quickActions = [
        { id: 'scanner', icon: 'center_focus_weak', label: 'Scanner', action: onNavigateToScanner },
        { id: 'chat', icon: 'smart_toy', label: 'Chef AI', action: onNavigateToChat },
        { id: 'pantry', icon: 'inventory_2', label: 'Pantry', action: () => onNavigate('pantry') },
        { id: 'shopping', icon: 'shopping_basket', label: 'Cart', action: onNavigateToShopping },
    ];

    return (
        <div className="pb-32 min-h-screen bg-black font-display relative overflow-x-hidden">
            <header className="px-6 pt-14 pb-8 sticky top-0 z-30 liquid-glass border-b border-white/5 rounded-b-[48px] shadow-2xl">
                <div className="flex justify-between items-center mb-8">
                    <div className="flex items-center gap-4 cursor-pointer" onClick={onNavigateToProfile}>
                        <div className="size-14 rounded-2xl bg-gradient-to-br from-primary to-secondary p-[1px] shadow-lg shadow-primary/20">
                            <div className="size-full rounded-2xl bg-black overflow-hidden border border-white/10 flex items-center justify-center">
                                {user?.photoUrl ? <img src={user.photoUrl} className="size-full object-cover" /> : <span className="material-symbols-outlined text-white/30 text-2xl">person</span>}
                            </div>
                        </div>
                        <div>
                            <p className="text-[10px] font-black text-primary uppercase tracking-[0.2em] mb-0.5">Atelier Member</p>
                            <h2 className="text-2xl font-black text-white leading-none tracking-tighter">{user?.name.split(' ')[0]}</h2>
                        </div>
                    </div>
                    <button className="size-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/40 hover:text-primary transition-colors">
                        <span className="material-symbols-outlined">notifications</span>
                    </button>
                </div>

                <div className="relative group">
                    <span className="material-symbols-outlined absolute left-5 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-primary transition-colors">search</span>
                    <input 
                        type="text" value={query} onChange={e => setQuery(e.target.value)}
                        placeholder="Search your library..." 
                        onKeyDown={e => e.key === 'Enter' && query && onSearch(query)}
                        className="w-full h-14 bg-white/5 rounded-full pl-14 pr-6 text-white text-[15px] font-bold border border-white/10 focus:border-primary/40 transition-all placeholder:text-white/20"
                    />
                </div>
            </header>

            <main className="px-6 space-y-12 mt-8 animate-reveal">
                {/* Hero Card */}
                <div className="relative aspect-[16/10] w-full rounded-[48px] overflow-hidden border border-white/10 group cursor-pointer shadow-2xl" onClick={onNavigateToDiscover}>
                    <img src="https://images.unsplash.com/photo-1556910103-1c02745a30bf?w=1200&q=80" className="size-full object-cover group-hover:scale-110 transition-transform duration-[12s] ease-out" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent"></div>
                    <div className="absolute inset-x-10 bottom-10">
                        <h3 className="text-5xl font-black text-white leading-[0.85] tracking-tighter mb-6 drop-shadow-2xl">Find Your Next<br/><span className="text-primary">Culinary Feast.</span></h3>
                        <button className="h-14 px-10 rounded-full bg-white text-black font-black text-xs uppercase tracking-widest shadow-xl active:scale-95 transition-all">Start Journey</button>
                    </div>
                </div>

                {/* Quick Actions */}
                <div className="grid grid-cols-4 gap-4">
                    {quickActions.map(action => (
                        <button key={action.id} onClick={action.action} className="flex flex-col items-center gap-3 active:scale-90 transition-transform group">
                            <div className="size-16 rounded-[24px] bg-white/5 border border-white/5 flex items-center justify-center text-white/40 group-hover:text-primary group-hover:border-primary/20 transition-all shadow-lg">
                                <span className="material-symbols-outlined text-3xl">{action.icon}</span>
                            </div>
                            <span className="text-[9px] font-black text-white/40 uppercase tracking-widest group-hover:text-white transition-colors">{action.label}</span>
                        </button>
                    ))}
                </div>

                {/* Suggestions Carousel - FIXED SWIPING */}
                <div className="pb-10">
                    <div className="flex justify-between items-end mb-6 px-1">
                        <h4 className="text-[11px] font-black text-white/30 uppercase tracking-[0.4em]">Neural Recommendations</h4>
                        <span className="text-[10px] font-bold text-primary uppercase tracking-widest cursor-pointer hover:underline">View All</span>
                    </div>
                    
                    {/* Carousel Container */}
                    <div 
                        className="snap-carousel no-scrollbar -mx-6 px-6 gap-6" 
                        data-scrollable="true"
                    >
                        {mockSuggestedRecipes.map(recipe => (
                            <div 
                                key={recipe.id} 
                                onClick={() => onSelectRecipe(recipe)} 
                                className="min-w-[300px] aspect-[4/5] rounded-[48px] overflow-hidden relative border border-white/5 shadow-2xl group cursor-pointer snap-start"
                            >
                                <img src={recipe.imageUrl} className="size-full object-cover transition-transform group-hover:scale-105 duration-1000" />
                                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80 transition-opacity group-hover:opacity-70"></div>
                                <div className="absolute bottom-10 left-8 right-8">
                                    <h4 className="text-3xl font-black text-white leading-none tracking-tighter mb-4 drop-shadow-xl">{recipe.recipeName}</h4>
                                    <div className="flex gap-4">
                                        <span className="text-[10px] font-black text-white/60 uppercase tracking-widest flex items-center gap-1">
                                            <span className="material-symbols-outlined text-sm text-primary">timer</span> {recipe.cookTime}
                                        </span>
                                        <span className="text-[10px] font-black text-white/60 uppercase tracking-widest flex items-center gap-1">
                                            <span className="material-symbols-outlined text-sm text-primary">bolt</span> {recipe.calories} Cal
                                        </span>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </main>
        </div>
    );
};

export default HomeScreen;
