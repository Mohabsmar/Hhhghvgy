
import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";
import { Recipe, Filters, ScanResult, Store, Language, Substitution, SeasonalProduce, CulinaryTerm, PartyPlan, TasteProfile } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const recipeSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      recipeName: { type: Type.STRING },
      description: { type: Type.STRING },
      origin: { type: Type.STRING },
      history: { type: Type.STRING },
      prepTime: { type: Type.STRING },
      cookTime: { type: Type.STRING },
      servings: { type: Type.INTEGER },
      calories: { type: Type.INTEGER },
      calorieBreakdown: { type: Type.STRING },
      protein: { type: Type.INTEGER },
      carbs: { type: Type.INTEGER },
      fat: { type: Type.INTEGER },
      difficulty: { type: Type.STRING },
      ingredients: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            amount: { type: Type.STRING },
            name: { type: Type.STRING }
          },
          required: ["amount", "name"],
        },
      },
      instructions: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
      },
    },
    required: ["recipeName", "description", "prepTime", "cookTime", "servings", "calories", "protein", "carbs", "fat", "difficulty", "ingredients", "instructions"],
  },
};

const scanSchema = {
  type: Type.OBJECT,
  properties: {
    foodName: { type: Type.STRING },
    calories: { type: Type.INTEGER },
    description: { type: Type.STRING },
    origin: { type: Type.STRING },
    nutrients: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
            name: { type: Type.STRING },
            amount: { type: Type.STRING }
        }
      }
    }
  },
  required: ["foodName", "calories", "description", "origin", "nutrients"]
};

/**
 * Generates an actual image using Gemini 2.5 Flash Image
 */
export const generateRecipeImage = async (recipeName: string): Promise<string> => {
  try {
    const prompt = `A professional Michelin-star quality food photograph of ${recipeName}. Cinematic lighting, extreme detail, top-down or 45-degree angle, high-end restaurant plating, emerald green and charcoal black background theme.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: [{ text: prompt }],
      config: {
        imageConfig: {
          aspectRatio: "16:9"
        }
      }
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data returned");
  } catch (error) {
    console.error("Image generation failed:", error);
    // Fallback to a high-quality placeholder if generation fails for speed/quota reasons
    return `https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=1200&q=80`;
  }
};

/**
 * Generates an ingredient visual for "Input" display
 */
export const generateIngredientImage = async (ingredientName: string): Promise<string> => {
  try {
    const prompt = `A single raw ${ingredientName} on a dark minimalist background, clean lighting, food photography style.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: [{ text: prompt }],
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    return `https://source.unsplash.com/400x400/?${encodeURIComponent(ingredientName)},food`;
  } catch (error) {
    return `https://source.unsplash.com/400x400/?${encodeURIComponent(ingredientName)},food`;
  }
};

export const chatWithChef = async (
    history: any[], 
    message: string, 
    image?: {mimeType: string, data: string},
    lang: Language = 'en'
): Promise<{text: string, toolCalls?: any[]}> => {
  try {
    let parts: any[] = [{ text: message }];
    if (image) parts.push({ inlineData: { mimeType: image.mimeType, data: image.data } });

    const contents = [
        ...history,
        { role: 'user', parts: parts }
    ];

    const result = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents,
      config: { 
          systemInstruction: `You are CalBot, an elite AI Executive Chef. 
          Respond in the requested language: ${lang}.
          Capabilities:
          1. Use 'propose_dish' for recipes.
          2. Use 'navigate_to' for app navigation.
          Always be professional, concise, and helpful.`,
          thinkingConfig: { thinkingBudget: 0 },
          tools: [{ functionDeclarations: [
            {
                name: 'propose_dish',
                description: 'Propose a recipe when the user asks how to cook something.',
                parameters: {
                    type: Type.OBJECT,
                    properties: { dishName: { type: Type.STRING } },
                    required: ['dishName']
                }
            },
            {
                name: 'navigate_to',
                description: 'Navigate to a screen in the app.',
                parameters: {
                    type: Type.OBJECT,
                    properties: { screen: { type: Type.STRING, enum: ['scanner', 'shopping', 'mealPlan', 'profile', 'stores', 'labs', 'pantry'] } },
                    required: ['screen']
                }
            }
          ] }]
      }
    });
    
    return { text: result.text || "", toolCalls: result.functionCalls };
  } catch (error) {
    return { text: "Chef is busy in the kitchen. Try again!" };
  }
};

export const analyzeFoodImage = async (base64Image: string, lang: Language = 'en'): Promise<ScanResult> => {
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: {
            parts: [
                { inlineData: { mimeType: 'image/jpeg', data: base64Image } },
                { text: `Analyze this dish in detail. Language: ${lang}. Return JSON.` }
            ]
        },
        config: { 
            responseMimeType: "application/json", 
            responseSchema: scanSchema,
            thinkingConfig: { thinkingBudget: 0 }
        }
    });
    return JSON.parse(response.text) as ScanResult;
}

export const identifyFridgeIngredients = async (base64Image: string, lang: Language = 'en'): Promise<string[]> => {
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: {
            parts: [
                { inlineData: { mimeType: 'image/jpeg', data: base64Image } },
                { text: `Identify ingredients in this fridge. Return JSON with 'ingredients' array. Language: ${lang}.` }
            ]
        },
        config: { 
            responseMimeType: "application/json", 
            responseSchema: { type: Type.OBJECT, properties: { ingredients: { type: Type.ARRAY, items: { type: Type.STRING } } } },
            thinkingConfig: { thinkingBudget: 0 }
        }
    });
    const res = JSON.parse(response.text);
    return res.ingredients || [];
}

export const generateRecipesFromIngredients = async (
  ingredients: string[],
  filters: Filters,
  lang: Language = 'en'
): Promise<Recipe[]> => {
  const prompt = `3-Michelin star Chef. Generate 3 gourmet recipes using: ${ingredients.join(', ')}. 
  Dietary: ${filters.dietary.join(', ')}, Cuisine: ${filters.cuisine.join(', ')}.
  Language: ${lang}. Return JSON array.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: { 
        responseMimeType: "application/json", 
        responseSchema: recipeSchema,
        thinkingConfig: { thinkingBudget: 0 }
    },
  });

  const rawRecipes = JSON.parse(response.text) as Omit<Recipe, 'id' | 'imageUrl'>[];
  // Parallel image generation for speed
  return await Promise.all(rawRecipes.map(async (r, i) => {
    const imageUrl = await generateRecipeImage(r.recipeName);
    return {
      ...r,
      id: `neural-recipe-${Date.now()}-${i}`,
      imageUrl
    };
  }));
};

export const generateLeftoverRecipe = async (ingredients: string[]): Promise<Recipe> => {
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Generate 1 elite gourmet recipe using ONLY: ${ingredients.join(', ')}. Return JSON array with one item.`,
        config: { 
            responseMimeType: "application/json", 
            responseSchema: recipeSchema,
            thinkingConfig: { thinkingBudget: 0 }
        },
    });
    const rawRecipes = JSON.parse(response.text) as Omit<Recipe, 'id' | 'imageUrl'>[];
    const r = rawRecipes[0];
    const imageUrl = await generateRecipeImage(r.recipeName);
    return {
        ...r,
        id: `leftover-${Date.now()}`,
        imageUrl
    };
};

export const searchNearbyStores = async (params: { lat?: number; lng?: number; query?: string; lang?: Language }): Promise<Store[]> => {
    let prompt = params.query ? `Supermarkets near "${params.query}"` : `Supermarkets near me.`;
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: { 
            tools: [{ googleMaps: {} }],
            toolConfig: { retrievalConfig: { latLng: params.lat && params.lng ? { latitude: params.lat, longitude: params.lng } : undefined } }
        }
    });
    const stores: Store[] = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    chunks.forEach((chunk: any, i) => {
        const title = chunk.web?.title || chunk.maps?.title;
        const uri = chunk.web?.uri || chunk.maps?.uri;
        if (title) {
            stores.push({ id: `s-${i}`, name: title, address: "Nearby", mapUri: uri, isOpen: true });
        }
    });
    return stores;
};

export const askCulinaryExpert = async (role: string, query: string, lang: Language = 'en'): Promise<string> => {
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `You are a world-class ${role}. ${query}. Respond in ${lang}.`,
        config: { thinkingConfig: { thinkingBudget: 0 } }
    });
    return response.text;
};

export const findSubstitutions = async (ingredient: string): Promise<Substitution> => {
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `3 substitutes for ${ingredient}. JSON: {original, substitutes: [{name, ratio, notes}]}`,
        config: { responseMimeType: "application/json", thinkingConfig: { thinkingBudget: 0 } }
    });
    return JSON.parse(response.text);
};

export const getSeasonalProduce = async (month: string, hemisphere: string): Promise<SeasonalProduce> => {
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Seasonal produce for ${month} in ${hemisphere}. JSON: {month, hemisphere, fruits: [], vegetables: []}`,
        config: { responseMimeType: "application/json", thinkingConfig: { thinkingBudget: 0 } }
    });
    return JSON.parse(response.text);
};

export const analyzeTasteProfile = async (answers: string[]): Promise<TasteProfile> => {
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Map flavor DNA from these answers: ${answers.join('. ')}. Return JSON profile.`,
        config: { responseMimeType: "application/json", thinkingConfig: { thinkingBudget: 0 } }
    });
    return JSON.parse(response.text);
};

export const recommendWine = async (dish: string): Promise<{ name: string; type: string; description: string; priceRange: string }> => {
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Wine pairing for: ${dish}. JSON: {name, type, description, priceRange}`,
        config: { responseMimeType: "application/json", thinkingBudget: 0 }
    });
    return JSON.parse(response.text);
};

export const generateCocktail = async (vibe: string): Promise<Recipe> => {
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `1 unique cocktail for vibe: ${vibe}. Return JSON array.`,
        config: { 
            responseMimeType: "application/json", 
            responseSchema: recipeSchema,
            thinkingConfig: { thinkingBudget: 0 }
        },
    });
    const rawRecipes = JSON.parse(response.text) as Omit<Recipe, 'id' | 'imageUrl'>[];
    const r = rawRecipes[0];
    const imageUrl = await generateRecipeImage(r.recipeName);
    return { ...r, id: `cocktail-${Date.now()}`, imageUrl };
};

export const explainCulinaryTerm = async (term: string): Promise<CulinaryTerm> => {
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Explain: ${term}. JSON: {term, definition, category, pronunciation}`,
        config: { responseMimeType: "application/json", thinkingConfig: { thinkingBudget: 0 } }
    });
    return JSON.parse(response.text);
};

export const generatePartyPlan = async (guests: number, duration: number, type: string): Promise<PartyPlan> => {
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Plan for ${guests} guests, ${duration} hrs, ${type} party. JSON: {guests, duration, type, foodRequirements: [], drinkRequirements: []}`,
        config: { responseMimeType: "application/json", thinkingConfig: { thinkingBudget: 0 } }
    });
    return JSON.parse(response.text);
};
