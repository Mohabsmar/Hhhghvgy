
import { useState, useEffect, useCallback } from 'react';
import { Recipe } from '../../types';

const STORAGE_KEY = 'stitchSavedRecipes';

export const useCookbook = () => {
  const [savedRecipes, setSavedRecipes] = useState<Recipe[]>([]);

  useEffect(() => {
    try {
      const storedItems = window.localStorage.getItem(STORAGE_KEY);
      if (storedItems) {
        setSavedRecipes(JSON.parse(storedItems));
      }
    } catch (error) {
      console.error("Error reading saved recipes from localStorage", error);
    }
  }, []);

  const saveToLocalStorage = (recipes: Recipe[]) => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(recipes));
    } catch (error) {
      console.error("Error saving recipes to localStorage", error);
    }
  };

  const addRecipe = useCallback((recipe: Recipe) => {
    setSavedRecipes(prevRecipes => {
      const newRecipes = [...prevRecipes, recipe];
      saveToLocalStorage(newRecipes);
      return newRecipes;
    });
  }, []);

  const removeRecipe = useCallback((recipeId: string) => {
    setSavedRecipes(prevRecipes => {
      const newRecipes = prevRecipes.filter(r => r.id !== recipeId);
      saveToLocalStorage(newRecipes);
      return newRecipes;
    });
  }, []);
  
  const isRecipeSaved = useCallback((recipeId: string) => {
    return savedRecipes.some(r => r.id === recipeId);
  }, [savedRecipes]);

  return { savedRecipes, addRecipe, removeRecipe, isRecipeSaved };
};
