
import { User, PantryItem, Recipe } from '../types';
import { db as firestoreDb, auth, isConfigured } from './firebase';
import { doc, getDoc, setDoc, updateDoc, collection, getDocs, deleteDoc, addDoc } from 'firebase/firestore';

class DatabaseService {
  
  // --- Local Storage Fallbacks (Mock Mode) ---
  private _getLocal(key: string) {
    const data = localStorage.getItem(`stitch_${key}`);
    return data ? JSON.parse(data) : null;
  }
  private _setLocal(key: string, data: any) {
    localStorage.setItem(`stitch_${key}`, JSON.stringify(data));
  }

  // --- User Operations ---
  async saveUser(user: User): Promise<void> {
    if (isConfigured && firestoreDb && auth?.currentUser) {
        // Save to Firestore: users/{uid}
        await setDoc(doc(firestoreDb, 'users', auth.currentUser.uid), user, { merge: true });
    } else {
        this._setLocal(`user_${user.email}`, user);
    }
  }

  async getUser(email: string): Promise<User | null> {
    if (isConfigured && firestoreDb && auth?.currentUser) {
        const snap = await getDoc(doc(firestoreDb, 'users', auth.currentUser.uid));
        return snap.exists() ? snap.data() as User : null;
    } else {
        return this._getLocal(`user_${email}`);
    }
  }

  // --- Recipe Operations ---
  async saveRecipe(recipe: Recipe): Promise<void> {
    if (isConfigured && firestoreDb && auth?.currentUser) {
        // Save to Firestore: users/{uid}/savedRecipes/{recipeId}
        await setDoc(doc(firestoreDb, 'users', auth.currentUser.uid, 'savedRecipes', recipe.id), recipe);
    } else {
        const recipes = await this.getSavedRecipes();
        const filtered = recipes.filter(r => r.id !== recipe.id);
        this._setLocal('recipes', [...filtered, recipe]);
    }
  }

  async getSavedRecipes(): Promise<Recipe[]> {
    if (isConfigured && firestoreDb && auth?.currentUser) {
        const snap = await getDocs(collection(firestoreDb, 'users', auth.currentUser.uid, 'savedRecipes'));
        return snap.docs.map(d => d.data() as Recipe);
    } else {
        return this._getLocal('recipes') || [];
    }
  }

  async deleteRecipe(id: string): Promise<void> {
    if (isConfigured && firestoreDb && auth?.currentUser) {
        await deleteDoc(doc(firestoreDb, 'users', auth.currentUser.uid, 'savedRecipes', id));
    } else {
        const recipes = await this.getSavedRecipes();
        this._setLocal('recipes', recipes.filter(r => r.id !== id));
    }
  }

  // --- Pantry Operations ---
  async updatePantryItem(item: PantryItem): Promise<void> {
    if (isConfigured && firestoreDb && auth?.currentUser) {
        await setDoc(doc(firestoreDb, 'users', auth.currentUser.uid, 'pantry', item.id), item);
    } else {
        const items = await this.getAllPantry();
        const filtered = items.filter(i => i.id !== item.id);
        this._setLocal('pantry', [...filtered, item]);
    }
  }

  async getAllPantry(): Promise<PantryItem[]> {
    if (isConfigured && firestoreDb && auth?.currentUser) {
        const snap = await getDocs(collection(firestoreDb, 'users', auth.currentUser.uid, 'pantry'));
        return snap.docs.map(d => d.data() as PantryItem);
    } else {
        return this._getLocal('pantry') || [];
    }
  }

  async deletePantryItem(id: string): Promise<void> {
    if (isConfigured && firestoreDb && auth?.currentUser) {
        await deleteDoc(doc(firestoreDb, 'users', auth.currentUser.uid, 'pantry', id));
    } else {
        const items = await this.getAllPantry();
        this._setLocal('pantry', items.filter(i => i.id !== id));
    }
  }
}

export const dbService = new DatabaseService();
export const dbInstance = dbService; // Alias for compatibility if needed
// Export a 'db' object that matches the previous import usage in App.tsx
export const db = dbService;
