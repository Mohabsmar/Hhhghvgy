
import React from 'react';
import { IngredientItem } from '../../types';

interface IngredientChipProps {
  ingredient: IngredientItem;
  onRemove: (id: string) => void;
}

const IngredientChip: React.FC<IngredientChipProps> = ({ ingredient, onRemove }) => {
  return (
    <div className="flex items-center gap-2 h-10 pl-1 pr-2 rounded-full bg-surface-dark border border-white/10 text-text-dark animate-fade-in hover:border-primary/50 transition-colors group shadow-sm">
      <div className="size-8 rounded-full bg-surface-dark-secondary flex items-center justify-center overflow-hidden border border-white/5">
          {ingredient.isLoading ? (
             <div className="size-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
          ) : ingredient.imageUrl ? (
             <img src={ingredient.imageUrl} alt={ingredient.name} className="w-full h-full object-cover" />
          ) : (
             <span className="material-symbols-outlined text-base text-text-dark-secondary">nutrition</span>
          )}
      </div>
      <span className="text-sm font-medium">{ingredient.name}</span>
      <button
        onClick={() => onRemove(ingredient.id)}
        className="flex items-center justify-center size-5 rounded-full text-text-dark-secondary hover:text-error hover:bg-error/10 transition-all ml-1"
        aria-label={`Remove ${ingredient.name}`}
      >
        <span className="material-symbols-outlined text-sm">close</span>
      </button>
    </div>
  );
};

export default IngredientChip;
