import React from 'react';
import { Recipe } from '../../types';

interface RecipeCardProps {
  recipe: Recipe;
  onSelect: () => void;
  isSaved: boolean;
  onToggleSave: (recipe: Recipe) => void;
}

const Stat: React.FC<{ icon: string; value: string | number; unit: string; color?: string }> = ({ icon, value, unit, color = "text-primary" }) => (
    <div className="flex flex-col items-center justify-center">
        <div className="flex items-center gap-1 mb-0.5">
            <span className={`material-symbols-outlined text-sm ${color}`}>{icon}</span>
            <span className="font-bold text-white text-sm">{value}</span>
        </div>
        <span className="text-[10px] uppercase tracking-wide opacity-50 font-bold">{unit}</span>
    </div>
);

const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, onSelect, isSaved, onToggleSave }) => {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case 'easy': return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'hard': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  return (
    <div 
        onClick={onSelect} 
        className="group relative w-full overflow-hidden rounded-[32px] bg-surface-dark border border-white/10 shadow-lg cursor-pointer active:scale-[0.98] transition-all duration-300 hover:shadow-2xl hover:border-primary/30"
    >
      <div className="relative h-[220px] w-full overflow-hidden">
        <img
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          src={recipe.imageUrl || `https://picsum.photos/seed/${recipe.recipeName}/400/300`}
          alt={recipe.recipeName}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80"></div>
        
        <div className="absolute top-4 right-4 z-10">
            <button 
              onClick={(e) => { e.stopPropagation(); onToggleSave(recipe); }}
              className={`size-10 rounded-full flex items-center justify-center backdrop-blur-md border border-white/10 transition-all active:scale-90 ${isSaved ? 'bg-red-500/20 text-red-500' : 'bg-black/30 text-white hover:bg-white/10'}`}
            >
                <span className={`material-symbols-outlined text-[20px] ${isSaved ? 'fill-current' : ''}`} style={{fontVariationSettings: `'FILL' ${isSaved ? 1 : 0}`}}>favorite</span>
            </button>
        </div>
         <div className="absolute top-4 left-4 z-10">
            <span className={`px-3 py-1 text-[10px] font-bold uppercase tracking-wider rounded-full border backdrop-blur-md ${getDifficultyColor(recipe.difficulty)}`}>
                {recipe.difficulty}
            </span>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 p-5">
             <h3 className="text-white font-black text-2xl leading-tight drop-shadow-md line-clamp-2 mb-1 group-hover:text-primary transition-colors">
              {recipe.recipeName}
            </h3>
             <div className="flex items-center gap-2 text-white/80 text-xs font-bold uppercase tracking-wide">
                 <span className="material-symbols-outlined text-sm text-primary">schedule</span>
                 {recipe.cookTime} • {recipe.calories} kcal
             </div>
        </div>
      </div>

      <div className="p-4 grid grid-cols-3 gap-2 bg-white/[0.02] border-t border-white/5">
         <Stat icon="fitness_center" value={recipe.protein} unit="Pro" color="text-primary" />
         <Stat icon="bolt" value={recipe.carbs} unit="Carb" color="text-accent" />
         <Stat icon="water_drop" value={recipe.fat} unit="Fat" color="text-warning" />
      </div>
    </div>
  );
};

export default RecipeCard;