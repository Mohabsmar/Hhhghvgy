
import React, { useState, useEffect } from 'react';

const steps = [
  "Analyzing your ingredients...",
  "Consulting with culinary AI...",
  "Crafting unique recipes...",
  "Adding finishing touches...",
];

const GenerationLoader: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep((prev) => (prev + 1) % steps.length);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-surface-dark rounded-3xl p-8 text-center animate-fade-in transition-all duration-500">
      <div className="relative w-24 h-24 mx-auto mb-6">
        <div className="w-24 h-24 animate-icon-float">
            <span className="material-symbols-outlined text-7xl text-primary">lunch_dining</span>
        </div>
        {[...Array(3)].map((_, i) => (
            <div
                key={i}
                className="absolute inset-0 border-2 rounded-full animate-spin"
                style={{
                    borderColor: 'transparent',
                    borderTopColor: i === 0 ? 'var(--color-primary)' : i === 1 ? 'var(--color-secondary)' : '#81C784',
                    animationDelay: `-${i * 0.5}s`,
                    animationDuration: `${2 + i * 0.5}s`,
                }}
            />
        ))}
      </div>
      
      <h2 className="text-xl font-semibold text-text-dark mb-2 animate-pulse duration-1000">
        Generating Your Feast...
      </h2>
      <p className="text-text-dark-secondary mb-8">
        Our AI chef is curating the perfect dishes for you.
      </p>

      <div className="space-y-3 text-left">
        {steps.map((step, index) => (
          <div key={index} className={`flex items-center space-x-3 transition-all duration-300 ease-out ${currentStep >= index ? 'opacity-100' : 'opacity-40'}`}>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-sm transition-all duration-300 ease-out ${currentStep > index ? 'bg-success' : currentStep === index ? 'bg-primary animate-step-pulse' : 'bg-border-dark'}`}>
              <span className="material-symbols-outlined text-base">
                {currentStep > index ? 'check' : 'auto_awesome'}
              </span>
            </div>
            <span className={`text-sm transition-all duration-300 ease-out ${currentStep === index ? 'font-semibold text-primary' : currentStep > index ? 'text-text-dark' : 'text-text-dark-secondary'}`}>
              {step}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GenerationLoader;
