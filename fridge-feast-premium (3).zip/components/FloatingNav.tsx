
import React, { useState } from 'react';
import { AppScreen, Language } from '../types';
import { getTranslation } from '../constants';

interface FloatingNavProps {
  activeScreen: AppScreen;
  onNavigate: (screen: AppScreen) => void;
  lang: Language;
}

const FloatingNav: React.FC<FloatingNavProps> = ({ activeScreen, onNavigate, lang }) => {
  const [isOpen, setIsOpen] = useState(false);
  const t = (key: any) => getTranslation(lang, key);

  const menuItems = [
    { id: 'profile', icon: 'person', label: t('profile') },
    { id: 'planner', icon: 'calendar_month', label: t('planner') },
    { id: 'shopping', icon: 'shopping_cart', label: t('shop') },
    { id: 'favorites', icon: 'favorite', label: t('saved') },
    { id: 'stores', icon: 'storefront', label: t('stores') },
    { id: 'chat', icon: 'smart_toy', label: 'CalBot' },
    { id: 'scanner', icon: 'center_focus_weak', label: t('scan') },
    { id: 'home', icon: 'home', label: t('home') },
  ];

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end pointer-events-none safe-area-bottom">
      
      {/* Expanded Menu Items */}
      <div className={`flex flex-col items-end gap-3 mb-4 transition-all duration-300 ${isOpen ? 'pointer-events-auto' : 'pointer-events-none'}`}>
        {menuItems.map((item, index) => {
            const isOpenStyle = {
                opacity: 1,
                transform: 'translateY(0) scale(1)',
                transitionDelay: `${index * 40}ms`
            };
            const isClosedStyle = {
                opacity: 0,
                transform: 'translateY(10px) scale(0.9)',
                transitionDelay: `${(menuItems.length - 1 - index) * 30}ms`
            };

            const isActive = activeScreen === item.id;

            return (
                <div 
                    key={item.id} 
                    className="flex items-center gap-3 transition-all duration-300"
                    style={isOpen ? isOpenStyle : isClosedStyle}
                >
                    <span className="text-white text-xs font-bold bg-background-dark/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 shadow-lg">
                        {item.label}
                    </span>
                    
                    <button
                        onClick={() => {
                            onNavigate(item.id as AppScreen);
                            setIsOpen(false);
                        }}
                        className={`size-12 rounded-full flex items-center justify-center transition-all duration-200 active:scale-95 shadow-lg border ${isActive ? 'bg-primary text-white border-primary' : 'bg-surface-dark/90 text-white/80 border-white/10 hover:bg-white/10'}`}
                    >
                        <span className="material-symbols-outlined text-[20px]">
                            {item.icon}
                        </span>
                    </button>
                </div>
            );
        })}
      </div>

      {/* Main Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`pointer-events-auto size-14 rounded-full shadow-xl flex items-center justify-center transition-all duration-300 active:scale-90 border relative overflow-hidden group z-50 backdrop-blur-md ${isOpen ? 'bg-white text-black border-white' : 'bg-primary text-white border-primary'}`}
      >
         <div className="relative size-6 flex items-center justify-center">
             <span 
                className={`material-symbols-outlined text-2xl absolute transition-all duration-300 ${isOpen ? 'rotate-90 opacity-0' : 'rotate-0 opacity-100'}`}
            >
                menu
            </span>
            <span 
                className={`material-symbols-outlined text-2xl absolute transition-all duration-300 ${isOpen ? 'rotate-0 opacity-100' : '-rotate-90 opacity-0'}`}
            >
                close
            </span>
         </div>
      </button>

      {/* Backdrop */}
      {isOpen && (
          <div 
            className="fixed inset-0 z-40 pointer-events-auto bg-black/40 backdrop-blur-[2px] transition-opacity duration-300"
            onClick={() => setIsOpen(false)}
          ></div>
      )}
    </div>
  );
};

export default FloatingNav;
