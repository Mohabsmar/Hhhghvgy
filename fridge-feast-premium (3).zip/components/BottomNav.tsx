
import React from 'react';
import { AppScreen, Language, NavBarConfig } from '../types';
import { getTranslation } from '../constants';

interface BottomNavProps {
  activeScreen: AppScreen;
  onNavigate: (screen: AppScreen) => void;
  lang: Language;
  config: NavBarConfig;
  isPreview?: boolean;
}

const BottomNav: React.FC<BottomNavProps> = ({ activeScreen, onNavigate, lang, config, isPreview = false }) => {
  const t = (key: any) => getTranslation(lang, key);

  const navItems = [
    { id: 'home', icon: 'home', label: t('home') },
    { id: 'discover', icon: 'kitchen', label: 'Recipes' },
    { id: 'scanner', icon: 'center_focus_weak', label: t('scan') },
    { id: 'chat', icon: 'smart_toy', label: 'Chef AI' },
    { id: 'profile', icon: 'person', label: t('profile') },
  ];

  const hexToRgba = (hex: string, opacity: number) => {
        let c: any;
        if(/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)){
            c= hex.substring(1).split('');
            if(c.length== 3){
                c= [c[0], c[0], c[1], c[1], c[2], c[2]];
            }
            c= '0x'+c.join('');
            return 'rgba('+[(c>>16)&255, (c>>8)&255, c&255].join(',')+','+(opacity/100)+')';
        }
        return hex;
  }

  const isFixed = config.style === 'fixed';
  
  const baseStyle: React.CSSProperties = {
      width: isFixed ? '100%' : `${config.width}%`,
      maxWidth: isFixed ? '100%' : '450px',
      zIndex: 40,
      transition: 'all 300ms cubic-bezier(0.25, 0.8, 0.25, 1)',
  };

  const positioningStyle: React.CSSProperties = {};
  if (config.containerPosition === 'center') {
      positioningStyle.left = 0;
      positioningStyle.right = 0;
      positioningStyle.marginLeft = 'auto';
      positioningStyle.marginRight = 'auto';
      if (config.horizontalOffset) positioningStyle.transform = `translateX(${config.horizontalOffset}px)`;
  } else if (config.containerPosition === 'right') {
      positioningStyle.right = isFixed ? 0 : `${config.horizontalOffset || 0}px`;
      positioningStyle.left = 'auto';
  } else {
      positioningStyle.left = isFixed ? 0 : `${config.horizontalOffset || 0}px`;
      positioningStyle.right = 'auto';
  }

  if (config.verticalPosition === 'top') {
      positioningStyle.top = isFixed ? 0 : `${config.bottomOffset}px`;
      positioningStyle.bottom = 'auto';
  } else {
      positioningStyle.bottom = isFixed ? 0 : `${config.bottomOffset}px`;
      positioningStyle.top = 'auto';
  }

  const containerStyle: React.CSSProperties = {
      position: isPreview ? 'absolute' : 'fixed',
      ...baseStyle,
      ...positioningStyle,
  };

  const barStyle: React.CSSProperties = {
      height: isFixed ? `calc(${config.height}px + env(safe-area-inset-bottom))` : `${config.height}px`,
      paddingBottom: isFixed ? 'env(safe-area-inset-bottom)' : '0',
      background: config.blurEffect 
        ? `rgba(15, 15, 20, ${config.backgroundOpacity / 100})` 
        : hexToRgba(config.backgroundColor, config.backgroundOpacity),
      borderRadius: isFixed ? '0' : '9999px',
      border: `${config.borderWidth}px solid rgba(255, 255, 255, 0.1)`,
      backdropFilter: config.blurEffect ? 'blur(40px) saturate(180%)' : 'none',
      WebkitBackdropFilter: config.blurEffect ? 'blur(40px) saturate(180%)' : 'none',
      boxShadow: '0 20px 50px rgba(0,0,0,0.5), inset 0 1px 1px 0 rgba(255, 255, 255, 0.15)',
  };

  return (
    <div className={!isPreview ? 'animate-slide-up' : ''} style={containerStyle}>
         <div className="flex justify-between items-center relative transition-all duration-300 px-4 overflow-hidden" style={barStyle}>
             {navItems.map((item) => {
                const isActive = activeScreen === item.id;
                return (
                     <button
                        key={item.id}
                        onClick={() => onNavigate(item.id as AppScreen)}
                        className={`flex-1 flex flex-col items-center justify-center transition-all duration-300 h-full relative outline-none select-none`}
                        style={{ color: isActive ? config.activeIconColor : config.iconColor }}
                    >
                        <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-primary/10 blur-xl transition-opacity duration-500 ${isActive ? 'opacity-100' : 'opacity-0'}`}></div>
                        <div className={`relative transition-all duration-300 z-10 ${isActive ? '-translate-y-1 scale-110' : 'hover:text-white'}`}>
                            <span className="material-symbols-outlined" style={{ fontVariationSettings: `'FILL' ${isActive ? 1 : 0}, 'wght' ${isActive ? 600 : 400}`, fontSize: '28px' }}>
                                {item.icon}
                            </span>
                        </div>
                        {config.showLabels && (
                            <span className={`text-[10px] font-bold mt-1 transition-all z-10 ${isActive ? 'opacity-100 text-white' : 'opacity-40'}`}>
                                {item.label}
                            </span>
                        )}
                    </button>
                )
             })}
         </div>
    </div>
  );
};

export default BottomNav;
