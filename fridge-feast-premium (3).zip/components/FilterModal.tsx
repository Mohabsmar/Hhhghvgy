
import React from 'react';
import { Filters } from '../types';
import { DIETARY_OPTIONS, CUISINE_OPTIONS, DIFFICULTY_OPTIONS } from '../constants';
import FilterTag from './common/recipe_generator/FilterTag';

interface FilterModalProps {
  isOpen: boolean;
  onClose: () => void;
  filters: Filters;
  setFilters: React.Dispatch<React.SetStateAction<Filters>>;
}

const FilterSection: React.FC<{title: string, children: React.ReactNode}> = ({title, children}) => (
    <div className="space-y-4">
        <h3 className="text-xs font-black text-white/30 uppercase tracking-[0.4em] px-6">{title}</h3>
        <div 
            className="snap-carousel no-scrollbar px-6 gap-3 pb-2" 
            data-scrollable="true"
        >
            {children}
        </div>
    </div>
);

const FilterModal: React.FC<FilterModalProps> = ({ isOpen, onClose, filters, setFilters }) => {
  if (!isOpen) return null;

  const handleMultiSelect = (label: string, category: 'dietary' | 'cuisine' | 'difficulty') => {
    setFilters(prev => {
        const currentCategoryFilters = prev[category];
        const isSelected = currentCategoryFilters.includes(label);
        const newCategoryFilters = isSelected 
            ? currentCategoryFilters.filter(item => item !== label)
            : [...currentCategoryFilters, label];
        return { ...prev, [category]: newCategoryFilters };
    });
  };

  const activeFilterCount = filters.dietary.length + filters.cuisine.length + filters.difficulty.length + (filters.time ? 1 : 0);
  
  const resetFilters = () => {
    setFilters({ dietary: [], cuisine: [], difficulty: [], time: ''});
  };

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-3xl z-[70] flex flex-col font-display animate-reveal" role="dialog" aria-modal="true">
      <header className="flex items-center justify-between p-6 pt-safe-top border-b border-white/5 flex-shrink-0">
        <button onClick={onClose} className="size-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white">
            <span className="material-symbols-outlined">close</span>
        </button>
        <h2 className="text-lg font-black uppercase tracking-widest">Atelier Filters</h2>
        <button onClick={resetFilters} className="text-[10px] font-black text-primary uppercase tracking-widest disabled:opacity-30" disabled={activeFilterCount === 0}>Reset</button>
      </header>

      <main className="flex-1 py-8 space-y-12 overflow-y-auto no-scrollbar">
        <FilterSection title="Dietary Preferences">
             {DIETARY_OPTIONS.map(opt => <FilterTag key={opt} label={opt} isSelected={filters.dietary.includes(opt)} onClick={(label) => handleMultiSelect(label, 'dietary')} />)}
        </FilterSection>
         <FilterSection title="Cuisine DNA">
             {CUISINE_OPTIONS.map(opt => <FilterTag key={opt} label={opt} isSelected={filters.cuisine.includes(opt)} onClick={(label) => handleMultiSelect(label, 'cuisine')} />)}
        </FilterSection>
        <FilterSection title="Technical Level">
             {DIFFICULTY_OPTIONS.map(opt => <FilterTag key={opt} label={opt} isSelected={filters.difficulty.includes(opt)} onClick={(label) => handleMultiSelect(label, 'difficulty')} />)}
        </FilterSection>
      </main>

      <footer className="p-8 border-t border-white/5 safe-area-bottom">
         <button 
            onClick={onClose}
            className="w-full h-16 rounded-full bg-primary text-black font-black text-xs uppercase tracking-[0.3em] flex items-center justify-center shadow-2xl shadow-primary/20 active:scale-[0.98] transition-all"
        >
           Apply Selection {activeFilterCount > 0 ? `(${activeFilterCount})` : ''}
        </button>
      </footer>
    </div>
  );
};

export default FilterModal;
