
import React from 'react';

// Status bar feature has been removed.
const CustomStatusBar: React.FC<any> = () => {
    return null;
};

export default CustomStatusBar;
