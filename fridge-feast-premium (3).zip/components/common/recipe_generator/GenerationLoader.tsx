
import React, { useState, useEffect } from 'react';

const steps = [
  "Checking your ingredients...",
  "Looking for delicious recipes...",
  "Planning the steps...",
  "Preparing your ideas...",
];

const GenerationLoader: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep((prev) => (prev + 1) % steps.length);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="liquid-panel rounded-[48px] p-12 text-center animate-reveal border border-white/5 shadow-2xl relative overflow-hidden bg-black/40">
      <div className="relative size-32 mx-auto mb-10 flex items-center justify-center">
        <div className="absolute inset-0 border-2 border-primary/20 rounded-full animate-spin-slow"></div>
        <div className="absolute inset-4 border border-secondary/20 rounded-full animate-spin" style={{ animationDirection: 'reverse' }}></div>
        <div className="size-20 rounded-[24px] bg-black border border-white/10 flex items-center justify-center shadow-lg relative z-10">
            <span className="material-symbols-outlined text-5xl text-white animate-pulse">auto_awesome</span>
        </div>
      </div>
      
      <div className="space-y-2">
        <h2 className="text-2xl font-black text-white tracking-tight">Creating your recipe...</h2>
        <p className="text-primary text-[10px] font-bold uppercase tracking-widest opacity-60">Almost there</p>
      </div>

      <div className="max-w-xs mx-auto space-y-4 mt-8">
        {steps.map((step, index) => {
          const isActive = currentStep === index;
          return (
            <div key={index} className={`flex items-center gap-4 transition-all duration-500 ${isActive ? 'scale-105' : 'opacity-40'}`}>
                <div className={`size-2 rounded-full transition-all ${isActive ? 'bg-primary scale-125' : 'bg-white/20'}`}></div>
                <span className={`text-xs font-bold uppercase tracking-wider text-left ${isActive ? 'text-white' : 'text-white/40'}`}>{step}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default GenerationLoader;
