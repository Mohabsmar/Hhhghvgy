
import React, { useState } from 'react';
import { Recipe } from '../../../types';

interface RecipeCardProps {
  recipe: Recipe;
  onSelect: () => void;
  isSaved: boolean;
  onToggleSave: (recipe: Recipe) => void;
}

const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, onSelect, isSaved, onToggleSave }) => {
  const [imgLoaded, setImgLoaded] = useState(false);
  const [imgError, setImgError] = useState(false);

  const diffStyles = {
    Easy: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    Medium: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
    Hard: 'bg-red-500/10 text-red-400 border-red-500/20'
  };

  const fallbackImage = `https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80`;

  return (
    <div 
        onClick={onSelect} 
        className="group relative w-full aspect-[16/11] overflow-hidden rounded-[40px] obsidian-glass cursor-pointer active:scale-[0.98] transition-all duration-500 hover:border-primary/40"
    >
      {/* Loading Skeleton */}
      {!imgLoaded && !imgError && (
          <div className="absolute inset-0 bg-white/5 animate-pulse flex items-center justify-center">
              <span className="material-symbols-outlined text-4xl text-white/10 animate-spin">progress_activity</span>
          </div>
      )}

      <img
        className={`size-full object-cover transition-all duration-1000 group-hover:scale-110 ${imgLoaded ? 'opacity-100' : 'opacity-0'}`}
        src={imgError ? fallbackImage : (recipe.imageUrl || fallbackImage)}
        alt={recipe.recipeName}
        onLoad={() => setImgLoaded(true)}
        onError={() => { setImgError(true); setImgLoaded(true); }}
        loading="lazy"
      />
      
      {/* High-Contrast Dynamic Overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent opacity-90 transition-opacity group-hover:opacity-80"></div>
      
      <div className="absolute top-5 right-5 z-10">
          <button 
            onClick={(e) => { e.stopPropagation(); onToggleSave(recipe); }}
            className={`size-12 rounded-full flex items-center justify-center backdrop-blur-2xl border transition-all active:scale-90 ${isSaved ? 'bg-red-500/20 text-red-500 border-red-500/30' : 'bg-black/40 border-white/10 text-white hover:bg-white/10'}`}
          >
              <span className="material-symbols-outlined text-[20px]" style={{fontVariationSettings: `'FILL' ${isSaved ? 1 : 0}, 'wght' 600`}}>favorite</span>
          </button>
      </div>

       <div className="absolute top-5 left-5 z-10">
          <div className={`px-4 py-1.5 text-[9px] font-black uppercase tracking-[0.2em] rounded-full border backdrop-blur-2xl shadow-lg ${diffStyles[recipe.difficulty]}`}>
              {recipe.difficulty}
          </div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 p-6 space-y-3">
           <div className="space-y-1">
                <h3 className="text-3xl font-black text-white leading-[0.95] tracking-tighter drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)] group-hover:text-primary transition-colors duration-300 line-clamp-2">
                    {recipe.recipeName}
                </h3>
                <p className="text-white/60 text-[10px] font-bold uppercase tracking-widest line-clamp-1">{recipe.description || 'Gourmet experience curated by AI.'}</p>
           </div>

           <div className="flex items-center gap-4 pt-2">
               <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/5 backdrop-blur-md">
                   <span className="material-symbols-outlined text-sm text-primary">schedule</span>
                   <span className="text-white/90 text-[10px] font-black uppercase tracking-widest">{recipe.cookTime}</span>
               </div>
               <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/5 backdrop-blur-md">
                   <span className="material-symbols-outlined text-sm text-secondary">bolt</span>
                   <span className="text-white/90 text-[10px] font-black uppercase tracking-widest">{recipe.calories} kcal</span>
               </div>
           </div>
      </div>

      {/* Shine effect on hover */}
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-tr from-white/0 via-white/5 to-white/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
    </div>
  );
};

export default RecipeCard;
