
import React from 'react';

interface FilterTagProps {
  label: string;
  isSelected: boolean;
  onClick: (label: string) => void;
}

const FilterTag: React.FC<FilterTagProps> = ({ label, isSelected, onClick }) => {
  const baseClasses = "flex h-10 shrink-0 items-center justify-center gap-x-2 rounded-full px-4 text-sm font-medium transition-all duration-200 ease-out";
  const selectedClasses = "bg-primary/20 text-primary border-primary/0";
  const unselectedClasses = "bg-surface-dark border border-border-dark text-text-dark-secondary hover:border-primary hover:text-primary";

  return (
    <button
      onClick={() => onClick(label)}
      className={`${baseClasses} ${isSelected ? selectedClasses : unselectedClasses}`}
    >
      <p className="leading-normal">{label}</p>
      {isSelected && <span className="material-symbols-outlined text-xl">check</span>}
    </button>
  );
};

export default FilterTag;
