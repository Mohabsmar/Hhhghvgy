
import React from 'react';

const DietaryReportScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Dietary Report</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6 overflow-y-auto">
                <div className="p-6 rounded-[32px] bg-gradient-to-br from-green-500/20 to-teal-500/20 border border-green-500/30 text-center">
                    <h2 className="text-5xl font-black text-white mb-2">A+</h2>
                    <p className="text-sm font-bold text-green-300 uppercase tracking-widest">Nutrition Score</p>
                </div>
                
                <div className="liquid-panel p-6 rounded-[32px] border border-white/5">
                    <h3 className="font-bold text-white mb-4">Macro Trends</h3>
                    <div className="space-y-4">
                        {['Protein', 'Carbs', 'Fats'].map(m => (
                            <div key={m}>
                                <div className="flex justify-between text-xs font-bold text-text-dark-secondary mb-1">
                                    <span>{m}</span>
                                    <span>On Target</span>
                                </div>
                                <div className="h-3 bg-white/5 rounded-full overflow-hidden">
                                    <div className="h-full bg-primary w-[70%]"></div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </main>
        </div>
    );
};
export default DietaryReportScreen;
