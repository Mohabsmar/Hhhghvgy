
import React, { useState, useEffect } from 'react';
import { Recipe, Language } from '../../../types';
import { getTranslation } from '../../../constants';

interface MealPlannerScreenProps {
    onSelectRecipe: (recipe: Recipe) => void;
    savedRecipes: Recipe[];
    lang: Language;
}

const STORAGE_KEY = 'stitch_meal_plan';
const mealTypes = ['Breakfast', 'Lunch', 'Dinner'];

// Date Utilities
const formatDateKey = (date: Date) => date.toISOString().split('T')[0]; // YYYY-MM-DD
const getStartOfWeek = (date: Date) => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Adjust when day is sunday
    return new Date(d.setDate(diff));
};
const addDays = (date: Date, days: number) => {
    const d = new Date(date);
    d.setDate(d.getDate() + days);
    return d;
};

const MealPlannerScreen: React.FC<MealPlannerScreenProps> = ({ onSelectRecipe, savedRecipes, lang }) => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [plannedMeals, setPlannedMeals] = useState<Record<string, Recipe>>({}); 
    const [view, setView] = useState<'Day' | 'Week'>('Week');
    const [loaded, setLoaded] = useState(false);
    
    // Picker State
    const [isYearPickerOpen, setIsYearPickerOpen] = useState(false);
    const [activeSlot, setActiveSlot] = useState<{date: string, type: string} | null>(null);
    const t = (key: any) => getTranslation(lang, key);

    // Load persistence
    useEffect(() => {
        try {
            const stored = localStorage.getItem(STORAGE_KEY);
            if (stored) {
                setPlannedMeals(JSON.parse(stored));
            }
        } catch (e) {
            console.error("Failed to load meal plan");
        } finally {
            setLoaded(true);
        }
    }, []);

    // Save persistence
    useEffect(() => {
        if (loaded) {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(plannedMeals));
        }
    }, [plannedMeals, loaded]);

    // Generate Week Days
    const startOfWeek = getStartOfWeek(currentDate);
    const weekDays = Array.from({ length: 7 }).map((_, i) => addDays(startOfWeek, i));

    const handleYearChange = (year: number) => {
        const newDate = new Date(currentDate);
        newDate.setFullYear(year);
        setCurrentDate(newDate);
        setIsYearPickerOpen(false);
    };

    const handleAddRecipeToSlot = (recipe: Recipe) => {
        if (activeSlot) {
            const key = `${activeSlot.date}-${activeSlot.type}`;
            setPlannedMeals(prev => ({ ...prev, [key]: recipe }));
            setActiveSlot(null);
        }
    };

    const handleRemoveMeal = (dateStr: string, type: string, e: React.MouseEvent) => {
        e.stopPropagation();
        const key = `${dateStr}-${type}`;
        const newMeals = { ...plannedMeals };
        delete newMeals[key];
        setPlannedMeals(newMeals);
    };

    const MealSlot: React.FC<{date: Date, type: string}> = ({date, type}) => {
        const dateStr = formatDateKey(date);
        const key = `${dateStr}-${type}`;
        const recipe = plannedMeals[key];

        return (
            <div className="ios-list-item h-[88px] !p-0 overflow-hidden active:bg-surface-dark-secondary transition-colors group relative border-b border-white/5 last:border-none">
                {recipe ? (
                    <button 
                        onClick={() => onSelectRecipe(recipe)} 
                        className="w-full h-full flex items-center px-4 gap-4 text-left"
                    >
                        <img src={recipe.imageUrl} alt={recipe.recipeName} className="size-14 object-cover rounded-2xl bg-surface-dark-secondary border border-white/10 shadow-sm"/>
                        <div className="min-w-0 flex-1">
                            <p className="text-[12px] font-bold text-primary uppercase tracking-wide mb-0.5">{type}</p>
                            <p className="text-[16px] font-bold text-white truncate leading-tight">{recipe.recipeName}</p>
                            <p className="text-[13px] text-text-dark-secondary mt-0.5">{recipe.calories} kcal • {recipe.cookTime}</p>
                        </div>
                        <div 
                            onClick={(e) => handleRemoveMeal(dateStr, type, e)}
                            className="size-10 flex items-center justify-center text-text-dark-secondary hover:text-error transition-colors bg-white/5 rounded-full"
                        >
                            <span className="material-symbols-outlined text-xl">remove</span>
                        </div>
                    </button>
                ) : (
                    <button 
                        onClick={() => setActiveSlot({date: dateStr, type})}
                        className="w-full h-full flex items-center px-4 gap-4 text-left group-active:bg-white/5"
                    >
                        <div className="size-14 rounded-2xl border border-dashed border-white/20 flex items-center justify-center bg-white/5 group-hover:border-primary/50 group-hover:bg-primary/10 transition-colors">
                             <span className="material-symbols-outlined text-text-dark-secondary group-hover:text-primary">add</span>
                        </div>
                        <div>
                            <p className="text-[12px] font-bold text-text-dark-secondary uppercase tracking-wide mb-0.5">{type}</p>
                            <span className="text-[16px] font-medium text-white/40">Plan a meal</span>
                        </div>
                    </button>
                )}
            </div>
        );
    };

    // Generate Year Options
    const currentYear = new Date().getFullYear();
    const yearOptions = Array.from({ length: 11 }).map((_, i) => currentYear - 5 + i);

    return (
        <div className="min-h-screen relative pb-32 font-display">
             <header className="px-4 pt-safe-top pb-2 liquid-glass sticky top-0 z-30 border-b border-white/10 rounded-b-[40px]">
                 <div className="flex justify-between items-center h-12">
                     <div className="flex items-center gap-1 text-white" onClick={() => setIsYearPickerOpen(true)}>
                        <span className="text-[22px] font-bold cursor-pointer">{currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span>
                        <span className="material-symbols-outlined text-lg pt-1 text-primary">expand_more</span>
                     </div>
                     <div className="flex bg-white/10 rounded-full p-1">
                         <button 
                            onClick={() => setView('Day')}
                            className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${view === 'Day' ? 'bg-white text-black shadow-sm' : 'text-white/60'}`}
                        >
                             Day
                         </button>
                         <button 
                            onClick={() => setView('Week')}
                            className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${view === 'Week' ? 'bg-white text-black shadow-sm' : 'text-white/60'}`}
                        >
                             Week
                         </button>
                     </div>
                 </div>
                 
                 {/* Calendar Strip */}
                 <div className="flex justify-between items-center py-4">
                    {weekDays.map(day => {
                        const isSelected = formatDateKey(day) === formatDateKey(currentDate);
                        const isToday = formatDateKey(day) === formatDateKey(new Date());
                        
                        return (
                            <button 
                                key={day.toISOString()}
                                onClick={() => setCurrentDate(day)}
                                className={`flex flex-col items-center justify-center w-[13.5%] h-[68px] rounded-[24px] transition-all duration-300 ${isSelected ? 'bg-primary shadow-[0_0_15px_rgba(16,185,129,0.4)] scale-105' : 'bg-white/5 hover:bg-white/10 border border-white/5'}`}
                            >
                                <span className={`text-[10px] font-bold uppercase mb-1 ${isSelected ? 'text-white/90' : 'text-text-dark-secondary'}`}>
                                    {day.toLocaleDateString('en-US', { weekday: 'short' }).charAt(0)}
                                </span>
                                <span className={`text-[18px] font-bold leading-none ${isSelected ? 'text-white' : isToday ? 'text-primary' : 'text-white'}`}>
                                    {day.getDate()}
                                </span>
                                {isToday && !isSelected && <div className="w-1 h-1 rounded-full bg-primary mt-1.5 shadow-[0_0_5px_#10B981]"></div>}
                            </button>
                        )
                    })}
                 </div>
             </header>

            <div className="px-4 mt-6 space-y-8">
                {(view === 'Week' ? weekDays : [currentDate]).map(day => {
                    const dateKey = formatDateKey(day);
                    const isToday = dateKey === formatDateKey(new Date());
                    const isSelected = dateKey === formatDateKey(currentDate);

                    // In week view, only show selected day expanded
                    if (view === 'Week' && !isSelected) return null;

                    return (
                        <div key={day.toISOString()} className="animate-slide-up">
                            <div className="flex items-baseline justify-between mb-3 px-2">
                                <h3 className="text-white text-[18px] font-bold">
                                    {isToday ? 'Today\'s Plan' : day.toLocaleDateString('en-US', { weekday: 'long' })}
                                </h3>
                                <span className="text-xs font-medium text-text-dark-secondary uppercase tracking-wider">{day.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                            </div>
                            
                            <div className="ios-list-group liquid-panel border border-white/10 !rounded-[40px]">
                                {mealTypes.map(type => (
                                    <MealSlot key={type} date={day} type={type} />
                                ))}
                            </div>
                        </div>
                    );
                })}
                
                {/* Stats Summary */}
                 <div className="p-5 rounded-[40px] liquid-panel border border-white/5 shadow-lg">
                     <h4 className="text-xs font-bold text-text-dark-secondary uppercase tracking-wider mb-4">Daily Nutrition Target</h4>
                     <div className="flex justify-between items-end gap-4">
                         <div className="flex flex-col gap-1">
                             <span className="text-2xl font-black text-white">1,250</span>
                             <span className="text-xs font-medium text-white/50">Calories consumed</span>
                         </div>
                         <div className="h-12 w-px bg-white/10"></div>
                         <div className="flex gap-3">
                             <div className="text-center">
                                 <div className="size-10 rounded-full border-4 border-primary/30 border-t-primary flex items-center justify-center text-[10px] font-bold text-white">65g</div>
                                 <span className="text-[9px] text-text-dark-secondary mt-1 block">PRO</span>
                             </div>
                             <div className="text-center">
                                 <div className="size-10 rounded-full border-4 border-accent/30 border-t-accent flex items-center justify-center text-[10px] font-bold text-white">120g</div>
                                 <span className="text-[9px] text-text-dark-secondary mt-1 block">CARB</span>
                             </div>
                         </div>
                     </div>
                 </div>
            </div>

            {/* Year Picker Modal */}
            {isYearPickerOpen && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-6 animate-fade-in" onClick={() => setIsYearPickerOpen(false)}>
                    <div className="bg-[#1C1C1E] w-full max-w-xs rounded-[40px] overflow-hidden border border-white/10 shadow-2xl" onClick={e => e.stopPropagation()}>
                         <div className="h-14 flex items-center justify-center border-b border-white/5 bg-white/5">
                             <span className="font-bold text-white">Select Year</span>
                         </div>
                        <div className="h-[300px] overflow-y-auto no-scrollbar p-2">
                            {yearOptions.map(year => (
                                <button 
                                    key={year}
                                    onClick={() => handleYearChange(year)}
                                    className={`w-full py-3 rounded-full font-bold text-[16px] transition-all ${year === currentDate.getFullYear() ? 'text-black bg-primary' : 'text-white hover:bg-white/5'}`}
                                >
                                    {year}
                                </button>
                            ))}
                        </div>
                        <button onClick={() => setIsYearPickerOpen(false)} className="w-full py-4 text-text-dark-secondary font-bold text-[15px] border-t border-white/5 hover:text-white transition-colors">
                            Close
                        </button>
                    </div>
                </div>
            )}

            {/* Add Recipe Modal */}
            {activeSlot && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-end sm:items-center justify-center animate-fade-in" onClick={() => setActiveSlot(null)}>
                    <div className="liquid-panel w-full max-w-md sm:rounded-[40px] rounded-t-[40px] h-[85vh] sm:h-[70vh] flex flex-col shadow-2xl animate-slide-up overflow-hidden border border-white/10" onClick={e => e.stopPropagation()}>
                        <div className="h-16 flex items-center justify-between px-6 border-b border-white/10 bg-white/5">
                            <button onClick={() => setActiveSlot(null)} className="text-text-dark-secondary hover:text-white transition-colors font-medium">Cancel</button>
                            <span className="font-bold text-white text-lg">Add to {activeSlot.type}</span>
                            <div className="w-10"></div>
                        </div>
                        
                        <div className="p-4 bg-white/5">
                             <div className="relative group">
                                <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-text-dark-secondary group-focus-within:text-primary transition-colors">search</span>
                                <input 
                                    type="text" 
                                    placeholder="Search cookbooks..."
                                    className="w-full h-12 bg-black/40 rounded-full pl-10 pr-4 text-white placeholder:text-text-dark-secondary/50 focus:outline-none focus:ring-1 focus:ring-primary border border-white/10 transition-all"
                                />
                            </div>
                        </div>

                        <div className="flex-1 overflow-y-auto p-4">
                            {savedRecipes.length > 0 ? (
                                <div className="space-y-3">
                                    {savedRecipes.map((recipe, idx) => (
                                        <div 
                                            key={recipe.id} 
                                            onClick={() => handleAddRecipeToSlot(recipe)}
                                            className="flex items-center gap-4 p-3 rounded-2xl bg-surface-dark border border-white/5 active:scale-[0.98] transition-all hover:border-primary/50 cursor-pointer"
                                        >
                                            <img src={recipe.imageUrl} className="size-16 rounded-xl object-cover bg-surface-dark-secondary" />
                                            <div className="flex-1 min-w-0">
                                                <h4 className="font-bold text-white text-[16px] truncate">{recipe.recipeName}</h4>
                                                <div className="flex items-center gap-3 mt-1">
                                                    <span className="text-xs font-bold text-primary bg-primary/10 px-2 py-0.5 rounded-md">{recipe.calories} kcal</span>
                                                    <span className="text-xs text-text-dark-secondary">{recipe.cookTime}</span>
                                                </div>
                                            </div>
                                            <button className="size-8 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-primary hover:text-black transition-colors">
                                                <span className="material-symbols-outlined text-xl">add</span>
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="flex flex-col items-center justify-center h-64 text-text-dark-secondary opacity-50">
                                    <span className="material-symbols-outlined text-5xl mb-4">bookmark_border</span>
                                    <p className="font-medium">No saved recipes found.</p>
                                    <p className="text-xs mt-1">Save recipes to plan them.</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default MealPlannerScreen;
