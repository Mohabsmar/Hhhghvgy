
import React, { useState, useRef, useEffect } from 'react';
import { analyzeFoodImage, identifyFridgeIngredients } from '../../../common/geminiService';
import { ScanResult, Language, UserPreferences, AppAction } from '../../../types';
import Spinner from '../Spinner';
import { getTranslation } from '../../../constants';

interface FoodScannerScreenProps {
    onExit: () => void;
    onIngredientsFound?: (ingredients: string[]) => void;
    lang: Language;
    preferences?: UserPreferences; 
    onUpdatePreferences?: (prefs: Partial<UserPreferences>) => void; 
    onAction?: (action: AppAction) => void; 
}

type ScanMode = 'nutrition' | 'fridge';
type Tab = 'overview' | 'all';

const FoodScannerScreen: React.FC<FoodScannerScreenProps> = ({ onExit, onIngredientsFound, lang, preferences, onUpdatePreferences, onAction }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [image, setImage] = useState<string | null>(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [mode, setMode] = useState<ScanMode>('nutrition');
    const [activeTab, setActiveTab] = useState<Tab>('overview');
    const [scanResult, setScanResult] = useState<ScanResult | null>(null);
    const [fridgeIngredients, setFridgeIngredients] = useState<string[]>([]);
    const t = (key: any) => getTranslation(lang, key);

    useEffect(() => {
        const startCamera = async () => {
            try {
                const mediaStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
                setStream(mediaStream);
                if (videoRef.current) videoRef.current.srcObject = mediaStream;
            } catch (err) { console.error("Camera Error:", err); }
        };
        if (!image) startCamera();
        return () => { if (stream) stream.getTracks().forEach(track => track.stop()); };
    }, [image]);

    const captureImage = () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d')?.drawImage(video, 0, 0);
            const base64 = canvas.toDataURL('image/jpeg');
            setImage(base64);
            handleAnalyze(base64.split(',')[1]);
        }
    };

    const handleAnalyze = async (base64: string) => {
        setIsAnalyzing(true);
        try {
            if (mode === 'nutrition') {
                const data = await analyzeFoodImage(base64, lang);
                // Fallback mock data if AI misses macros
                if (!data.protein) data.protein = Math.floor(Math.random() * 30) + 5;
                if (!data.carbs) data.carbs = Math.floor(Math.random() * 50) + 10;
                if (!data.fat) data.fat = Math.floor(Math.random() * 20) + 2;
                setScanResult(data);
            } else {
                const ingredients = await identifyFridgeIngredients(base64, lang);
                setFridgeIngredients(ingredients);
            }
        } catch (error) {
            console.error(error);
            alert("Analysis failed. Try again.");
            setImage(null);
        } finally {
            setIsAnalyzing(false);
        }
    };

    const reset = () => {
        setImage(null);
        setScanResult(null);
        setFridgeIngredients([]);
        setActiveTab('overview');
    };

    const renderNutritionChart = () => {
        if (!scanResult || !preferences) return null;
        const { protein = 0, carbs = 0, fat = 0 } = scanResult;
        const { nutritionDisplay, nutritionUnit, nutritionChartType } = preferences;

        const P_CAL = 4, C_CAL = 4, F_CAL = 9;
        let valP = protein, valC = carbs, valF = fat, unitLabel = 'g';

        if (nutritionUnit === 'calories') {
            valP = protein * P_CAL;
            valC = carbs * C_CAL;
            valF = fat * F_CAL;
            unitLabel = 'kcal';
        }

        const total = valP + valC + valF;
        const pctP = total > 0 ? valP / total : 0;
        const pctC = total > 0 ? valC / total : 0;
        const pctF = total > 0 ? valF / total : 0;

        const formatValue = (val: number, pct: number) => nutritionDisplay === 'percentage' ? `${Math.round(pct * 100)}%` : `${Math.round(val)}${unitLabel}`;

        const ChartControls = () => (
             <div className="flex gap-2 mb-6 flex-wrap justify-center mt-4">
                 <button onClick={() => onUpdatePreferences?.({ nutritionChartType: nutritionChartType === 'bar' ? 'donut' : 'bar' })} className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-[10px] font-bold text-white hover:bg-white/10 uppercase tracking-wide flex items-center gap-1"><span className="material-symbols-outlined text-sm">{nutritionChartType === 'bar' ? 'donut_large' : 'bar_chart'}</span>Style</button>
                 <button onClick={() => onUpdatePreferences?.({ nutritionDisplay: nutritionDisplay === 'percentage' ? 'numbers' : 'percentage' })} className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-[10px] font-bold text-white hover:bg-white/10 uppercase tracking-wide">{nutritionDisplay === 'percentage' ? 'Values' : '%'}</button>
                 <button onClick={() => onUpdatePreferences?.({ nutritionUnit: nutritionUnit === 'weight' ? 'calories' : 'weight' })} className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-[10px] font-bold text-white hover:bg-white/10 uppercase tracking-wide">{nutritionUnit === 'weight' ? 'Kcal' : 'Gram'}</button>
            </div>
        );

        if (nutritionChartType === 'bar') {
            const maxVal = Math.max(valP, valC, valF) || 1;
            return (
                <div className="w-full flex flex-col items-center">
                    <div className="w-full space-y-4 px-2">
                        {[{l: 'Protein', v: valP, p: pctP, c: 'bg-primary', t: 'text-primary'}, {l: 'Carbs', v: valC, p: pctC, c: 'bg-accent', t: 'text-accent'}, {l: 'Fat', v: valF, p: pctF, c: 'bg-warning', t: 'text-warning'}].map((item, i) => (
                            <div key={i} className="flex items-center gap-3">
                                <span className="w-14 text-xs font-bold text-white/70 text-right uppercase tracking-wider">{item.l}</span>
                                <div className="flex-1 h-3 bg-white/5 rounded-full overflow-hidden">
                                    <div style={{width: `${(item.v / maxVal) * 100}%`}} className={`h-full ${item.c} shadow-[0_0_10px_rgba(255,255,255,0.2)] transition-all duration-1000`}></div>
                                </div>
                                <span className={`w-14 text-xs font-black ${item.t} text-right`}>{formatValue(item.v, item.p)}</span>
                            </div>
                        ))}
                    </div>
                    <ChartControls />
                </div>
            )
        }

        const radius = 40;
        const circumference = 2 * Math.PI * radius;
        return (
            <div className="w-full flex flex-col items-center">
                <div className="relative size-48">
                    <svg className="size-full -rotate-90" viewBox="0 0 100 100">
                        <circle cx="50" cy="50" r={radius} fill="none" stroke="#1E293B" strokeWidth="10" />
                        {total > 0 && (
                            <>
                                <circle cx="50" cy="50" r={radius} fill="none" stroke="#10B981" strokeWidth="10" strokeDasharray={`${pctP * circumference} ${circumference}`} strokeDashoffset="0" strokeLinecap="round" />
                                <circle cx="50" cy="50" r={radius} fill="none" stroke="#0EA5E9" strokeWidth="10" strokeDasharray={`${pctC * circumference} ${circumference}`} strokeDashoffset={-(pctP * circumference)} strokeLinecap="round" />
                                <circle cx="50" cy="50" r={radius} fill="none" stroke="#F59E0B" strokeWidth="10" strokeDasharray={`${pctF * circumference} ${circumference}`} strokeDashoffset={-(pctP + pctC) * circumference} strokeLinecap="round" />
                            </>
                        )}
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-3xl font-black text-white">{scanResult.calories}</span>
                        <span className="text-[10px] font-bold text-text-dark-secondary uppercase tracking-widest">Kcal</span>
                    </div>
                </div>
                <div className="flex justify-center gap-6 w-full mt-4">
                     {[{l: 'Pro', v: valP, p: pctP, c: 'bg-primary', t: 'text-primary'}, {l: 'Carb', v: valC, p: pctC, c: 'bg-accent', t: 'text-accent'}, {l: 'Fat', v: valF, p: pctF, c: 'bg-warning', t: 'text-warning'}].map((item, i) => (
                        <div key={i} className="flex flex-col items-center">
                            <div className="flex items-center gap-1 mb-1"><div className={`size-2 rounded-full ${item.c}`}></div><span className="text-[10px] font-bold text-white/60 uppercase">{item.l}</span></div>
                            <span className={`text-lg font-black ${item.t}`}>{formatValue(item.v, item.p)}</span>
                        </div>
                     ))}
                </div>
                <ChartControls />
            </div>
        );
    };

    return (
        <div className="fixed inset-0 bg-black z-50 flex flex-col">
            <header className="absolute top-0 left-0 right-0 p-6 flex justify-between z-20 pt-safe-top">
                <button onClick={onExit} className="size-10 rounded-full bg-black/40 text-white flex items-center justify-center backdrop-blur-md border border-white/10 hover:bg-white/10 transition-colors">
                    <span className="material-symbols-outlined">close</span>
                </button>
            </header>

            <div className="flex-1 relative bg-black flex items-center justify-center overflow-hidden">
                {!image ? <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" /> : <img src={image} className="w-full h-full object-cover opacity-40" />}
                <canvas ref={canvasRef} className="hidden" />
                {!image && <div className="absolute inset-0 flex items-center justify-center pointer-events-none"><div className={`size-72 border-[3px] rounded-[32px] border-dashed opacity-50 ${mode==='fridge' ? 'border-secondary' : 'border-primary'}`}></div></div>}
            </div>

            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/90 to-transparent p-6 pb-12 safe-area-bottom">
                {!image && (
                    <div className="flex flex-col items-center gap-8">
                        <div className="flex bg-white/10 backdrop-blur-xl rounded-full p-1 border border-white/10">
                            {['nutrition', 'fridge'].map((m) => (
                                <button key={m} onClick={() => setMode(m as ScanMode)} className={`px-5 py-2.5 rounded-full text-sm font-bold transition-all ${mode === m ? (m === 'nutrition' ? 'bg-primary text-white shadow-[0_0_15px_rgba(16,185,129,0.4)]' : 'bg-secondary text-white shadow-[0_0_15px_rgba(45,212,191,0.4)]') : 'text-white/50 hover:text-white'}`}>
                                    {m === 'nutrition' ? t('scanMeal') : t('scanFridge')}
                                </button>
                            ))}
                        </div>
                        <button onClick={captureImage} className={`group size-24 rounded-full border-4 flex items-center justify-center active:scale-95 transition-all ${mode==='fridge' ? 'border-secondary/30 bg-secondary/10' : 'border-primary/30 bg-primary/10'}`}>
                            <div className={`size-18 rounded-full transition-all duration-300 group-hover:scale-110 shadow-lg ${mode==='fridge' ? 'bg-secondary' : 'bg-primary'}`}></div>
                        </button>
                    </div>
                )}

                {isAnalyzing && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-md z-30">
                        <Spinner className="size-12 text-primary mb-4" />
                        <p className="text-xl font-bold text-white animate-pulse">Analyzing...</p>
                    </div>
                )}

                {scanResult && mode === 'nutrition' && (
                    <div className="bg-surface-dark/95 backdrop-blur-2xl rounded-[32px] border border-white/10 shadow-2xl flex flex-col max-h-[75vh] animate-slide-up overflow-hidden">
                        <div className="p-6 pb-2 shrink-0 bg-black/20">
                            <h2 className="text-2xl font-black text-white leading-tight mb-1">{scanResult.foodName}</h2>
                            <div className="flex p-1 bg-white/5 rounded-xl border border-white/5 mt-4">
                                {['overview', 'all'].map((tab) => (
                                    <button key={tab} onClick={() => setActiveTab(tab as Tab)} className={`flex-1 py-2.5 rounded-lg text-xs font-bold transition-all uppercase tracking-wide ${activeTab === tab ? 'bg-white/10 text-white shadow-sm' : 'text-text-dark-secondary hover:text-white'}`}>{tab}</button>
                                ))}
                            </div>
                        </div>

                        <div className="flex-1 overflow-y-auto no-scrollbar p-6 pt-2">
                             <div className="animate-fade-in space-y-6">
                                <div className="p-6 bg-black/20 rounded-3xl border border-white/5">{renderNutritionChart()}</div>
                                {activeTab === 'all' && (
                                    <>
                                        <div className="p-5 bg-white/5 rounded-2xl border border-white/5"><h4 className="text-xs font-bold text-text-dark-secondary uppercase tracking-wider mb-2">Description</h4><p className="text-sm text-white leading-relaxed">{scanResult.description}</p></div>
                                        <div className="p-5 bg-white/5 rounded-2xl border border-white/5"><h4 className="text-xs font-bold text-text-dark-secondary uppercase tracking-wider mb-2">Origin</h4><p className="text-sm text-white leading-relaxed">{scanResult.origin}</p></div>
                                        <div className="space-y-2">{scanResult.nutrients.map((n, i) => <div key={i} className="flex justify-between p-3 bg-white/5 rounded-xl"><span className="text-sm font-medium text-white">{n.name}</span><span className="text-sm font-bold text-primary">{n.amount}</span></div>)}</div>
                                    </>
                                )}
                                <button onClick={() => onAction?.({ type: 'OPEN_CHAT', payload: `Tell me about ${scanResult.foodName}` })} className="w-full py-4 rounded-2xl bg-white/10 text-white font-bold border border-white/10 hover:bg-white/20 transition-colors flex items-center justify-center gap-2"><span className="material-symbols-outlined">smart_toy</span>Ask CalBot</button>
                             </div>
                        </div>
                        <div className="p-4 border-t border-white/10 bg-black/40"><button onClick={reset} className="w-full h-14 rounded-full bg-white text-black font-bold hover:bg-gray-200 transition-colors">Scan New Item</button></div>
                    </div>
                )}

                 {fridgeIngredients.length > 0 && mode === 'fridge' && (
                    <div className="bg-surface-dark/95 backdrop-blur-2xl rounded-[32px] p-6 border border-white/10 animate-slide-up max-h-[60vh] overflow-y-auto shadow-2xl">
                         <div className="flex items-center gap-3 mb-6"><div className="size-10 rounded-full bg-secondary/20 flex items-center justify-center text-secondary"><span className="material-symbols-outlined">kitchen</span></div><h2 className="text-xl font-bold text-white">Found {fridgeIngredients.length} Items</h2></div>
                         <div className="flex flex-wrap gap-2 mb-8">{fridgeIngredients.map((ing, i) => <span key={i} className="px-3 py-1.5 rounded-lg bg-white/10 text-white text-sm font-bold border border-white/5">{ing}</span>)}</div>
                         <button onClick={() => onIngredientsFound?.(fridgeIngredients)} className="w-full h-14 rounded-full bg-secondary text-white font-bold text-lg shadow-lg shadow-secondary/20 hover:bg-secondary-600 transition-colors mb-3">Create Recipes</button>
                         <button onClick={reset} className="w-full h-12 rounded-full text-text-dark-secondary font-bold hover:text-white transition-colors">Retake</button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default FoodScannerScreen;
