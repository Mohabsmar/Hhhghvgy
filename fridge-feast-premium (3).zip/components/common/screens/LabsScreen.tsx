
import React, { useState } from 'react';
import { AppScreen } from '../../../types';

interface LabsScreenProps {
    onExit: () => void;
    onNavigate: (screen: AppScreen) => void;
}

const LabsScreen: React.FC<LabsScreenProps> = ({ onExit, onNavigate }) => {
    const [search, setSearch] = useState('');

    const features: { id: AppScreen, name: string, desc: string, icon: string, color: string }[] = [
        // Previous 15
        { id: 'unitConverter', name: 'Unit Converter', desc: 'Convert mass, volume, temps', icon: 'calculate', color: 'text-blue-400' },
        { id: 'kitchenTimers', name: 'Kitchen Timers', desc: 'Multi-track cooking timers', icon: 'timer', color: 'text-orange-400' },
        { id: 'winePairing', name: 'Wine Sommelier', desc: 'AI wine recommendations', icon: 'wine_bar', color: 'text-purple-400' },
        { id: 'mixology', name: 'Mixology AI', desc: 'Cocktail generator', icon: 'local_bar', color: 'text-pink-400' },
        { id: 'coffeeBar', name: 'Coffee Bar', desc: 'Brewing guides & timers', icon: 'coffee', color: 'text-brown-400' },
        { id: 'substitutions', name: 'Substitutions', desc: 'Find ingredient alts', icon: 'sync_alt', color: 'text-green-400' },
        { id: 'seasonalGuide', name: 'Seasonal Guide', desc: 'Produce by month', icon: 'eco', color: 'text-emerald-400' },
        { id: 'cookingSchool', name: 'Cooking School', desc: 'Skill tracking', icon: 'school', color: 'text-red-400' },
        { id: 'dictionary', name: 'Dictionary', desc: 'Culinary terms defined', icon: 'menu_book', color: 'text-yellow-400' },
        { id: 'leftoverMagic', name: 'Leftover Magic', desc: 'Iron Chef mode', icon: 'auto_fix_high', color: 'text-indigo-400' },
        { id: 'tasteProfiler', name: 'Taste Profiler', desc: 'Discover your palate', icon: 'palette', color: 'text-teal-400' },
        { id: 'fermentationLog', name: 'Fermentation', desc: 'Track sourdough & pickles', icon: 'science', color: 'text-lime-400' },
        { id: 'partyPlanner', name: 'Party Planner', desc: 'Food qty calculator', icon: 'celebration', color: 'text-cyan-400' },
        { id: 'dietaryReport', name: 'Dietary Report', desc: 'Macro analytics', icon: 'health_and_safety', color: 'text-rose-400' },
        { id: 'familySync', name: 'Family Sync', desc: 'Share lists & plans', icon: 'sync', color: 'text-blue-200' },
        
        // New 20
        { id: 'mealPrep', name: 'Meal Prep Mode', desc: 'Batch cooking workflow', icon: 'bento', color: 'text-amber-400' },
        { id: 'priceCompare', name: 'Price Watch', desc: 'Grocery comparison', icon: 'price_check', color: 'text-green-500' },
        { id: 'farmersMarket', name: 'Farmers Market', desc: 'Local produce finder', icon: 'storefront', color: 'text-orange-500' },
        { id: 'molecularGastronomy', name: 'Molecular Lab', desc: 'Spherification guides', icon: 'bubble_chart', color: 'text-purple-500' },
        { id: 'foodPhotography', name: 'Food Photo', desc: 'Composition tips', icon: 'camera', color: 'text-pink-500' },
        { id: 'teaLounge', name: 'Tea Lounge', desc: 'Brewing techniques', icon: 'emoji_food_beverage', color: 'text-green-300' },
        { id: 'spiceBlender', name: 'Spice Blender', desc: 'Custom rub generator', icon: 'grain', color: 'text-red-300' },
        { id: 'cheeseBoard', name: 'Cheese Board', desc: 'Pairing wizard', icon: 'cookie', color: 'text-yellow-200' },
        { id: 'sourdoughCalc', name: 'Sourdough Calc', desc: 'Hydration math', icon: 'bakery_dining', color: 'text-orange-200' },
        { id: 'homeBrew', name: 'Home Brewer', desc: 'Beer log', icon: 'sports_bar', color: 'text-amber-600' },
        { id: 'canningGuide', name: 'Canning Safe', desc: 'Preservation guide', icon: 'kitchen', color: 'text-gray-400' },
        { id: 'foraging', name: 'Foraging', desc: 'Identification tips', icon: 'forest', color: 'text-green-700' },
        { id: 'butcheryGuide', name: 'Butchery 101', desc: 'Cuts of meat', icon: 'restaurant_menu', color: 'text-red-700' },
        { id: 'knifeCare', name: 'Knife Care', desc: 'Sharpening tracker', icon: 'content_cut', color: 'text-gray-200' },
        { id: 'applianceTracker', name: 'Appliance Health', desc: 'Maintenance log', icon: 'home_repair_service', color: 'text-blue-300' },
        { id: 'gardenTracker', name: 'Garden to Table', desc: 'Planting calendar', icon: 'yard', color: 'text-green-400' },
        { id: 'halalScanner', name: 'Halal/Kosher', desc: 'Ingredient checker', icon: 'verified', color: 'text-emerald-600' },
        { id: 'allergyRadar', name: 'Allergy Radar', desc: 'Contamination check', icon: 'warning', color: 'text-red-500' },
        { id: 'sommelierChat', name: 'Sommelier Chat', desc: 'Ask about wine', icon: 'forum', color: 'text-purple-300' },
        { id: 'labelDecoder', name: 'Label Decoder', desc: 'Nutrition explainer', icon: 'fact_check', color: 'text-blue-500' },
    ];

    const filtered = features.filter(f => f.name.toLowerCase().includes(search.toLowerCase()) || f.desc.toLowerCase().includes(search.toLowerCase()));

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <div>
                    <h1 className="text-xl font-black text-white text-center">Kitchen Labs</h1>
                    <p className="text-[10px] text-primary font-bold uppercase tracking-widest text-center">Experimental Features</p>
                </div>
                <div className="size-10"></div>
            </header>
            
            <div className="px-6 py-4">
                <div className="relative">
                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-text-dark-secondary">search</span>
                    <input 
                        type="text" 
                        placeholder="Search tools..." 
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                        className="w-full h-12 bg-surface-dark rounded-full pl-12 pr-4 text-white placeholder:text-text-dark-secondary/50 border border-white/10 focus:border-primary/50 focus:ring-0"
                    />
                </div>
            </div>

            <main className="flex-1 overflow-y-auto p-6 pt-0 pb-32">
                <div className="grid grid-cols-2 gap-4">
                    {filtered.map(feature => (
                        <button 
                            key={feature.id}
                            onClick={() => onNavigate(feature.id)}
                            className="liquid-panel p-4 rounded-[24px] border border-white/5 flex flex-col items-center text-center gap-3 hover:bg-white/5 transition-all active:scale-95 group"
                        >
                            <div className={`size-12 rounded-2xl bg-white/5 flex items-center justify-center ${feature.color} border border-white/5 group-hover:scale-110 transition-transform`}>
                                <span className="material-symbols-outlined text-2xl">{feature.icon}</span>
                            </div>
                            <div>
                                <h3 className="text-sm font-bold text-white leading-tight">{feature.name}</h3>
                                <p className="text-[10px] text-text-dark-secondary mt-1">{feature.desc}</p>
                            </div>
                        </button>
                    ))}
                </div>
            </main>
        </div>
    );
};

export default LabsScreen;
