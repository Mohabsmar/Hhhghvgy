
import React, { useState } from 'react';
import { User, Language } from '../../../types';
import { auth, isConfigured } from '../../../common/firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { db } from '../../../common/dbService'; // Import the service, not the firestore instance
import Spinner from '../Spinner';

interface LoginScreenProps {
    onLogin: (user: User) => void;
    onGuestLogin: () => void;
    selectedLanguage: Language;
    onLanguageChange: (lang: Language) => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, onGuestLogin, selectedLanguage, onLanguageChange }) => {
    const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleAuth = async () => {
        if (!email || !password) return;
        if (authMode === 'signup' && !name) return;
        
        setIsLoading(true);
        setError(null);

        // MOCK MODE FALLBACK if no Firebase config
        if (!isConfigured || !auth) {
            setTimeout(() => {
                const mockUser: User = {
                    name: name || "Mock User",
                    email: email,
                    photoUrl: "https://images.unsplash.com/photo-1583394838336-acd977730f90?w=400&q=80",
                    preferences: {
                        dietary: [], cuisine: [], difficulty: 'Medium', notifications: true, language: selectedLanguage,
                        nutritionDisplay: 'percentage', nutritionUnit: 'weight', nutritionChartType: 'donut',
                        quickAccess: ['scanner', 'chat', 'shopping', 'favorites'],
                        navBar: {
                            style: 'floating', width: 90, height: 70, borderRadius: 40, bottomOffset: 24, horizontalOffset: 0,
                            backgroundColor: '#000000', backgroundOpacity: 85, iconColor: '#ffffff', activeIconColor: '#10B981',
                            showLabels: false, blurEffect: true, borderColor: 'rgba(16,185,129,0.2)', borderWidth: 1,
                            containerPosition: 'center', verticalPosition: 'bottom'
                        },
                        dataSaver: false, incognito: false, themeMode: 'dark'
                    },
                    xp: 0, level: 1, rank: 'Novice', badges: [],
                    stats: { recipesCooked: 0, streakDays: 0, moneySaved: 0, wasteReduced: 0, cuisinesExplored: [], totalCaloriesCooked: 0, weeklyActivity: [0,0,0,0,0,0,0] }
                };
                onLogin(mockUser);
            }, 1500);
            return;
        }

        // REAL FIREBASE AUTH
        try {
            let userCredential;
            if (authMode === 'signup') {
                userCredential = await createUserWithEmailAndPassword(auth, email, password);
                if (auth.currentUser) {
                    await updateProfile(auth.currentUser, { displayName: name });
                }
            } else {
                userCredential = await signInWithEmailAndPassword(auth, email, password);
            }

            const firebaseUser = userCredential.user;
            
            // Construct User Object
            const appUser: User = {
                name: firebaseUser.displayName || name || "Chef",
                email: firebaseUser.email || "",
                photoUrl: firebaseUser.photoURL || "https://images.unsplash.com/photo-1583394838336-acd977730f90?w=400&q=80",
                preferences: {
                    dietary: [], cuisine: [], difficulty: 'Medium', notifications: true, language: selectedLanguage,
                    nutritionDisplay: 'percentage', nutritionUnit: 'weight', nutritionChartType: 'donut',
                    quickAccess: ['scanner', 'chat', 'shopping', 'favorites'],
                    navBar: {
                        style: 'floating', width: 90, height: 70, borderRadius: 40, bottomOffset: 24, horizontalOffset: 0,
                        backgroundColor: '#000000', backgroundOpacity: 85, iconColor: '#ffffff', activeIconColor: '#10B981',
                        showLabels: false, blurEffect: true, borderColor: 'rgba(16,185,129,0.2)', borderWidth: 1,
                        containerPosition: 'center', verticalPosition: 'bottom'
                    },
                    dataSaver: false, incognito: false, themeMode: 'dark'
                },
                xp: 0, level: 1, rank: 'Novice', badges: [],
                stats: { recipesCooked: 0, streakDays: 0, moneySaved: 0, wasteReduced: 0, cuisinesExplored: [], totalCaloriesCooked: 0, weeklyActivity: [0,0,0,0,0,0,0] }
            };

            // Check if profile exists in DB, if not create/save
            const existing = await db.getUser(appUser.email);
            if (!existing && authMode === 'signup') {
                await db.saveUser(appUser);
            }
            
            onLogin(existing || appUser);

        } catch (err: any) {
            console.error(err);
            setError(err.message || "Authentication failed.");
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-[#020617] flex flex-col items-center justify-center p-6 relative overflow-hidden font-display">
            {/* Cinematic Background Layer */}
            <div className="absolute inset-0 z-0 pointer-events-none">
                {/* Nebula Effects */}
                <div className="absolute top-[-10%] left-[-10%] size-[800px] bg-primary/5 blur-[160px] rounded-full animate-pulse-glow"></div>
                <div className="absolute bottom-[-10%] right-[-10%] size-[800px] bg-purple-900/10 blur-[160px] rounded-full animate-pulse-glow" style={{ animationDelay: '3s' }}></div>
                
                {/* Grain Noise Overlay is handled by global body class, ensuring depth */}
            </div>

            {/* Content Layer */}
            <div className="w-full max-w-sm relative z-10 flex flex-col items-center">
                <div className="space-y-8 animate-reveal w-full">
                    
                    {/* Compact Logo */}
                    <div className="text-center space-y-4">
                        <div className="relative size-20 group mx-auto">
                            <div className="absolute inset-0 bg-primary/20 blur-3xl group-hover:bg-primary/40 transition-all duration-1000"></div>
                            <div className="relative size-full rounded-full border border-primary/30 flex items-center justify-center bg-black/80 backdrop-blur-xl shadow-[0_0_50px_rgba(16,185,129,0.1)] animate-float">
                                <span className="material-symbols-outlined text-4xl text-primary drop-shadow-[0_0_15px_rgba(16,185,129,0.5)]">restaurant_menu</span>
                            </div>
                        </div>
                        <div>
                            <h1 className="text-4xl font-black text-white tracking-tighter leading-none select-none">
                                Fridge<span className="text-primary text-glow-primary">Feast</span>
                            </h1>
                            <p className="text-white/30 font-bold uppercase tracking-[0.6em] text-[10px] mt-2">Obsidian OS v5.0</p>
                        </div>
                    </div>

                    {/* Obsidian Glass Auth Card */}
                    <div className="liquid-glass rounded-[40px] p-8 w-full relative overflow-hidden transition-all duration-500">
                        {/* Specular Highlight Top Left */}
                        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-white/40 via-transparent to-transparent"></div>
                        <div className="absolute top-0 left-0 h-full w-px bg-gradient-to-b from-white/40 via-transparent to-transparent"></div>

                        {/* Mode Toggle */}
                        <div className="flex bg-black/40 rounded-full p-1 mb-8 border border-white/5 relative shadow-inner">
                            <button 
                                onClick={() => setAuthMode('login')} 
                                className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-full transition-all relative z-10 ${authMode === 'login' ? 'text-black' : 'text-white/40 hover:text-white'}`}
                            >
                                Login
                            </button>
                            <button 
                                onClick={() => setAuthMode('signup')} 
                                className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-full transition-all relative z-10 ${authMode === 'signup' ? 'text-black' : 'text-white/40 hover:text-white'}`}
                            >
                                Register
                            </button>
                            <div 
                                className="absolute top-1 bottom-1 w-[calc(50%-4px)] bg-primary rounded-full transition-all duration-300 ease-spring shadow-[0_0_20px_rgba(16,185,129,0.4)]"
                                style={{ left: authMode === 'login' ? '4px' : 'calc(50%)' }}
                            ></div>
                        </div>

                        {/* Input Fields */}
                        <div className="space-y-5">
                            {authMode === 'signup' && (
                                <div className="space-y-1 animate-slide-up">
                                    <label className="text-[9px] font-bold text-white/30 uppercase tracking-widest ml-4">Codename</label>
                                    <div className="relative group">
                                        <input 
                                            type="text" 
                                            value={name}
                                            onChange={(e) => setName(e.target.value)}
                                            className="w-full h-12 bg-white/5 rounded-2xl px-12 text-white text-sm font-bold border border-white/10 focus:border-primary/50 focus:bg-white/10 transition-all placeholder:text-white/10 outline-none"
                                            placeholder="Chef Name"
                                        />
                                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-primary transition-colors text-lg">badge</span>
                                    </div>
                                </div>
                            )}

                            <div className="space-y-1">
                                <label className="text-[9px] font-bold text-white/30 uppercase tracking-widest ml-4">Identity</label>
                                <div className="relative group">
                                    <input 
                                        type="email" 
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        className="w-full h-12 bg-white/5 rounded-2xl px-12 text-white text-sm font-bold border border-white/10 focus:border-primary/50 focus:bg-white/10 transition-all placeholder:text-white/10 outline-none"
                                        placeholder="chef@kitchen.os"
                                    />
                                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-primary transition-colors text-lg">mail</span>
                                </div>
                            </div>

                            <div className="space-y-1">
                                <label className="text-[9px] font-bold text-white/30 uppercase tracking-widest ml-4">Access Key</label>
                                <div className="relative group">
                                    <input 
                                        type="password" 
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        className="w-full h-12 bg-white/5 rounded-2xl px-12 text-white text-sm font-bold border border-white/10 focus:border-primary/50 focus:bg-white/10 transition-all placeholder:text-white/10 outline-none"
                                        placeholder="••••••••"
                                    />
                                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-primary transition-colors text-lg">lock</span>
                                </div>
                            </div>
                        </div>

                        {error && (
                            <div className="mt-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-bold text-center animate-pulse">
                                {error}
                            </div>
                        )}

                        {/* Action Buttons */}
                        <div className="mt-8 space-y-4">
                            <button 
                                onClick={handleAuth}
                                disabled={isLoading || !email || !password || (authMode === 'signup' && !name)}
                                className="w-full h-14 rounded-full bg-primary text-black font-black text-xs uppercase tracking-[0.2em] shadow-[0_0_30px_rgba(16,185,129,0.3)] hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-30 disabled:scale-100 disabled:shadow-none"
                            >
                                {isLoading ? (
                                    <Spinner className="size-5 text-black" />
                                ) : (
                                    <>
                                        <span>Initialize</span>
                                        <span className="material-symbols-outlined text-lg">bolt</span>
                                    </>
                                )}
                            </button>

                            <button 
                                onClick={onGuestLogin}
                                className="w-full h-14 rounded-full bg-transparent border border-white/10 text-white font-bold text-[10px] uppercase tracking-[0.2em] hover:bg-white/5 active:scale-95 transition-all flex items-center justify-center gap-2"
                            >
                                <span className="material-symbols-outlined text-lg opacity-50">visibility_off</span>
                                Guest Access
                            </button>
                        </div>
                    </div>

                    {!isConfigured && (
                        <div className="p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20 text-center">
                            <p className="text-yellow-500 text-[10px] font-bold uppercase tracking-wide">⚠️ Running in Mock Mode</p>
                            <p className="text-white/40 text-[9px]">Add keys to common/firebase.ts for real auth</p>
                        </div>
                    )}

                    {/* Footer */}
                    <div className="flex items-center justify-center gap-6">
                        {['en', 'fr', 'ja'].map(l => (
                            <button 
                                key={l}
                                onClick={() => onLanguageChange(l as Language)}
                                className={`text-[9px] font-black uppercase tracking-widest transition-all ${selectedLanguage === l ? 'text-primary scale-125' : 'text-white/20 hover:text-white/50'}`}
                            >
                                {l}
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* Bottom Tag */}
            <div className="absolute bottom-8 left-0 right-0 text-center opacity-30 pointer-events-none">
                <p className="text-[8px] font-black text-white/50 uppercase tracking-[0.5em]">Forge Intelligence Laboratory</p>
            </div>
        </div>
    );
};

export default LoginScreen;
