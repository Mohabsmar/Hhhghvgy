
import React, { useState, useMemo } from 'react';
import { Recipe, Language, ShoppingListItem, ShoppingListCategory } from '../../../types';
import { getTranslation } from '../../../constants';

interface RecipeDetailScreenProps {
    recipe: Recipe;
    onStartCooking: (recipe: Recipe) => void;
    onExit: () => void;
    lang: Language;
    chartMode: 'weight' | 'calories';
}

const RecipeDetailScreen: React.FC<RecipeDetailScreenProps> = ({ recipe, onStartCooking, onExit, lang, chartMode }) => {
    const [activeTab, setActiveTab] = useState<'ingredients' | 'instructions' | 'nutrition'>('ingredients');
    const [currentServings, setCurrentServings] = useState(recipe.servings || 2);
    const [addedToShop, setAddedToShop] = useState(false);

    const scaleFactor = currentServings / (recipe.servings || 2);

    // Summing Engine: Correctly calculates Prep Time + Cook Time
    const calculateTotalTime = (prep: string, cook: string): string => {
        const timeToMinutes = (str: string) => {
            if (!str) return 0;
            const clean = str.toLowerCase();
            let mins = 0;
            const h = clean.match(/(\d+)\s*h/);
            const m = clean.match(/(\d+)\s*m/);
            if (h) mins += parseInt(h[1]) * 60;
            if (m) mins += parseInt(m[1]);
            if (!h && !m) {
                const pure = parseInt(clean);
                if (!isNaN(pure)) mins += pure;
            }
            return mins;
        };

        const totalMins = timeToMinutes(prep) + timeToMinutes(cook);
        if (totalMins === 0) return 'Quick';
        
        const hrs = Math.floor(totalMins / 60);
        const rm = totalMins % 60;
        
        if (hrs > 0) return `${hrs}h ${rm > 0 ? rm + 'm' : ''}`.trim();
        return `${rm}m`;
    };

    const totalTime = useMemo(() => calculateTotalTime(recipe.prepTime, recipe.cookTime), [recipe.prepTime, recipe.cookTime]);

    const scaledIngredients = useMemo(() => {
        const base = recipe.ingredients || [];
        return base.map(ing => {
            const match = ing.amount.match(/^(\d+(\.\d+)?|\d+\/\d+)(.*)$/);
            if (match) {
                const numStr = match[1];
                const rest = match[3];
                let val = numStr.includes('/') ? (eval(numStr)) : parseFloat(numStr);
                const newVal = (val * scaleFactor).toFixed(1).replace(/\.0$/, '');
                return { ...ing, amount: `${newVal}${rest}` };
            }
            return ing;
        });
    }, [recipe.ingredients, scaleFactor]);

    const handleAddToShoppingList = () => {
        const STORAGE_KEY = 'stitch_shopping_list';
        const stored = localStorage.getItem(STORAGE_KEY);
        let currentList: ShoppingListCategory[] = stored ? JSON.parse(stored) : [];
        let recipeCatIndex = currentList.findIndex(c => c.name === 'From Recipes');
        const newItems: ShoppingListItem[] = scaledIngredients.map((ing, idx) => ({
            id: `recipe-${recipe.id}-${idx}-${Date.now()}`,
            name: ing.name, quantity: ing.amount, source: recipe.recipeName, checked: false, status: 'available'
        }));
        if (recipeCatIndex === -1) currentList.unshift({ name: 'From Recipes', items: newItems });
        else currentList[recipeCatIndex].items = [...newItems, ...currentList[recipeCatIndex].items];
        localStorage.setItem(STORAGE_KEY, JSON.stringify(currentList));
        setAddedToShop(true);
        setTimeout(() => setAddedToShop(false), 2000);
    };

    return (
        <div className="fixed inset-0 bg-black z-50 flex flex-col overflow-y-auto no-scrollbar font-display animate-reveal">
            {/* Immersive Header */}
            <div className="relative h-[55vh] w-full shrink-0">
                <img 
                    src={recipe.imageUrl || "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=1200&auto=format&fit=crop"} 
                    className="w-full h-full object-cover"
                    alt={recipe.recipeName}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent"></div>
                
                <div className="absolute top-0 left-0 right-0 p-8 flex justify-between items-center z-20 pt-safe-top">
                    <button onClick={onExit} className="size-14 rounded-full bg-black/40 backdrop-blur-3xl flex items-center justify-center text-white border border-white/10 active:scale-90 transition-transform">
                        <span className="material-symbols-outlined text-3xl">close</span>
                    </button>
                    <button className="size-14 rounded-full bg-black/40 backdrop-blur-3xl flex items-center justify-center text-white border border-white/10 active:scale-90 transition-transform">
                        <span className="material-symbols-outlined text-3xl">favorite</span>
                    </button>
                </div>

                <div className="absolute bottom-8 left-8 right-8 p-10 rounded-[56px] liquid-glass border border-white/10 shadow-2xl">
                    <div className="flex flex-wrap items-center gap-3 mb-5">
                        <span className="px-5 py-2 rounded-full bg-primary/20 text-primary text-[10px] font-black uppercase tracking-[0.2em] border border-primary/20">
                            {recipe.difficulty}
                        </span>
                        <div className="flex items-center gap-2 px-5 py-2 rounded-full bg-white/5 border border-white/10 text-[10px] font-black text-white uppercase tracking-[0.2em]">
                            <span className="material-symbols-outlined text-lg text-primary">schedule</span>
                            Sum: {totalTime}
                        </div>
                    </div>
                    <h1 className="text-5xl font-black text-white leading-[0.9] tracking-tighter drop-shadow-2xl">{recipe.recipeName}</h1>
                    <p className="text-white/30 text-[10px] font-black uppercase tracking-[0.5em] mt-4">Pure Gastronomy</p>
                </div>
            </div>

            <div className="px-8 pb-48 bg-black">
                {/* Elite Stats Bar */}
                <div className="grid grid-cols-3 gap-5 my-12">
                    <div className="p-6 rounded-[36px] bg-white/5 border border-white/5 text-center flex flex-col justify-center">
                         <span className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em] mb-1">Prep</span>
                         <span className="text-xl font-black text-white">{recipe.prepTime}</span>
                    </div>
                    <div className="p-6 rounded-[36px] bg-white/5 border border-white/5 text-center flex flex-col justify-center">
                         <span className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em] mb-1">Cook</span>
                         <span className="text-xl font-black text-white">{recipe.cookTime}</span>
                    </div>
                    <div className="p-6 rounded-[36px] bg-primary/10 border border-primary/20 text-center flex flex-col justify-center shadow-[0_0_40px_rgba(16,185,129,0.1)]">
                         <span className="text-[10px] font-black text-primary uppercase tracking-[0.3em] mb-1">Total</span>
                         <span className="text-xl font-black text-primary">{totalTime}</span>
                    </div>
                </div>

                {/* Luxury Tabs */}
                <div className="flex p-1.5 bg-white/5 rounded-[32px] border border-white/5 mb-12 sticky top-6 z-30 backdrop-blur-3xl shadow-xl">
                    {(['ingredients', 'instructions', 'nutrition'] as const).map(tab => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`flex-1 py-4 rounded-[28px] text-[10px] font-black uppercase tracking-[0.3em] transition-all ${activeTab === tab ? 'bg-white text-black shadow-2xl' : 'text-white/30 hover:text-white/60'}`}
                        >
                            {tab}
                        </button>
                    ))}
                </div>

                <div className="min-h-[400px]">
                    {activeTab === 'ingredients' && (
                        <div className="space-y-10 animate-reveal">
                            <div className="flex items-center justify-between bg-white/5 p-10 rounded-[48px] border border-white/5">
                                <div className="space-y-1">
                                    <span className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Portion Control</span>
                                    <p className="text-white font-black text-lg">Yield Adjustment</p>
                                </div>
                                <div className="flex items-center gap-10">
                                    <button onClick={() => setCurrentServings(Math.max(1, currentServings - 1))} className="size-14 rounded-full bg-white/5 flex items-center justify-center border border-white/10 text-white hover:bg-white/10 transition-colors shadow-lg active:scale-90"><span className="material-symbols-outlined text-2xl">remove</span></button>
                                    <span className="text-4xl font-black text-primary min-w-[40px] text-center tabular-nums">{currentServings}</span>
                                    <button onClick={() => setCurrentServings(currentServings + 1)} className="size-14 rounded-full bg-white/5 flex items-center justify-center border border-white/10 text-white hover:bg-white/10 transition-colors shadow-lg active:scale-90"><span className="material-symbols-outlined text-2xl">add</span></button>
                                </div>
                            </div>
                            <div className="space-y-4">
                                {scaledIngredients.map((ing, i) => (
                                    <div key={i} className="flex items-center justify-between p-8 rounded-[36px] bg-white/[0.02] border border-white/5 group hover:bg-white/[0.05] transition-all">
                                        <span className="text-white font-bold text-2xl group-hover:text-primary transition-colors">{ing.name}</span>
                                        <span className="text-primary font-black text-xl px-5 py-2 rounded-full bg-primary/5 border border-primary/10">{ing.amount}</span>
                                    </div>
                                ))}
                            </div>
                            <button 
                                onClick={handleAddToShoppingList}
                                className={`w-full h-20 rounded-[32px] font-black text-xs uppercase tracking-[0.5em] flex items-center justify-center gap-4 transition-all active:scale-95 shadow-2xl border ${addedToShop ? 'bg-emerald-500 border-emerald-500 text-black shadow-emerald-500/30' : 'bg-white/5 border-white/10 text-white hover:bg-white/10'}`}
                            >
                                <span className="material-symbols-outlined text-3xl">{addedToShop ? 'check_circle' : 'shopping_bag'}</span>
                                {addedToShop ? 'Added to Pantry' : 'Sync to Shopping List'}
                            </button>
                        </div>
                    )}

                    {activeTab === 'instructions' && (
                        <div className="space-y-14 pb-20 animate-reveal">
                            {recipe.instructions.map((step, i) => (
                                <div key={i} className="flex gap-10 group">
                                    <div className="size-16 rounded-[24px] bg-white/5 border border-white/10 flex items-center justify-center shrink-0 font-black text-2xl text-white shadow-inner group-hover:bg-primary group-hover:text-black group-hover:rotate-6 transition-all duration-500">
                                        {i + 1}
                                    </div>
                                    <div className="pt-3">
                                        <p className="text-white/80 leading-[1.6] text-2xl font-medium tracking-tight">{step}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}

                    {activeTab === 'nutrition' && (
                        <div className="space-y-10 animate-reveal">
                             <div className="p-16 rounded-[64px] bg-white/5 border border-white/5 text-center relative overflow-hidden">
                                 <div className="absolute top-[-20%] right-[-10%] size-64 bg-primary/10 blur-[100px] rounded-full"></div>
                                 <span className="text-8xl font-black text-white tabular-nums drop-shadow-xl">{Math.round(recipe.calories * scaleFactor)}</span>
                                 <p className="text-[10px] font-black text-white/20 uppercase tracking-[0.6em] mt-5">Caloric Value Per Batch</p>
                             </div>
                             <div className="grid grid-cols-3 gap-6">
                                 {[['Protein', recipe.protein, 'text-primary', 'fitness_center'], ['Carbs', recipe.carbs, 'text-accent', 'bolt'], ['Fat', recipe.fat, 'text-orange-400', 'water_drop']].map(([l, v, c, icon]) => (
                                     <div key={l as string} className="p-8 rounded-[48px] bg-white/5 border border-white/5 text-center flex flex-col items-center group hover:bg-white/[0.08] transition-colors">
                                         <span className={`material-symbols-outlined ${c as string} text-3xl mb-4 group-hover:scale-125 transition-transform`}>{icon as string}</span>
                                         <span className={`text-3xl font-black ${c as string} tabular-nums`}>{Math.round((v as number) * scaleFactor)}g</span>
                                         <p className="text-[9px] font-black text-white/20 uppercase tracking-widest mt-3">{l as string}</p>
                                     </div>
                                 ))}
                             </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Bottom Elite Execution Bar */}
            <div className="fixed bottom-0 left-0 right-0 p-10 bg-gradient-to-t from-black via-black/95 to-transparent z-40 safe-area-bottom">
                <button 
                    onClick={() => onStartCooking(recipe)}
                    className="w-full h-24 rounded-[36px] bg-white text-black font-black text-2xl shadow-[0_30px_60px_rgba(255,255,255,0.15)] flex items-center justify-center gap-5 active:scale-[0.98] transition-all group"
                >
                    Initialize Preparation
                    <span className="material-symbols-outlined text-primary text-4xl group-hover:translate-x-3 transition-transform">bolt</span>
                </button>
            </div>
        </div>
    );
};

export default RecipeDetailScreen;
