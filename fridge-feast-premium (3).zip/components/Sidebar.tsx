
import React from 'react';
import { AppScreen, NavItemDef } from '../types';

interface SidebarProps {
    isOpen: boolean;
    onClose: () => void;
    allItems: NavItemDef[];
    pinnedItems: NavItemDef[];
    onTogglePin: (item: NavItemDef) => void;
    onNavigate: (screen: AppScreen) => void;
    activeScreen: AppScreen;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, allItems, pinnedItems, onTogglePin, onNavigate, activeScreen }) => {
    if (!isOpen) return null;

    // Grouping Logic
    const groups = {
        "Main": ['home', 'profile', 'settings', 'community'],
        "Food & Prep": ['discover', 'pantry', 'shopping', 'mealPlan', 'scanner'],
        "Kitchen Tools": ['kitchenTimers', 'unitConverter', 'substitutions', 'partyPlanner', 'familySync'],
        "Chef's Lab": ['winePairing', 'mixology', 'coffeeBar', 'leftoverMagic', 'fermentationLog'],
        "Education": ['cookingSchool', 'dictionary', 'seasonalGuide', 'tasteProfiler'],
        "Stats": ['analytics', 'gamification', 'stores', 'favorites']
    };

    return (
        <div className="fixed inset-0 z-[60] flex flex-col justify-end sm:justify-center sm:items-center">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-md animate-fade-in" onClick={onClose}></div>

            <div className="relative w-full sm:w-[400px] bg-[#0F0F11] sm:rounded-[40px] rounded-t-[40px] border border-white/10 shadow-[0_-20px_60px_rgba(0,0,0,0.8)] overflow-hidden animate-slide-up max-h-[85vh] flex flex-col">
                
                <div className="p-6 pb-2 flex items-center justify-between relative z-20 bg-gradient-to-b from-[#0F0F11] to-transparent">
                    <div>
                        <h2 className="text-2xl font-bold text-white tracking-tight">App Directory</h2>
                        <p className="text-xs text-text-dark-secondary mt-1">Explore all culinary tools.</p>
                    </div>
                    <button onClick={onClose} className="size-9 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white active:bg-white/10">
                        <span className="material-symbols-outlined">close</span>
                    </button>
                </div>

                <div className="p-6 pt-4 overflow-y-auto no-scrollbar pb-10 space-y-6">
                    {Object.entries(groups).map(([groupName, ids]) => (
                        <div key={groupName}>
                            <h3 className="text-xs font-bold text-text-dark-secondary uppercase tracking-wider mb-3 px-2">{groupName}</h3>
                            <div className="grid grid-cols-4 gap-3">
                                {ids.map(id => {
                                    const item = allItems.find(i => i.id === id);
                                    if (!item) return null;
                                    const isActive = activeScreen === item.id;
                                    return (
                                        <button 
                                            key={item.id}
                                            onClick={() => { onNavigate(item.id as AppScreen); onClose(); }}
                                            className={`flex flex-col items-center gap-2 p-2 rounded-xl transition-all ${isActive ? 'bg-white/10' : 'hover:bg-white/5'}`}
                                        >
                                            <div className={`size-12 rounded-2xl flex items-center justify-center border transition-colors ${isActive ? 'bg-primary text-white border-primary' : 'bg-surface-dark text-white/70 border-white/10'}`}>
                                                <span className="material-symbols-outlined text-2xl">{item.icon}</span>
                                            </div>
                                            <span className={`text-[10px] font-bold truncate w-full text-center ${isActive ? 'text-white' : 'text-text-dark-secondary'}`}>{item.label}</span>
                                        </button>
                                    );
                                })}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Sidebar;
