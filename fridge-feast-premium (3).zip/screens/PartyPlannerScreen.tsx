import React, { useState } from 'react';
import { generatePartyPlan } from '../common/geminiService';
import Spinner from '../components/common/Spinner';

const PartyPlannerScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [guests, setGuests] = useState(10);
    const [duration, setDuration] = useState(4);
    const [type, setType] = useState('Dinner');
    const [plan, setPlan] = useState<any>(null);
    const [loading, setLoading] = useState(false);

    const handlePlan = async () => {
        setLoading(true);
        const res = await generatePartyPlan(guests, duration, type);
        setPlan(res);
        setLoading(false);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Party Planner</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6 overflow-y-auto">
                <div className="space-y-4">
                    <div className="flex gap-4">
                        <div className="flex-1">
                            <label className="text-xs font-bold text-text-dark-secondary uppercase ml-2">Guests</label>
                            <input type="number" value={guests} onChange={e => setGuests(Number(e.target.value))} className="w-full h-12 bg-white/5 rounded-2xl px-4 text-white border border-white/10" />
                        </div>
                        <div className="flex-1">
                            <label className="text-xs font-bold text-text-dark-secondary uppercase ml-2">Hours</label>
                            <input type="number" value={duration} onChange={e => setDuration(Number(e.target.value))} className="w-full h-12 bg-white/5 rounded-2xl px-4 text-white border border-white/10" />
                        </div>
                    </div>
                    <div>
                        <label className="text-xs font-bold text-text-dark-secondary uppercase ml-2">Type</label>
                        <select value={type} onChange={e => setType(e.target.value)} className="w-full h-12 bg-white/5 rounded-2xl px-4 text-white border border-white/10">
                            <option value="Dinner" className="text-black">Dinner Party</option>
                            <option value="Cocktail" className="text-black">Cocktail Hour</option>
                            <option value="BBQ" className="text-black">BBQ</option>
                        </select>
                    </div>
                    <button onClick={handlePlan} disabled={loading} className="w-full h-14 bg-pink-600 rounded-full text-white font-bold text-lg shadow-lg shadow-pink-600/20">{loading ? <Spinner /> : 'Calculate Quantities'}</button>
                </div>

                {plan && (
                    <div className="liquid-panel p-6 rounded-[32px] border border-white/5 space-y-6">
                        <div>
                            <h3 className="text-lg font-bold text-white mb-2 border-b border-white/10 pb-1">Food List</h3>
                            <ul className="list-disc pl-5 text-sm text-text-dark-secondary space-y-1">
                                {plan.foodRequirements.map((item: string, i: number) => <li key={i}>{item}</li>)}
                            </ul>
                        </div>
                        <div>
                            <h3 className="text-lg font-bold text-white mb-2 border-b border-white/10 pb-1">Drink List</h3>
                            <ul className="list-disc pl-5 text-sm text-text-dark-secondary space-y-1">
                                {plan.drinkRequirements.map((item: string, i: number) => <li key={i}>{item}</li>)}
                            </ul>
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
};
export default PartyPlannerScreen;