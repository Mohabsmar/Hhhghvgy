import React, { useState } from 'react';
import { analyzeTasteProfile } from '../common/geminiService';
import Spinner from '../components/common/Spinner';

const QUESTIONS = [
    "How do you drink your coffee?",
    "Pick a snack: Chips or Chocolate?",
    "Spice level preference?",
    "Favorite fruit?",
    "Pick a cuisine:"
];

const TasteProfilerScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [answers, setAnswers] = useState<string[]>(Array(5).fill(''));
    const [result, setResult] = useState<any>(null);
    const [loading, setLoading] = useState(false);

    const handleAnalyze = async () => {
        setLoading(true);
        const res = await analyzeTasteProfile(answers);
        setResult(res);
        setLoading(false);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Taste Profiler</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 overflow-y-auto pb-32">
                {!result ? (
                    <div className="space-y-6">
                        {QUESTIONS.map((q, i) => (
                            <div key={i}>
                                <label className="block text-white font-bold mb-2 text-sm uppercase tracking-wider">{q}</label>
                                <input value={answers[i]} onChange={e => {
                                    const newA = [...answers];
                                    newA[i] = e.target.value;
                                    setAnswers(newA);
                                }} className="w-full bg-white/5 rounded-xl border border-white/10 px-4 py-3 text-white focus:border-primary" placeholder="Type answer..." />
                            </div>
                        ))}
                        <button onClick={handleAnalyze} disabled={loading} className="w-full h-14 bg-primary text-white font-bold rounded-full mt-4">{loading ? <Spinner /> : 'Analyze Palate'}</button>
                    </div>
                ) : (
                    <div className="liquid-panel p-8 rounded-[40px] border border-primary/30 text-center">
                        <h2 className="text-4xl font-black text-white mb-2">{result.archetype}</h2>
                        <p className="text-text-dark-secondary mb-8 leading-relaxed">{result.description}</p>
                        <div className="grid grid-cols-2 gap-4">
                            {Object.entries(result.scores).map(([k, v]: any) => (
                                <div key={k} className="bg-white/5 p-3 rounded-xl">
                                    <span className="text-xs font-bold text-white uppercase block mb-1">{k}</span>
                                    <div className="h-1.5 bg-white/10 rounded-full overflow-hidden"><div style={{width: `${v}%`}} className="h-full bg-primary"></div></div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
};
export default TasteProfilerScreen;