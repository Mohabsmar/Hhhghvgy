
import React, { useState } from 'react';

const FermentationLogScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [logs, setLogs] = useState([{ id: '1', name: 'Sourdough Starter', start: '2023-10-01', status: 'Active' }]);
    
    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Fermentation Lab</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6">
                <div className="liquid-panel p-6 rounded-[32px] border border-white/5 mb-6">
                    <h3 className="font-bold text-white text-lg mb-2">My Projects</h3>
                    {logs.map(log => (
                        <div key={log.id} className="flex justify-between items-center bg-white/5 p-4 rounded-2xl border border-white/5">
                            <div>
                                <h4 className="font-bold text-white">{log.name}</h4>
                                <p className="text-xs text-text-dark-secondary">Started: {log.start}</p>
                            </div>
                            <span className="px-3 py-1 rounded-full bg-green-500/20 text-green-400 text-xs font-bold uppercase">{log.status}</span>
                        </div>
                    ))}
                </div>
                <button className="w-full py-4 rounded-2xl border-2 border-dashed border-white/20 text-white/50 font-bold hover:text-white hover:border-white/40 transition-colors">
                    + New Batch
                </button>
            </main>
        </div>
    );
};
export default FermentationLogScreen;
