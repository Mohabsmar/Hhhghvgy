import React, { useState, useEffect } from 'react';
import { getSeasonalProduce } from '../common/geminiService';
import Spinner from '../components/common/Spinner';

const SeasonalGuideScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [data, setData] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [hemisphere, setHemisphere] = useState<'Northern' | 'Southern'>('Northern');
    
    useEffect(() => {
        const fetch = async () => {
            setLoading(true);
            const month = new Date().toLocaleString('default', { month: 'long' });
            const res = await getSeasonalProduce(month, hemisphere);
            setData(res);
            setLoading(false);
        };
        fetch();
    }, [hemisphere]);

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Seasonal Guide</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6 overflow-y-auto">
                <div className="flex bg-white/5 p-1 rounded-full border border-white/5">
                    <button onClick={() => setHemisphere('Northern')} className={`flex-1 py-2 rounded-full text-xs font-bold transition-all ${hemisphere==='Northern' ? 'bg-primary text-white' : 'text-white/50'}`}>Northern</button>
                    <button onClick={() => setHemisphere('Southern')} className={`flex-1 py-2 rounded-full text-xs font-bold transition-all ${hemisphere==='Southern' ? 'bg-primary text-white' : 'text-white/50'}`}>Southern</button>
                </div>

                {loading ? <div className="flex justify-center pt-20"><Spinner className="size-10 text-primary" /></div> : (
                    <div className="space-y-8">
                        <div className="text-center">
                            <h2 className="text-3xl font-black text-white">{data?.month}</h2>
                            <p className="text-primary font-bold uppercase tracking-widest text-xs">Peak Season</p>
                        </div>
                        
                        <div>
                            <h3 className="text-lg font-bold text-white mb-4 border-b border-white/10 pb-2">Fruits</h3>
                            <div className="flex flex-wrap gap-2">
                                {data?.fruits.map((f: string) => (
                                    <span key={f} className="px-4 py-2 rounded-full bg-orange-500/20 text-orange-300 text-sm font-bold border border-orange-500/20">{f}</span>
                                ))}
                            </div>
                        </div>
                        <div>
                            <h3 className="text-lg font-bold text-white mb-4 border-b border-white/10 pb-2">Vegetables</h3>
                            <div className="flex flex-wrap gap-2">
                                {data?.vegetables.map((f: string) => (
                                    <span key={f} className="px-4 py-2 rounded-full bg-green-500/20 text-green-300 text-sm font-bold border border-green-500/20">{f}</span>
                                ))}
                            </div>
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
};
export default SeasonalGuideScreen;