import React, { useState, useEffect } from 'react';
import { Store, Language } from '../types';
import { searchNearbyStores } from '../common/geminiService';
import Spinner from '../components/common/Spinner';
import { getTranslation } from '../constants';

interface StoreLocatorProps {
    lang: Language;
}

const StoreLocatorScreen: React.FC<StoreLocatorProps> = ({ lang }) => {
    const [stores, setStores] = useState<Store[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [locationError, setLocationError] = useState<string | null>(null);
    const [selectedStore, setSelectedStore] = useState<Store | null>(null);
    const [checkingStock, setCheckingStock] = useState(false);
    const [manualQuery, setManualQuery] = useState('');
    const [searchMode, setSearchMode] = useState<'gps' | 'manual'>('gps');
    const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
    
    const t = (key: any) => getTranslation(lang, key);

    const handleSearch = async (type: 'gps' | 'manual') => {
        setIsLoading(true);
        setLocationError(null);
        setStores([]);

        if (type === 'manual') {
             if (!manualQuery.trim()) {
                 setLocationError("Please enter a city or address.");
                 setIsLoading(false);
                 return;
             }
             try {
                 const results = await searchNearbyStores({ query: manualQuery, lang });
                 setStores(results);
                 if (results.length === 0) setLocationError("No stores found. Try a different search.");
             } catch (err) {
                 setLocationError("Failed to find stores.");
             } finally {
                 setIsLoading(false);
             }
        } else {
            if (!navigator.geolocation) {
                setLocationError("Geolocation is not supported.");
                setIsLoading(false);
                return;
            }

            navigator.geolocation.getCurrentPosition(
                async (position) => {
                    try {
                        const { latitude, longitude } = position.coords;
                        const results = await searchNearbyStores({ lat: latitude, lng: longitude, lang });
                        setStores(results);
                        if (results.length === 0) setLocationError("No stores found nearby.");
                    } catch (err) {
                        setLocationError("Failed to find stores nearby.");
                    } finally {
                        setIsLoading(false);
                    }
                },
                (error) => {
                    setIsLoading(false);
                    if (error.code === error.PERMISSION_DENIED) {
                        setLocationError("Permission denied. Try manual search.");
                        setSearchMode('manual');
                    } else {
                        setLocationError("Unable to retrieve location.");
                    }
                }
            );
        }
    };

    const handleCheckAvailability = () => {
        setCheckingStock(true);
        setTimeout(() => {
            setCheckingStock(false);
            alert("In Stock: 85% of your list is likely available here.");
        }, 2000);
    };

    const handlePriceEstimate = () => {
         alert(`AI Estimate: A typical basket here costs approx. $${(40 + Math.random() * 50).toFixed(2)} based on area pricing.`);
    }

    const handleOpenMap = () => {
        setViewMode('map');
    };

    return (
        <div className="px-5 pb-32 min-h-screen flex flex-col font-display">
            {/* MAIN CONTENT OR LIST VIEW */}
            {viewMode === 'list' && (
                <>
                    <header className="flex items-center pt-8 pb-4 justify-between sticky top-0 liquid-glass z-30 -mx-5 px-5 animate-slide-up border-b border-white/5 rounded-b-[32px]" style={{ animationDuration: '0.5s' }}>
                        <div>
                            <h1 className="text-text-dark text-2xl font-extrabold leading-tight tracking-tight">
                            {t('stores')}
                            </h1>
                        </div>
                    </header>

                    <div className="mb-6 mt-6 space-y-4 animate-slide-up" style={{ animationDelay: '0.1s', animationFillMode: 'both' }}>
                        <div className="flex bg-surface-dark rounded-full p-1.5 border border-white/5 shadow-lg hover:scale-[1.02] transition-transform duration-300">
                            <button 
                                onClick={() => setSearchMode('gps')}
                                className={`flex-1 py-3 rounded-full text-sm font-bold transition-all duration-300 flex items-center justify-center gap-2 ${searchMode === 'gps' ? 'bg-primary text-white shadow-md' : 'text-text-dark-secondary hover:text-white'}`}
                            >
                                <span className="material-symbols-outlined text-lg">my_location</span>
                                {t('nearMe')}
                            </button>
                            <button 
                                onClick={() => setSearchMode('manual')}
                                className={`flex-1 py-3 rounded-full text-sm font-bold transition-all duration-300 flex items-center justify-center gap-2 ${searchMode === 'manual' ? 'bg-primary text-white shadow-md' : 'text-text-dark-secondary hover:text-white'}`}
                            >
                                <span className="material-symbols-outlined text-lg">search</span>
                                {t('manualSearch')}
                            </button>
                        </div>

                        {searchMode === 'manual' && (
                            <div className="relative animate-fade-in">
                                <input 
                                    type="text" 
                                    value={manualQuery}
                                    onChange={(e) => setManualQuery(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && handleSearch('manual')}
                                    placeholder="Enter City..."
                                    className="w-full h-14 bg-surface-dark border border-white/10 rounded-full pl-6 pr-14 text-text-dark placeholder:text-text-dark-muted focus:ring-2 focus:ring-primary focus:outline-none shadow-sm transition-all"
                                />
                                <button 
                                    onClick={() => handleSearch('manual')}
                                    disabled={isLoading}
                                    className="absolute right-2 top-1/2 -translate-y-1/2 size-10 bg-primary text-white rounded-full flex items-center justify-center hover:bg-primary-600 transition-colors shadow-md active:scale-95"
                                >
                                    <span className="material-symbols-outlined text-xl">arrow_forward</span>
                                </button>
                            </div>
                        )}

                        {searchMode === 'gps' && stores.length === 0 && !isLoading && (
                            <button 
                                onClick={() => handleSearch('gps')}
                                className="w-full py-4 bg-surface-dark border border-primary/30 text-primary rounded-[32px] font-bold shadow-lg shadow-primary/10 active:scale-95 transition-all flex items-center justify-center gap-2 hover:bg-primary hover:text-white group relative overflow-hidden"
                            >
                                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 ease-in-out" />
                                <span className="material-symbols-outlined group-hover:rotate-12 transition-transform duration-300">location_searching</span>
                                {t('findStores')}
                            </button>
                        )}
                        
                        {locationError && (
                            <div className="p-4 bg-error/10 border border-error/20 rounded-[24px] text-error text-sm font-semibold flex items-start gap-3 animate-bounce" style={{ animationIterationCount: 1 }}>
                                <span className="material-symbols-outlined text-xl">warning</span>
                                <div>
                                    <p>{locationError}</p>
                                </div>
                            </div>
                        )}
                    </div>

                    {isLoading && (
                        <div className="flex-1 flex flex-col items-center justify-center opacity-70 animate-fade-in">
                            <Spinner className="w-12 h-12 text-primary mb-4" />
                            <p className="text-text-dark font-bold animate-pulse text-lg">{t('analyzing')}</p>
                        </div>
                    )}

                    {stores.length > 0 && (
                        <div className="flex-1 space-y-4 overflow-y-auto no-scrollbar animate-fade-in">
                            
                            {stores.map((store, index) => (
                                <div 
                                    key={store.id} 
                                    onClick={() => setSelectedStore(store)} 
                                    className="liquid-panel p-4 rounded-[32px] border border-white/5 active:scale-[0.98] transition-all duration-300 cursor-pointer hover:bg-white/5 hover:border-primary/20 flex gap-4 animate-slide-up group"
                                    style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'backwards' }}
                                >
                                    <div className="size-14 rounded-2xl bg-surface-dark-secondary flex items-center justify-center text-text-dark-secondary shrink-0 border border-white/5 shadow-inner group-hover:scale-110 transition-transform duration-300">
                                        <span className="material-symbols-outlined text-2xl group-hover:text-primary transition-colors">storefront</span>
                                    </div>
                                    <div className="flex-1 min-w-0 flex flex-col justify-center">
                                        <div className="flex justify-between items-start mb-1">
                                            <h3 className="font-bold text-text-dark truncate pr-2 text-lg">{store.name}</h3>
                                        </div>
                                        <p className="text-xs text-text-dark-secondary truncate font-medium opacity-80">{store.address}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </>
            )}

            {/* MAP MODE */}
            {viewMode === 'map' && selectedStore && (
                <div className="fixed inset-0 bg-background-dark z-[60] flex flex-col animate-fade-in">
                    {/* Floating Header */}
                    <div className="absolute top-0 left-0 right-0 p-5 z-20 flex justify-between safe-area-inset-top">
                        <button 
                            onClick={() => setViewMode('list')} 
                            className="size-12 rounded-full bg-surface-dark/80 backdrop-blur-md border border-white/10 text-white flex items-center justify-center shadow-xl active:scale-95 transition-transform"
                        >
                            <span className="material-symbols-outlined">arrow_back</span>
                        </button>
                    </div>

                    {/* Map Iframe */}
                    <div className="flex-1 relative bg-surface-dark-secondary w-full h-full">
                        <div className="absolute inset-0 flex items-center justify-center text-text-dark-secondary z-0">
                            <Spinner />
                        </div>
                        <iframe
                            width="100%"
                            height="100%"
                            style={{ border: 0, opacity: 0.9 }}
                            loading="lazy"
                            allowFullScreen
                            referrerPolicy="no-referrer-when-downgrade"
                            src={`https://maps.google.com/maps?q=${encodeURIComponent(selectedStore.name + ' ' + (selectedStore.address || ''))}&t=&z=15&ie=UTF8&iwloc=&output=embed`}
                            className="relative z-10 grayscale-[0.2] contrast-[1.1] brightness-[0.8]"
                        ></iframe>
                        {/* Overlay Gradient for better UI integration */}
                        <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-background-dark to-transparent z-10 pointer-events-none"></div>
                    </div>

                    {/* Bottom Sheet Overlay */}
                    <div className="absolute bottom-0 left-0 right-0 p-6 z-20 safe-area-inset-bottom">
                        <div className="bg-surface-dark/95 backdrop-blur-xl border border-white/10 p-6 rounded-[32px] shadow-2xl animate-slide-up">
                            <div className="flex justify-between items-start mb-4">
                                <div>
                                    <h2 className="text-2xl font-bold text-white leading-tight mb-1">{selectedStore.name}</h2>
                                    <p className="text-text-dark-secondary text-sm">{selectedStore.address}</p>
                                </div>
                            </div>
                            
                            <div className="flex gap-3">
                                <a 
                                    href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(selectedStore.name + ' ' + selectedStore.address)}`}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="flex-1 h-14 bg-primary text-white rounded-full font-bold text-lg flex items-center justify-center gap-2 shadow-lg shadow-primary/20 active:scale-95 transition-transform"
                                >
                                    <span className="material-symbols-outlined">directions</span>
                                    {t('directions')}
                                </a>
                                <button 
                                    onClick={() => handleCheckAvailability()}
                                    className="size-14 rounded-full bg-surface-dark border border-white/10 text-primary flex items-center justify-center active:scale-95 transition-transform hover:bg-white/5"
                                >
                                    <span className="material-symbols-outlined">inventory_2</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* STORE DETAIL MODAL (List View) */}
            {selectedStore && viewMode === 'list' && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-end justify-center p-4 animate-fade-in">
                    <div className="liquid-glass w-full max-w-md rounded-[40px] p-6 animate-slide-up border border-white/10 shadow-2xl relative overflow-hidden" onClick={e => e.stopPropagation()}>
                        {/* Glow effect */}
                        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/20 blur-[50px] pointer-events-none rounded-full"></div>

                        <div className="flex justify-between items-start mb-6 relative z-10">
                            <div className="flex-1 pr-4">
                                <h2 className="text-2xl font-bold text-white leading-tight">{selectedStore.name}</h2>
                                <p className="text-text-dark-secondary text-sm mt-1 font-medium">{selectedStore.address !== 'View on map' ? selectedStore.address : 'Nearby'}</p>
                            </div>
                             <button onClick={() => setSelectedStore(null)} className="size-10 rounded-full bg-white/5 flex items-center justify-center shrink-0 hover:bg-white/10 backdrop-blur-md border border-white/5">
                                <span className="material-symbols-outlined">close</span>
                            </button>
                        </div>

                        <div className="space-y-3 mb-6 relative z-10">
                             <button 
                                onClick={handleOpenMap}
                                className="w-full py-4 bg-surface-dark-secondary text-text-dark font-bold rounded-2xl flex items-center justify-center gap-2 border border-white/5 hover:bg-white/5 transition-colors group"
                            >
                                <span className="material-symbols-outlined text-primary group-hover:scale-110 transition-transform">map</span>
                                View in App Map
                            </button>
                            
                            <button 
                                onClick={handleCheckAvailability}
                                disabled={checkingStock}
                                className="w-full py-4 bg-primary text-white font-bold rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-primary/20 active:scale-95 transition-transform hover:bg-primary-600"
                            >
                                {checkingStock ? (
                                    <div className="size-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                ) : (
                                    <>
                                    <span className="material-symbols-outlined">inventory_2</span>
                                    {t('checkStock')}
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default StoreLocatorScreen;