
import React, { useState } from 'react';
import { User, NavBarConfig } from '../types';
import BottomNav from '../components/BottomNav';

interface NavBarEditorScreenProps {
    user: User;
    onUpdateUser: (user: Partial<User>) => void;
    onExit: () => void;
}

const NavBarEditorScreen: React.FC<NavBarEditorScreenProps> = ({ user, onUpdateUser, onExit }) => {
    const [config, setConfig] = useState<NavBarConfig>(user.preferences.navBar);
    const [isPreviewing, setIsPreviewing] = useState(false);

    const updateConfig = (key: keyof NavBarConfig, value: any) => {
        const newConfig = { ...config, [key]: value };
        if (key === 'width' && typeof value === 'number') {
             newConfig.style = value < 100 ? 'floating' : 'fixed';
        }
        setConfig(newConfig);
        onUpdateUser({ preferences: { ...user.preferences, navBar: newConfig } });
    };

    return (
        <div className="fixed inset-0 bg-[#0F172A] z-50 flex flex-col">
            {/* Platform Area */}
            <div className="flex-1 relative overflow-hidden select-none bg-[#0F172A]">
                
                {/* Mode Switcher */}
                {isPreviewing ? (
                    // Preview Mode: Mock Content
                    <div className="absolute inset-0 bg-white animate-fade-in">
                        <div className="h-full bg-background-dark relative overflow-hidden">
                             {/* Mock App Content */}
                             <div className="p-6 pt-20 space-y-4 opacity-50">
                                <div className="h-40 bg-surface-dark rounded-[32px] w-full border border-white/10"></div>
                                <div className="flex gap-3">
                                    <div className="h-32 bg-surface-dark rounded-[24px] flex-1 border border-white/10"></div>
                                    <div className="h-32 bg-surface-dark rounded-[24px] flex-1 border border-white/10"></div>
                                </div>
                                <div className="h-20 bg-surface-dark rounded-[24px] w-full border border-white/10"></div>
                                <div className="h-20 bg-surface-dark rounded-[24px] w-full border border-white/10"></div>
                                <div className="h-20 bg-surface-dark rounded-[24px] w-full border border-white/10"></div>
                             </div>
                             <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background-dark to-transparent pointer-events-none"></div>
                        </div>
                    </div>
                ) : (
                    // Blueprint Mode: Dotted Grid
                    <div 
                        className="absolute inset-0 animate-fade-in"
                        style={{
                            backgroundImage: 'radial-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px)',
                            backgroundSize: '24px 24px',
                            backgroundColor: '#0F172A'
                        }}
                    >
                        {/* Center Guide Line */}
                        <div className="absolute inset-y-0 left-1/2 w-px bg-primary/30"></div>
                        {/* Bottom Safe Area Guide */}
                        <div className="absolute bottom-0 left-0 right-0 h-[34px] border-t border-dashed border-white/10 pointer-events-none flex items-start justify-end px-2 pt-1">
                            <span className="text-[10px] text-white/20 font-mono">HOME INDICATOR AREA</span>
                        </div>
                        
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-30">
                            <p className="text-xs font-mono text-primary tracking-[0.3em]">NAVIGATION BLUEPRINT</p>
                        </div>
                    </div>
                )}

                {/* Render Actual Nav Bar Component for Preview */}
                <BottomNav 
                    activeScreen={'home'} 
                    onNavigate={() => {}} 
                    lang={user.preferences.language} 
                    config={config}
                    isPreview={true} 
                />
            </div>

            {/* Editor Panel */}
            <div className="h-[55vh] bg-surface-dark border-t border-white/10 flex flex-col shadow-[0_-10px_40px_rgba(0,0,0,0.5)] rounded-t-[32px] relative z-10">
                
                 {/* Floating Preview Trigger */}
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 z-20">
                    <button
                        onMouseDown={() => setIsPreviewing(true)}
                        onMouseUp={() => setIsPreviewing(false)}
                        onMouseLeave={() => setIsPreviewing(false)}
                        onTouchStart={() => setIsPreviewing(true)}
                        onTouchEnd={() => setIsPreviewing(false)}
                        className="px-8 py-3 bg-white text-black rounded-full font-bold text-sm shadow-xl border-4 border-surface-dark hover:scale-105 active:scale-95 transition-transform select-none flex items-center gap-2"
                    >
                        <span className="material-symbols-outlined text-lg">visibility</span>
                        Hold to Preview
                    </button>
                </div>

                <header className="flex items-center justify-between p-5 border-b border-white/10 mt-4">
                    <h2 className="text-lg font-bold text-white">Nav Bar Studio</h2>
                    <button onClick={onExit} className="px-6 py-2 bg-primary text-white rounded-full text-sm font-bold shadow-lg shadow-primary/20">Done</button>
                </header>
                
                <div className="flex-1 overflow-y-auto p-6 space-y-8 pb-10 no-scrollbar">
                    
                    {/* Placement & Position */}
                    <div className="p-4 bg-white/5 rounded-2xl border border-white/10 space-y-4">
                        <h3 className="text-xs font-bold text-text-dark-secondary uppercase tracking-wider mb-2">Placement & Position</h3>
                        
                        {/* Anchor */}
                        <div className="flex gap-3">
                            <button onClick={() => updateConfig('verticalPosition', 'top')} className={`flex-1 py-3 rounded-xl border font-bold text-xs transition-all ${config.verticalPosition === 'top' ? 'bg-primary border-primary text-white' : 'bg-transparent border-white/10 text-white/50'}`}>
                                Top
                            </button>
                            <button onClick={() => updateConfig('verticalPosition', 'bottom')} className={`flex-1 py-3 rounded-xl border font-bold text-xs transition-all ${config.verticalPosition === 'bottom' ? 'bg-primary border-primary text-white' : 'bg-transparent border-white/10 text-white/50'}`}>
                                Bottom
                            </button>
                        </div>

                        {/* Container Alignment */}
                        <div className="flex gap-2">
                             <button onClick={() => updateConfig('containerPosition', 'left')} className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${config.containerPosition === 'left' ? 'bg-white/20 text-white' : 'text-white/40 bg-white/5'}`}>Left Align</button>
                             <button onClick={() => updateConfig('containerPosition', 'center')} className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${config.containerPosition === 'center' ? 'bg-white/20 text-white' : 'text-white/40 bg-white/5'}`}>Center</button>
                             <button onClick={() => updateConfig('containerPosition', 'right')} className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${config.containerPosition === 'right' ? 'bg-white/20 text-white' : 'text-white/40 bg-white/5'}`}>Right Align</button>
                        </div>

                        {/* Offsets */}
                        <div className="grid grid-cols-2 gap-4">
                             <div className="space-y-2">
                                <div className="flex justify-between text-xs font-bold text-text-dark-secondary uppercase tracking-wider">
                                    <span>Vertical Y</span>
                                    <span className="text-primary">{config.bottomOffset}px</span>
                                </div>
                                <input type="range" min="0" max="100" value={config.bottomOffset} onChange={(e) => updateConfig('bottomOffset', Number(e.target.value))} className="w-full accent-primary h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer" />
                            </div>
                             <div className="space-y-2">
                                <div className="flex justify-between text-xs font-bold text-text-dark-secondary uppercase tracking-wider">
                                    <span>Horizontal X</span>
                                    <span className="text-primary">{config.horizontalOffset || 0}px</span>
                                </div>
                                <input type="range" min="-100" max="100" value={config.horizontalOffset || 0} onChange={(e) => updateConfig('horizontalOffset', Number(e.target.value))} className="w-full accent-primary h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer" />
                            </div>
                        </div>
                    </div>

                    {/* Style Presets */}
                    <div className="flex gap-4">
                        <button 
                            onClick={() => {
                                updateConfig('style', 'floating');
                                updateConfig('width', 90);
                                updateConfig('borderRadius', 32);
                            }}
                            className={`flex-1 py-3 rounded-xl border font-bold transition-all ${config.style === 'floating' ? 'bg-primary border-primary text-white' : 'bg-transparent border-white/10 text-white/50'}`}
                        >
                            Floating
                        </button>
                        <button 
                             onClick={() => {
                                updateConfig('style', 'fixed');
                                updateConfig('width', 100);
                                updateConfig('borderRadius', 0);
                                updateConfig('bottomOffset', 0);
                                updateConfig('horizontalOffset', 0);
                                updateConfig('containerPosition', 'center');
                            }}
                            className={`flex-1 py-3 rounded-xl border font-bold transition-all ${config.style === 'fixed' ? 'bg-primary border-primary text-white' : 'bg-transparent border-white/10 text-white/50'}`}
                        >
                            Fixed
                        </button>
                    </div>

                    {/* Dimensions Sliders */}
                    <div className="space-y-6">
                        <div className="space-y-3">
                            <div className="flex justify-between text-xs font-bold text-text-dark-secondary uppercase tracking-wider">
                                <span>Background Opacity</span>
                                <span className="text-primary">{config.backgroundOpacity}%</span>
                            </div>
                            <input type="range" min="0" max="100" value={config.backgroundOpacity} onChange={(e) => updateConfig('backgroundOpacity', Number(e.target.value))} className="w-full accent-primary h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer" />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                             <div className="space-y-3">
                                <div className="flex justify-between text-xs font-bold text-text-dark-secondary uppercase tracking-wider">
                                    <span>Width</span>
                                    <span className="text-primary">{config.width}%</span>
                                </div>
                                <input type="range" min="50" max="100" value={config.width} onChange={(e) => updateConfig('width', Number(e.target.value))} className="w-full accent-primary h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer" />
                            </div>
                             <div className="space-y-3">
                                <div className="flex justify-between text-xs font-bold text-text-dark-secondary uppercase tracking-wider">
                                    <span>Radius</span>
                                    <span className="text-primary">{config.borderRadius}px</span>
                                </div>
                                <input type="range" min="0" max="50" value={config.borderRadius} onChange={(e) => updateConfig('borderRadius', Number(e.target.value))} className="w-full accent-primary h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer" />
                            </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                             <div className="space-y-3">
                                <div className="flex justify-between text-xs font-bold text-text-dark-secondary uppercase tracking-wider">
                                    <span>Border Width</span>
                                    <span className="text-primary">{config.borderWidth}px</span>
                                </div>
                                <input type="range" min="0" max="5" value={config.borderWidth} onChange={(e) => updateConfig('borderWidth', Number(e.target.value))} className="w-full accent-primary h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer" />
                            </div>
                        </div>
                    </div>

                    {/* Colors */}
                    <div className="grid grid-cols-2 gap-3">
                         <div className="space-y-2">
                            <label className="text-xs font-bold text-text-dark-secondary uppercase tracking-wider">Background</label>
                            <div className="flex items-center gap-2 bg-white/5 p-2 rounded-xl border border-white/10">
                                <input type="color" value={config.backgroundColor} onChange={(e) => updateConfig('backgroundColor', e.target.value)} className="size-8 rounded-lg overflow-hidden border-none bg-transparent cursor-pointer" />
                            </div>
                        </div>
                         <div className="space-y-2">
                            <label className="text-xs font-bold text-text-dark-secondary uppercase tracking-wider">Border</label>
                            <div className="flex items-center gap-2 bg-white/5 p-2 rounded-xl border border-white/10">
                                <input type="color" value={config.borderColor} onChange={(e) => updateConfig('borderColor', e.target.value)} className="size-8 rounded-lg overflow-hidden border-none bg-transparent cursor-pointer" />
                            </div>
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-text-dark-secondary uppercase tracking-wider">Icon</label>
                            <div className="flex items-center gap-2 bg-white/5 p-2 rounded-xl border border-white/10">
                                <input type="color" value={config.iconColor} onChange={(e) => updateConfig('iconColor', e.target.value)} className="size-8 rounded-lg overflow-hidden border-none bg-transparent cursor-pointer" />
                            </div>
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-text-dark-secondary uppercase tracking-wider">Active</label>
                            <div className="flex items-center gap-2 bg-white/5 p-2 rounded-xl border border-white/10">
                                <input type="color" value={config.activeIconColor} onChange={(e) => updateConfig('activeIconColor', e.target.value)} className="size-8 rounded-lg overflow-hidden border-none bg-transparent cursor-pointer" />
                            </div>
                        </div>
                    </div>
                    
                    {/* Toggles */}
                    <div className="flex gap-3">
                        <button 
                            onClick={() => updateConfig('blurEffect', !config.blurEffect)}
                            className={`flex-1 py-3 rounded-xl border font-bold text-xs transition-all ${config.blurEffect ? 'bg-white/10 border-white/30 text-white' : 'bg-transparent border-white/10 text-white/50'}`}
                        >
                            Blur Effect
                        </button>
                        <button 
                            onClick={() => updateConfig('showLabels', !config.showLabels)}
                            className={`flex-1 py-3 rounded-xl border font-bold text-xs transition-all ${config.showLabels ? 'bg-white/10 border-white/30 text-white' : 'bg-transparent border-white/10 text-white/50'}`}
                        >
                            Labels
                        </button>
                    </div>

                </div>
            </div>
        </div>
    );
};

export default NavBarEditorScreen;
