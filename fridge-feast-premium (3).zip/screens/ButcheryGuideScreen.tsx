import React, { useState } from 'react';
import { askCulinaryExpert } from '../common/geminiService';
import Spinner from '../components/common/Spinner';

const ButcheryGuideScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [query, setQuery] = useState('');
    const [result, setResult] = useState('');
    const [loading, setLoading] = useState(false);

    const handleAsk = async () => {
        setLoading(true);
        const res = await askCulinaryExpert('Master Butcher', `Explain the cut: ${query}. Where it comes from, best cooking method, and characteristics.`);
        setResult(res);
        setLoading(false);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Butchery 101</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6">
                <div className="text-center py-6">
                    <span className="material-symbols-outlined text-6xl text-red-700 mb-4">restaurant_menu</span>
                    <h2 className="text-2xl font-bold text-white">Know Your Cuts</h2>
                </div>
                <input value={query} onChange={e => setQuery(e.target.value)} placeholder="e.g. Ribeye, Brisket, Pork Shoulder" className="w-full h-14 bg-white/5 rounded-full px-6 text-white border border-white/10 text-center text-lg focus:border-red-700" />
                <button onClick={handleAsk} disabled={loading} className="w-full h-14 bg-red-800 rounded-full text-white font-bold text-lg shadow-lg shadow-red-800/20">{loading ? <Spinner /> : 'Explain Cut'}</button>
                {result && <div className="liquid-panel p-6 rounded-[32px] border border-white/5 text-white leading-relaxed whitespace-pre-wrap">{result}</div>}
            </main>
        </div>
    );
};
export default ButcheryGuideScreen;