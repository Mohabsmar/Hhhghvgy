
import React, { useState } from 'react';

const HomeBrewScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [og, setOg] = useState(1.050);
    const [fg, setFg] = useState(1.010);

    const abv = ((og - fg) * 131.25).toFixed(2);

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Home Brewer</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-8">
                <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <label className="text-amber-400 text-xs font-bold uppercase">Original Gravity</label>
                        <input type="number" step="0.001" value={og} onChange={e => setOg(parseFloat(e.target.value))} className="w-full bg-white/5 rounded-xl px-4 py-4 text-white font-mono text-xl" />
                    </div>
                    <div className="space-y-2">
                        <label className="text-amber-400 text-xs font-bold uppercase">Final Gravity</label>
                        <input type="number" step="0.001" value={fg} onChange={e => setFg(parseFloat(e.target.value))} className="w-full bg-white/5 rounded-xl px-4 py-4 text-white font-mono text-xl" />
                    </div>
                </div>

                <div className="liquid-panel p-8 rounded-[40px] border border-amber-500/20 text-center bg-amber-500/5">
                    <span className="material-symbols-outlined text-4xl text-amber-500 mb-2">sports_bar</span>
                    <h2 className="text-6xl font-black text-white">{abv}%</h2>
                    <p className="text-amber-200 text-sm font-bold uppercase tracking-widest mt-2">Alcohol By Volume</p>
                </div>
            </main>
        </div>
    );
};
export default HomeBrewScreen;
