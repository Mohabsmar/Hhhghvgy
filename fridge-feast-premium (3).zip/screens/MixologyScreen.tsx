import React, { useState } from 'react';
import { generateCocktail } from '../common/geminiService';
import Spinner from '../components/common/Spinner';
import RecipeDetailScreen from '../components/common/screens/RecipeDetailScreen';

const MixologyScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [input, setInput] = useState('');
    const [recipe, setRecipe] = useState<any>(null);
    const [loading, setLoading] = useState(false);

    const handleMix = async () => {
        if(!input) return;
        setLoading(true);
        try {
            const res = await generateCocktail(input);
            setRecipe(res);
        } catch (e) { alert("Failed"); }
        setLoading(false);
    };

    if (recipe) return <RecipeDetailScreen recipe={recipe} onExit={() => setRecipe(null)} lang='en' onStartCooking={() => {}} chartMode='calories' />;

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Mixology AI</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 flex flex-col items-center justify-center space-y-8">
                <div className="text-center">
                    <span className="material-symbols-outlined text-7xl text-blue-400 mb-4">local_bar</span>
                    <h2 className="text-2xl font-bold text-white">What's your vibe?</h2>
                    <p className="text-text-dark-secondary">Enter a mood or spirit.</p>
                </div>
                <input value={input} onChange={e => setInput(e.target.value)} placeholder="e.g. Tropical, Gin, Sad" className="w-full max-w-sm h-14 bg-white/5 rounded-full px-6 text-white border border-white/10 text-center text-lg focus:border-blue-500" />
                <button onClick={handleMix} disabled={loading} className="w-full max-w-sm h-14 bg-blue-600 rounded-full text-white font-bold text-lg shadow-lg shadow-blue-600/20">{loading ? <Spinner /> : 'Mix Drink'}</button>
            </main>
        </div>
    );
};
export default MixologyScreen;