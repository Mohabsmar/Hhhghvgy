
import React, { useState } from 'react';

const MealPrepScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [tasks, setTasks] = useState<{id: string, text: string, done: boolean}[]>([
        { id: '1', text: 'Chop vegetables', done: false },
        { id: '2', text: 'Marinate chicken', done: true },
        { id: '3', text: 'Boil rice', done: false },
    ]);
    const [input, setInput] = useState('');

    const addTask = () => {
        if(!input) return;
        setTasks([...tasks, { id: Date.now().toString(), text: input, done: false }]);
        setInput('');
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Meal Prep</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6">
                <div className="flex gap-2">
                    <input value={input} onChange={e => setInput(e.target.value)} placeholder="Add task..." className="flex-1 h-12 bg-white/5 rounded-full px-6 text-white border border-white/10" onKeyDown={e => e.key === 'Enter' && addTask()} />
                    <button onClick={addTask} className="size-12 rounded-full bg-amber-500 text-black flex items-center justify-center"><span className="material-symbols-outlined">add</span></button>
                </div>
                <div className="space-y-3">
                    {tasks.map(task => (
                        <div key={task.id} onClick={() => setTasks(tasks.map(t => t.id === task.id ? {...t, done: !t.done} : t))} className={`p-4 rounded-2xl border flex items-center gap-4 cursor-pointer transition-all ${task.done ? 'bg-green-500/10 border-green-500/20 opacity-60' : 'bg-white/5 border-white/5'}`}>
                            <div className={`size-6 rounded-full border-2 flex items-center justify-center ${task.done ? 'bg-green-500 border-green-500' : 'border-white/30'}`}>
                                {task.done && <span className="material-symbols-outlined text-black text-sm font-bold">check</span>}
                            </div>
                            <span className={`text-white font-medium ${task.done ? 'line-through' : ''}`}>{task.text}</span>
                        </div>
                    ))}
                </div>
            </main>
        </div>
    );
};
export default MealPrepScreen;
