
import React from 'react';

const FamilySyncScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Family Sync</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 flex flex-col items-center justify-center text-center space-y-8">
                <div className="size-64 bg-white p-4 rounded-3xl">
                    <img src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=stitch-family-join-123`} className="w-full h-full" />
                </div>
                <div>
                    <h2 className="text-2xl font-bold text-white">Scan to Join</h2>
                    <p className="text-text-dark-secondary mt-2 max-w-xs mx-auto">Let your family members scan this code to sync shopping lists and meal plans instantly.</p>
                </div>
                <button className="px-8 py-3 bg-white/10 rounded-full font-bold text-white hover:bg-white/20 transition-colors">Share Link</button>
            </main>
        </div>
    );
};
export default FamilySyncScreen;
