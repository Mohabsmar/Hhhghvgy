
import React, { useState } from 'react';

const ApplianceTrackerScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [items, setItems] = useState<{id:string, name: string, lastService: string}[]>([
        { id: '1', name: 'Coffee Machine', lastService: '2023-11-01' },
        { id: '2', name: 'Oven', lastService: '2023-05-15' }
    ]);
    const [newName, setNewName] = useState('');

    const add = () => {
        if(!newName) return;
        setItems([...items, { id: Date.now().toString(), name: newName, lastService: new Date().toISOString().split('T')[0] }]);
        setNewName('');
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Appliance Log</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6">
                <div className="flex gap-2">
                    <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="Appliance Name..." className="flex-1 h-12 bg-white/5 rounded-full px-6 text-white border border-white/10" />
                    <button onClick={add} className="size-12 rounded-full bg-blue-500 text-white flex items-center justify-center"><span className="material-symbols-outlined">add</span></button>
                </div>
                {items.map(item => (
                    <div key={item.id} className="liquid-panel p-4 rounded-[24px] border border-white/5 flex justify-between items-center">
                        <div>
                            <h3 className="font-bold text-white">{item.name}</h3>
                            <p className="text-xs text-text-dark-secondary">Serviced: {item.lastService}</p>
                        </div>
                        <button className="px-4 py-2 bg-white/10 rounded-full text-xs font-bold text-white hover:bg-blue-500 hover:text-white transition-colors">Log Service</button>
                    </div>
                ))}
            </main>
        </div>
    );
};
export default ApplianceTrackerScreen;
