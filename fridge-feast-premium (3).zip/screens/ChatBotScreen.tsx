import React, { useState, useEffect, useRef } from 'react';
import { chatWithChef } from '../common/geminiService';
import { Language, AppAction } from '../types';
import { getTranslation } from '../constants';
import Spinner from '../components/common/Spinner';

interface ChatBotScreenProps {
    onExit: () => void;
    lang: Language;
    onAction: (action: AppAction) => void;
    initialQuery?: string;
}

interface Message {
    id: string;
    role: 'user' | 'model';
    text: string;
    image?: string;
    isTyping?: boolean;
    dishProposal?: string;
}

const ChatBotScreen: React.FC<ChatBotScreenProps> = ({ onExit, lang, onAction, initialQuery }) => {
    const [messages, setMessages] = useState<Message[]>([
        { id: 'init', role: 'model', text: 'Hey! I\'m CalBot. Ask me for a recipe or show me some ingredients.' }
    ]);
    const [input, setInput] = useState('');
    const [selectedImage, setSelectedImage] = useState<string | null>(null);
    const [isTyping, setIsTyping] = useState(false);
    
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const hasRunInitialQuery = useRef(false);
    const t = (key: any) => getTranslation(lang, key);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages, isTyping, selectedImage]);

    // Handle Initial Query from other screens (like Scanner)
    useEffect(() => {
        if (initialQuery && !hasRunInitialQuery.current) {
            hasRunInitialQuery.current = true;
            handleSend(initialQuery);
        }
    }, [initialQuery]);

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setSelectedImage(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const triggerFileInput = () => {
        fileInputRef.current?.click();
    };

    const removeSelectedImage = () => {
        setSelectedImage(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    const handleSend = async (manualText?: string) => {
        const textToSend = manualText || input;
        if (!textToSend.trim() && !selectedImage) return;

        const userMsg: Message = { 
            id: Date.now().toString(), 
            role: 'user', 
            text: textToSend,
            image: selectedImage || undefined
        };

        setMessages(prev => [...prev, userMsg]);
        if (!manualText) setInput(''); // Only clear input if it was a manual type
        const imageToSend = selectedImage;
        setSelectedImage(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
        
        setIsTyping(true);

        const history = messages.map(m => {
            const parts: Array<any> = [{ text: m.text }];
            if (m.image) {
                parts.push({ text: "[User uploaded an image]" }); 
            }
            return {
                role: m.role,
                parts: parts
            };
        });

        try {
            let imageData = undefined;
            if (imageToSend) {
                const match = imageToSend.match(/^data:(.*);base64,(.*)$/);
                if (match) {
                    imageData = { mimeType: match[1], data: match[2] };
                }
            }

            const response = await chatWithChef(history, userMsg.text || (imageToSend ? "Analyze this image" : ""), imageData, lang);
            
            if (response.toolCalls && response.toolCalls.length > 0) {
                for (const toolCall of response.toolCalls) {
                    if (toolCall.name === 'propose_dish') {
                        const dishName = toolCall.args?.dishName;
                        if (dishName) {
                             setMessages(prev => [
                                 ...prev, 
                                 { 
                                     id: (Date.now() + 1).toString(), 
                                     role: 'model', 
                                     text: `I found a great match: ${dishName}.`,
                                     dishProposal: dishName
                                 }
                             ]);
                        }
                    } else if (toolCall.name === 'navigate_to') {
                        const screen = toolCall.args?.screen;
                        if (screen) {
                             setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'model', text: `Navigating to ${screen}...` }]);
                             setTimeout(() => {
                                 if (screen === 'scanner') onAction({ type: 'OPEN_SCANNER' });
                                 else if (screen === 'generator') onAction({ type: 'NAVIGATE', payload: 'discover' });
                                 else onAction({ type: 'NAVIGATE', payload: screen });
                             }, 800);
                        }
                    }
                }
            } else {
                setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'model', text: response.text }]);
            }
        } catch (error) {
            setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'model', text: "Sorry, connection error." }]);
        } finally {
            setIsTyping(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            {/* Header */}
            <header className="flex items-center justify-between px-6 py-4 liquid-glass border-b border-white/5 z-10">
                <div className="flex items-center gap-3">
                    <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white hover:bg-white/10 transition-colors">
                        <span className="material-symbols-outlined">arrow_back</span>
                    </button>
                    <div>
                        <h1 className="text-lg font-bold text-white">CalBot</h1>
                        <div className="flex items-center gap-1.5">
                            <span className="size-2 bg-green-500 rounded-full animate-pulse"></span>
                            <span className="text-xs text-text-dark-secondary">Online</span>
                        </div>
                    </div>
                </div>
                <div className="size-10 rounded-full bg-gradient-to-br from-primary to-secondary p-[1px]">
                    <div className="size-full rounded-full bg-surface-dark flex items-center justify-center">
                        <span className="material-symbols-outlined text-primary">smart_toy</span>
                    </div>
                </div>
            </header>

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-24">
                {messages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] rounded-2xl p-4 ${
                            msg.role === 'user' 
                            ? 'bg-primary text-black rounded-tr-none shadow-lg shadow-primary/20' 
                            : 'bg-surface-dark border border-white/10 text-white rounded-tl-none shadow-md'
                        }`}>
                            {msg.image && (
                                <img src={msg.image} alt="User upload" className="w-full rounded-lg mb-2 max-h-48 object-cover border border-black/10" />
                            )}
                            <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                            
                            {msg.dishProposal && (
                                <button 
                                    onClick={() => onAction({ type: 'GENERATE_RECIPE', payload: msg.dishProposal })}
                                    className="mt-3 w-full py-2.5 bg-black/20 rounded-xl text-xs font-bold flex items-center justify-center gap-2 hover:bg-black/30 transition-colors border border-black/5"
                                >
                                    <span className="material-symbols-outlined text-sm">restaurant_menu</span>
                                    Generate Recipe
                                </button>
                            )}
                        </div>
                    </div>
                ))}
                
                {isTyping && (
                    <div className="flex justify-start">
                        <div className="bg-surface-dark border border-white/10 rounded-2xl rounded-tl-none p-4 flex gap-1">
                            <span className="size-2 bg-white/40 rounded-full animate-bounce"></span>
                            <span className="size-2 bg-white/40 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></span>
                            <span className="size-2 bg-white/40 rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></span>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-background-dark via-background-dark to-transparent pb-safe safe-area-bottom z-20">
                <div className="relative flex items-end gap-2 p-2 bg-surface-dark/80 backdrop-blur-xl rounded-[32px] border border-white/10 shadow-2xl">
                    <input 
                        type="file" 
                        accept="image/*" 
                        ref={fileInputRef}
                        className="hidden"
                        onChange={handleFileSelect}
                    />
                    
                    <button 
                        onClick={triggerFileInput}
                        className={`size-10 rounded-full flex items-center justify-center transition-colors shrink-0 mb-1 ml-1 ${selectedImage ? 'bg-primary text-black' : 'bg-white/5 text-white/70 hover:bg-white/10'}`}
                    >
                        <span className="material-symbols-outlined text-xl">{selectedImage ? 'image' : 'add_photo_alternate'}</span>
                    </button>

                    <div className="flex-1 flex items-center px-2 min-h-[48px]">
                        <input
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                            placeholder={selectedImage ? "Add a caption..." : "Ask me anything..."}
                            className="w-full bg-transparent border-none focus:ring-0 text-white placeholder:text-white/30 text-[15px] py-3 max-h-32"
                            autoComplete="off"
                        />
                    </div>

                    <button 
                        onClick={() => handleSend()}
                        disabled={(!input.trim() && !selectedImage) || isTyping}
                        className="size-10 rounded-full bg-primary text-black flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105 active:scale-95 transition-all shadow-lg shrink-0 mb-1 mr-1"
                    >
                        {isTyping ? <Spinner className="size-5 text-black" /> : <span className="material-symbols-outlined text-xl font-bold">send</span>}
                    </button>
                    
                    {selectedImage && (
                        <div className="absolute -top-16 left-4 animate-fade-in">
                            <div className="relative">
                                <img src={selectedImage} alt="Selected" className="h-14 w-14 object-cover rounded-xl border border-white/20 shadow-lg" />
                                <button 
                                    onClick={removeSelectedImage}
                                    className="absolute -top-2 -right-2 size-5 bg-surface-dark rounded-full border border-white/20 flex items-center justify-center text-white hover:text-error"
                                >
                                    <span className="material-symbols-outlined text-xs">close</span>
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ChatBotScreen;