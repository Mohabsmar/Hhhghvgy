
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { generateRecipesFromIngredients, generateIngredientImage } from '../common/geminiService';
import { Recipe, Filters, IngredientItem, Language } from '../types';
import IngredientChip from '../components/common/IngredientChip';
import RecipeCard from '../components/common/recipe_generator/RecipeCard';
import GenerationLoader from '../components/common/recipe_generator/GenerationLoader';
import Spinner from '../components/common/Spinner';
import FilterModal from '../components/FilterModal';
import { getTranslation } from '../constants';

interface DiscoverScreenProps {
    onSelectRecipe: (recipe: Recipe) => void;
    savedRecipes: Recipe[];
    onToggleSave: (recipe: Recipe) => void;
    initialIngredients?: string[];
    onIngredientsProcessed?: () => void;
    lang: Language;
}

const DiscoverScreen: React.FC<DiscoverScreenProps> = ({ onSelectRecipe, savedRecipes, onToggleSave, initialIngredients, onIngredientsProcessed, lang }) => {
  const [ingredients, setIngredients] = useState<IngredientItem[]>([
      { id: 'init-1', name: 'Chicken', imageUrl: 'https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=100' },
      { id: 'init-2', name: 'Broccoli', imageUrl: 'https://images.unsplash.com/photo-1584270354949-c26b0d5b4a0c?w=100' }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [filters, setFilters] = useState<Filters>({ dietary: [], cuisine: [], difficulty: [], time: '' });
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  
  const inputRef = useRef<HTMLInputElement>(null);

  const handleAddIngredient = useCallback(() => {
    const rawInput = inputValue.split(',').map(s => s.trim()).filter(Boolean);
    if (rawInput.length > 0) {
        const newItems: IngredientItem[] = rawInput.map(name => ({ id: `custom-${name}-${Date.now()}`, name, isLoading: true }));
        setIngredients(prev => [...newItems, ...prev]);
        setInputValue('');
        
        // Fast parallel image generation for inputs
        newItems.forEach(item => {
            generateIngredientImage(item.name).then(url => {
                setIngredients(prev => prev.map(i => i.id === item.id ? { ...i, imageUrl: url, isLoading: false } : i));
            });
        });
    }
  }, [inputValue]);

  const handleGenerateRecipes = async () => {
    if (ingredients.length === 0) return;
    setIsLoading(true);
    setError(null);
    try {
      const result = await generateRecipesFromIngredients(ingredients.map(i => i.name), filters, lang);
      setRecipes(result);
    } catch (err: any) {
      setError("Chef is busy. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen pb-40 relative font-display overflow-x-hidden bg-black">
      <header className="pt-16 pb-8 px-6 liquid-glass sticky top-0 z-30 border-b border-white/10 rounded-b-[48px] shadow-2xl">
        <div className="flex justify-between items-center mb-8">
            <div>
                <h1 className="text-4xl font-black text-white tracking-tighter leading-none">Find<br/><span className="text-primary">Recipes</span></h1>
                <p className="text-[10px] font-black text-white/40 uppercase tracking-widest mt-2">Add your ingredients • Get a dish</p>
            </div>
            <button onClick={() => setIsFilterModalOpen(true)} className="size-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white active:scale-95 transition-all shadow-lg hover:border-primary/40">
                <span className="material-symbols-outlined text-2xl">tune</span>
            </button>
        </div>

        <div className="relative group">
            <span className="material-symbols-outlined absolute left-6 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-primary transition-colors">add_circle</span>
            <input 
                ref={inputRef}
                type="text" 
                placeholder="What's in your pantry?" 
                className="w-full h-16 bg-white/5 rounded-[28px] pl-16 pr-16 text-white text-[16px] font-bold border border-white/10 focus:border-primary/50 transition-all placeholder:text-white/20 backdrop-blur-md"
                value={inputValue}
                onChange={e => setInputValue(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleAddIngredient()}
            />
            {inputValue.length > 0 && (
                <button onClick={handleAddIngredient} className="absolute right-3 top-1/2 -translate-y-1/2 size-10 rounded-full bg-primary text-black flex items-center justify-center shadow-lg active:scale-90 transition-transform">
                    <span className="material-symbols-outlined font-black">add</span>
                </button>
            )}
        </div>
      </header>

      <main className="px-6 space-y-10 mt-8">
        <div>
            <div className="flex items-center justify-between px-2 mb-4">
                <h4 className="text-[10px] font-black text-white/30 uppercase tracking-widest">Selected Assets</h4>
                <span className="text-[10px] font-black text-primary uppercase tracking-widest">{ingredients.length} items</span>
            </div>
            <div className="flex flex-wrap gap-3 overflow-x-auto no-scrollbar pb-2">
                {ingredients.map(ing => (
                    <IngredientChip key={ing.id} ingredient={ing} onRemove={() => setIngredients(prev => prev.filter(i => i.id !== ing.id))} />
                ))}
            </div>
        </div>

        <div className="space-y-8">
            {isLoading ? (
                <div className="py-12"><GenerationLoader /></div>
            ) : error ? (
                <div className="p-12 rounded-[40px] bg-red-500/10 border border-red-500/20 text-center space-y-6">
                    <div className="size-16 rounded-full bg-red-500/20 flex items-center justify-center text-red-500 mx-auto">
                        <span className="material-symbols-outlined text-4xl">warning</span>
                    </div>
                    <p className="text-white font-bold">{error}</p>
                    <button onClick={handleGenerateRecipes} className="px-8 h-12 rounded-full bg-white/10 text-white font-bold text-xs uppercase tracking-widest hover:bg-white/20 transition-colors">Retry Generation</button>
                </div>
            ) : recipes.length > 0 ? (
                <div className="grid grid-cols-1 gap-10 animate-reveal">
                    {recipes.map(recipe => (
                        <RecipeCard key={recipe.id} recipe={recipe} onSelect={() => onSelectRecipe(recipe)} isSaved={savedRecipes.some(r => r.id === recipe.id)} onToggleSave={onToggleSave} />
                    ))}
                </div>
            ) : (
                <div className="flex flex-col items-center justify-center py-20 text-center opacity-30 animate-fade-in">
                    <span className="material-symbols-outlined text-7xl mb-6 text-white">restaurant</span>
                    <h3 className="text-xl font-black text-white uppercase tracking-widest">Ready to Alchemize?</h3>
                    <p className="text-sm mt-1 max-w-[200px] mx-auto">Input your pantry items and let the neural engine cook.</p>
                </div>
            )}
        </div>
      </main>

      <div className="fixed bottom-28 left-0 right-0 px-6 z-20 pointer-events-none">
            <div className="max-w-md mx-auto pointer-events-auto">
                <button 
                    onClick={handleGenerateRecipes}
                    disabled={isLoading || ingredients.length === 0}
                    className="w-full h-20 rounded-[36px] bg-white text-black font-black flex items-center justify-center gap-4 shadow-[0_30px_60px_rgba(255,255,255,0.15)] active:scale-95 disabled:opacity-30 transition-all uppercase tracking-[0.25em] text-lg border border-white/20"
                >
                    {isLoading ? <Spinner className="text-black size-8" /> : "Synthesize Feast"}
                    <span className="material-symbols-outlined font-black text-primary text-4xl">bolt</span>
                </button>
            </div>
      </div>

      <FilterModal isOpen={isFilterModalOpen} onClose={() => setIsFilterModalOpen(false)} filters={filters} setFilters={setFilters} />
    </div>
  );
};

export default DiscoverScreen;
