
import React from 'react';
import { LeaderboardEntry } from '../types';

interface ChefProfileScreenProps {
    chefId: string; // Ideally this would fetch data, we'll mock with the ID for now
    onExit: () => void;
}

const ChefProfileScreen: React.FC<ChefProfileScreenProps> = ({ chefId, onExit }) => {
    // Mock data based on ID - in real app would fetch
    const chefData = {
        name: chefId === 'u1' ? 'Gordon R.' : 'Chef ' + chefId,
        rank: 'Michelin Star',
        level: 50,
        xp: 45000,
        avatar: chefId === 'u1' ? 'https://i.pravatar.cc/150?u=gordon' : `https://i.pravatar.cc/150?u=${chefId}`,
        badges: 42,
        recipes: 128,
        followers: '2.4M',
        bio: 'Passionate about fresh ingredients and perfect execution. No microwaves allowed.'
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            {/* Header Image */}
            <div className="h-48 relative">
                <img src="https://images.unsplash.com/photo-1556910103-1c02745a30bf?q=80&w=2070&auto=format&fit=crop" className="w-full h-full object-cover opacity-60" />
                <div className="absolute inset-0 bg-gradient-to-t from-background-dark to-transparent"></div>
                <button onClick={onExit} className="absolute top-safe-top left-6 size-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white border border-white/10 hover:bg-white/10">
                    <span className="material-symbols-outlined">arrow_back</span>
                </button>
            </div>

            {/* Profile Content */}
            <main className="flex-1 overflow-y-auto relative -mt-12 px-6 pb-32">
                <div className="flex justify-between items-end mb-6">
                    <div className="size-24 rounded-[32px] p-1 bg-background-dark">
                        <img src={chefData.avatar} className="size-full rounded-[28px] object-cover border-2 border-primary" />
                    </div>
                    <button className="h-10 px-6 bg-primary text-white rounded-full font-bold text-sm shadow-lg shadow-primary/20 hover:scale-105 transition-transform">
                        Follow
                    </button>
                </div>

                <div className="mb-8">
                    <div className="flex items-center gap-2 mb-1">
                        <h1 className="text-3xl font-black text-white">{chefData.name}</h1>
                        <span className="material-symbols-outlined text-blue-400 text-xl" style={{fontVariationSettings: "'FILL' 1"}}>verified</span>
                    </div>
                    <p className="text-primary font-bold text-sm uppercase tracking-wider mb-3">{chefData.rank} • Lvl {chefData.level}</p>
                    <p className="text-text-dark-secondary leading-relaxed">{chefData.bio}</p>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 mb-8">
                    <div className="bg-surface-dark border border-white/5 rounded-2xl p-4 text-center">
                        <p className="text-xl font-black text-white">{chefData.recipes}</p>
                        <p className="text-[10px] text-text-dark-secondary uppercase font-bold">Recipes</p>
                    </div>
                    <div className="bg-surface-dark border border-white/5 rounded-2xl p-4 text-center">
                        <p className="text-xl font-black text-white">{chefData.badges}</p>
                        <p className="text-[10px] text-text-dark-secondary uppercase font-bold">Badges</p>
                    </div>
                    <div className="bg-surface-dark border border-white/5 rounded-2xl p-4 text-center">
                        <p className="text-xl font-black text-white">{chefData.followers}</p>
                        <p className="text-[10px] text-text-dark-secondary uppercase font-bold">Followers</p>
                    </div>
                </div>

                {/* Recent Activity */}
                <h3 className="text-lg font-bold text-white mb-4">Latest Dishes</h3>
                <div className="grid grid-cols-2 gap-4">
                    {[1, 2, 3, 4].map(i => (
                        <div key={i} className="aspect-square rounded-2xl bg-white/5 border border-white/5 overflow-hidden relative group">
                            <img src={`https://images.unsplash.com/photo-${1540000000000 + i}?w=400&auto=format&fit=crop`} className="w-full h-full object-cover opacity-80 group-hover:scale-110 transition-transform duration-500" />
                            <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 to-transparent">
                                <div className="flex items-center gap-1 text-white text-xs font-bold">
                                    <span className="material-symbols-outlined text-sm text-red-500 fill-current">favorite</span>
                                    {120 + i * 15}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </main>
        </div>
    );
};

export default ChefProfileScreen;
