import React, { useState, useEffect } from 'react';
import { searchNearbyStores } from '../common/geminiService';
import Spinner from '../components/common/Spinner';

const FarmersMarketScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [markets, setMarkets] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetch = async () => {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(async (pos) => {
                    const res = await searchNearbyStores({ lat: pos.coords.latitude, lng: pos.coords.longitude, query: "farmers market" });
                    setMarkets(res);
                    setLoading(false);
                }, () => setLoading(false));
            } else {
                setLoading(false);
            }
        };
        fetch();
    }, []);

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Farmers Market</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-4 overflow-y-auto">
                {loading ? <div className="text-center pt-20"><Spinner className="size-10 text-orange-500"/></div> : 
                 markets.length === 0 ? <div className="text-center text-white/50 pt-20">No markets found nearby.</div> :
                 markets.map(m => (
                    <div key={m.id} className="liquid-panel p-5 rounded-[24px] border border-white/5 flex items-center gap-4">
                        <div className="size-12 rounded-full bg-orange-500/20 flex items-center justify-center text-orange-500"><span className="material-symbols-outlined">storefront</span></div>
                        <div className="flex-1">
                            <h3 className="font-bold text-white text-lg">{m.name}</h3>
                            <p className="text-text-dark-secondary text-sm">{m.address}</p>
                        </div>
                    </div>
                 ))
                }
            </main>
        </div>
    );
};
export default FarmersMarketScreen;