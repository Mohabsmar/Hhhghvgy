import React, { useState } from 'react';
import { explainCulinaryTerm } from '../common/geminiService';
import Spinner from '../components/common/Spinner';

const DictionaryScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [term, setTerm] = useState('');
    const [data, setData] = useState<any>(null);
    const [loading, setLoading] = useState(false);

    const handleSearch = async () => {
        if(!term) return;
        setLoading(true);
        const res = await explainCulinaryTerm(term);
        setData(res);
        setLoading(false);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Dictionary</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-8">
                <div className="flex gap-2">
                    <input value={term} onChange={e => setTerm(e.target.value)} placeholder="e.g. Mirepoix" className="flex-1 h-12 bg-white/5 rounded-full px-6 text-white border border-white/10" />
                    <button onClick={handleSearch} disabled={loading} className="size-12 rounded-full bg-primary flex items-center justify-center text-white shadow-lg">{loading ? <Spinner className='size-5' /> : <span className="material-symbols-outlined">search</span>}</button>
                </div>
                
                {data && (
                    <div className="liquid-panel p-8 rounded-[40px] border border-white/5">
                        <span className="text-xs font-bold text-primary uppercase tracking-widest mb-1 block">{data.category}</span>
                        <h2 className="text-4xl font-black text-white mb-2">{data.term}</h2>
                        <p className="text-text-dark-secondary italic mb-6 font-serif text-lg opacity-60">/{data.pronunciation}/</p>
                        <p className="text-white text-lg leading-relaxed">{data.definition}</p>
                    </div>
                )}
            </main>
        </div>
    );
};
export default DictionaryScreen;