
import React, { useState } from 'react';
import { LeaderboardEntry, Language, User } from '../types';
import { LEADERBOARD_DATA, getTranslation } from '../constants';

interface LeaderboardScreenProps {
    onExit: () => void;
    lang: Language;
    currentUser: User;
}

const LeaderboardScreen: React.FC<LeaderboardScreenProps> = ({ onExit, lang, currentUser }) => {
    const [timeframe, setTimeframe] = useState<'Weekly' | 'All Time'>('Weekly');
    const [filter, setFilter] = useState<'Global' | 'Friends'>('Global');
    const t = (key: any) => getTranslation(lang, key);

    const RankRow: React.FC<{entry: LeaderboardEntry, isMe?: boolean}> = ({ entry, isMe }) => (
        <div className={`flex items-center gap-4 p-4 rounded-[28px] border transition-all duration-300 ${isMe ? 'bg-primary/20 border-primary/50 shadow-[0_0_20px_rgba(16,185,129,0.2)]' : 'bg-white/5 border-white/5 hover:bg-white/10'}`}>
            <div className={`size-10 flex items-center justify-center font-black text-lg ${entry.rank <= 3 ? 'text-yellow-400 drop-shadow-md scale-125' : 'text-white/50'}`}>
                {entry.rank <= 3 ? <span className="material-symbols-outlined text-3xl">emoji_events</span> : `#${entry.rank}`}
            </div>
            
            <div className="relative">
                <img src={entry.avatar} className={`size-14 rounded-2xl object-cover border-2 ${entry.rank === 1 ? 'border-yellow-400' : 'border-white/10'}`} />
                {entry.rank === 1 && <div className="absolute -top-3 -right-2 text-2xl animate-bounce">👑</div>}
            </div>

            <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                    <h4 className={`font-bold truncate text-lg ${isMe ? 'text-primary' : 'text-white'}`}>{entry.name} {isMe && '(You)'}</h4>
                    {entry.rank <= 3 && <span className="px-2 py-0.5 rounded-md bg-yellow-400/20 text-yellow-400 text-[10px] font-bold uppercase tracking-wider">Top 3</span>}
                </div>
                <div className="flex items-center gap-4 mt-1 text-xs font-medium text-text-dark-secondary">
                    <span className="flex items-center gap-1"><span className="material-symbols-outlined text-sm text-orange-400">local_fire_department</span>{entry.streak} day streak</span>
                    <span className="flex items-center gap-1"><span className="material-symbols-outlined text-sm text-blue-400">military_tech</span>{entry.badges} badges</span>
                </div>
            </div>

            <div className="text-right">
                <p className="text-xl font-black text-white">{entry.xp.toLocaleString()}</p>
                <p className="text-[10px] font-bold text-text-dark-secondary uppercase tracking-wider">XP</p>
            </div>
        </div>
    );

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            {/* Header */}
            <div className="relative h-64 shrink-0 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-primary/30 to-background-dark z-10"></div>
                <img src="https://images.unsplash.com/photo-1556910103-1c02745a30bf?q=80&w=2070&auto=format&fit=crop" className="absolute inset-0 w-full h-full object-cover opacity-40 blur-sm" />
                
                <header className="absolute top-0 left-0 right-0 p-6 pt-safe-top z-20 flex justify-between items-center">
                    <button onClick={onExit} className="size-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/10 border border-white/10">
                        <span className="material-symbols-outlined">arrow_back</span>
                    </button>
                    <h1 className="text-2xl font-black text-white uppercase tracking-wider drop-shadow-lg">{t('leaderboard')}</h1>
                    <button className="size-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/10 border border-white/10">
                        <span className="material-symbols-outlined">info</span>
                    </button>
                </header>

                <div className="absolute bottom-6 left-6 right-6 z-20">
                    <div className="flex p-1.5 bg-black/40 backdrop-blur-xl rounded-full border border-white/10">
                        {['Weekly', 'All Time'].map(t => (
                            <button 
                                key={t}
                                onClick={() => setTimeframe(t as any)}
                                className={`flex-1 py-3 rounded-full text-xs font-bold transition-all uppercase tracking-wide ${timeframe === t ? 'bg-primary text-black shadow-lg' : 'text-white/60 hover:text-white'}`}
                            >
                                {t}
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            <main className="flex-1 overflow-y-auto p-6 pt-2 space-y-4 pb-32">
                <div className="flex gap-4 mb-2 overflow-x-auto no-scrollbar">
                    {['Global', 'Friends', 'Local'].map(f => (
                        <button 
                            key={f} 
                            onClick={() => setFilter(f as any)}
                            className={`px-6 py-2 rounded-full border text-xs font-bold transition-all uppercase tracking-wider ${filter === f ? 'bg-white text-black border-white' : 'bg-transparent text-white/50 border-white/10 hover:border-white/30'}`}
                        >
                            {f}
                        </button>
                    ))}
                </div>

                {LEADERBOARD_DATA.map((entry, index) => (
                    <RankRow key={entry.id} entry={entry} isMe={entry.id === 'u4'} />
                ))}
            </main>
        </div>
    );
};

export default LeaderboardScreen;
