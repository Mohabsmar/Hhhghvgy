
import React, { useState } from 'react';
import { generateLeftoverRecipe, generateIngredientImage } from '../common/geminiService';
import Spinner from '../components/common/Spinner';
import { Recipe } from '../types';

interface LeftoverMagicScreenProps {
    onExit: () => void;
    onSelectRecipe: (recipe: Recipe) => void;
}

const LeftoverMagicScreen: React.FC<LeftoverMagicScreenProps> = ({ onExit, onSelectRecipe }) => {
    const [ingredients, setIngredients] = useState(['', '', '']);
    const [ingredientVisuals, setIngredientVisuals] = useState<(string | null)[]>([null, null, null]);
    const [loading, setLoading] = useState(false);

    const handleInputChange = async (index: number, value: string) => {
        const newIngs = [...ingredients];
        newIngs[index] = value;
        setIngredients(newIngs);

        // If user stops typing, try to generate a small preview image of the ingredient (Input generation)
        if (value.length > 2) {
            const timeoutId = setTimeout(async () => {
                const img = await generateIngredientImage(value);
                setIngredientVisuals(prev => {
                    const next = [...prev];
                    next[index] = img;
                    return next;
                });
            }, 1500);
            return () => clearTimeout(timeoutId);
        } else if (value === "") {
            setIngredientVisuals(prev => {
                const next = [...prev];
                next[index] = null;
                return next;
            });
        }
    };

    const handleGenerate = async () => {
        const filtered = ingredients.filter(i => i.trim());
        if (filtered.length === 0) return;
        
        setLoading(true);
        try {
            const res = await generateLeftoverRecipe(filtered);
            onSelectRecipe(res);
        } catch (e) { 
            console.error(e);
            alert("Chef is overwhelmed. Please check your connection and try again."); 
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black z-50 flex flex-col font-display animate-reveal overflow-hidden">
            {/* Cinematic Background */}
            <div className="absolute inset-0 z-0 pointer-events-none">
                <div className="absolute top-[-20%] left-[-10%] size-[800px] bg-primary/10 blur-[160px] rounded-full animate-pulse-glow"></div>
                <div className="absolute bottom-[-20%] right-[-10%] size-[800px] bg-primary/5 blur-[160px] rounded-full animate-pulse-glow" style={{ animationDelay: '2s' }}></div>
            </div>

            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5 rounded-b-[40px]">
                <button onClick={onExit} className="size-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white active:scale-90 transition-transform">
                    <span className="material-symbols-outlined">arrow_back</span>
                </button>
                <div className="text-center">
                    <h1 className="text-xl font-black text-white tracking-tight">Leftover Magic</h1>
                    <p className="text-[10px] text-primary font-bold uppercase tracking-widest">Neural Kitchen Tool</p>
                </div>
                <div className="size-12"></div>
            </header>

            <main className="flex-1 p-8 flex flex-col items-center justify-center space-y-10 relative z-10 overflow-y-auto no-scrollbar">
                <div className="text-center space-y-4">
                    <div className="size-20 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto shadow-[0_0_50px_rgba(16,185,129,0.2)] animate-float">
                        <span className="material-symbols-outlined text-4xl text-primary">auto_fix_high</span>
                    </div>
                    <div className="space-y-1">
                        <h2 className="text-3xl font-black text-white tracking-tighter">The 3-Item Alchemy</h2>
                        <p className="text-text-dark-secondary text-sm max-w-[280px] mx-auto font-medium">Input ingredients for instant AI visual rendering and recipe generation.</p>
                    </div>
                </div>

                <div className="w-full max-w-sm space-y-6">
                    {ingredients.map((ing, i) => (
                        <div key={i} className="flex items-center gap-4 animate-reveal" style={{ animationDelay: `${i * 100}ms` }}>
                            <div className="size-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center overflow-hidden shrink-0 shadow-inner">
                                {ingredientVisuals[i] ? (
                                    <img src={ingredientVisuals[i]!} className="size-full object-cover animate-fade-in" alt="Input Preview" />
                                ) : (
                                    <span className="material-symbols-outlined text-white/10">kitchen</span>
                                )}
                            </div>
                            <div className="relative flex-1">
                                <span className="absolute left-5 top-1/2 -translate-y-1/2 text-primary font-black text-[9px] uppercase tracking-widest opacity-30">Item {i+1}</span>
                                <input 
                                    value={ing} 
                                    onChange={e => handleInputChange(i, e.target.value)} 
                                    placeholder="Enter ingredient..." 
                                    className="w-full h-14 bg-white/5 rounded-full pl-20 pr-6 text-white border border-white/10 text-[15px] font-bold focus:border-primary/50 focus:bg-white/[0.08] transition-all placeholder:text-white/10" 
                                />
                            </div>
                        </div>
                    ))}
                </div>

                <div className="w-full max-w-sm pt-4">
                    <button 
                        onClick={handleGenerate} 
                        disabled={loading || !ingredients.some(i => i.trim())} 
                        className="w-full h-16 rounded-full bg-primary text-black font-black text-xs uppercase tracking-[0.35em] shadow-[0_12px_40px_rgba(16,185,129,0.3)] hover:scale-[1.02] active:scale-95 transition-all duration-300 flex items-center justify-center gap-3 disabled:opacity-30 disabled:grayscale"
                    >
                        {loading ? (
                            <div className="flex items-center gap-3">
                                <Spinner className="size-6 text-black" />
                                <span>Generating Masterpiece...</span>
                            </div>
                        ) : (
                            <>
                                <span>Cast Culinary Spell</span>
                                <span className="material-symbols-outlined text-xl">bolt</span>
                            </>
                        )}
                    </button>
                    <p className="text-center text-[8px] text-white/20 font-black uppercase tracking-[0.6em] mt-8">Gemini AI Synthesis Engine v2.5</p>
                </div>
            </main>
        </div>
    );
};

export default LeftoverMagicScreen;
