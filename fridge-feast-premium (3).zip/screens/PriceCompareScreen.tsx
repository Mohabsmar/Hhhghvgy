
import React, { useState } from 'react';

const STORES = [
    { name: 'Whole Foods', multiplier: 1.4 },
    { name: 'Trader Joe\'s', multiplier: 0.9 },
    { name: 'Walmart', multiplier: 0.7 },
    { name: 'Kroger', multiplier: 1.0 },
    { name: 'Local Market', multiplier: 1.2 }
];

const PriceCompareScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [query, setQuery] = useState('');
    const [results, setResults] = useState<any[]>([]);

    const handleSearch = () => {
        if(!query) return;
        const basePrice = (Math.random() * 5) + 2; // Random base price $2-$7
        const mockResults = STORES.map(s => ({
            store: s.name,
            price: (basePrice * s.multiplier).toFixed(2)
        })).sort((a,b) => parseFloat(a.price) - parseFloat(b.price));
        setResults(mockResults);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Price Watch</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6">
                <div className="flex gap-2">
                    <input 
                        value={query} 
                        onChange={e => setQuery(e.target.value)} 
                        onKeyDown={e => e.key === 'Enter' && handleSearch()}
                        placeholder="e.g. Milk, Eggs, Avocado" 
                        className="flex-1 h-12 bg-white/5 rounded-full px-6 text-white border border-white/10" 
                    />
                    <button onClick={handleSearch} className="size-12 rounded-full bg-green-500 text-white flex items-center justify-center shadow-lg"><span className="material-symbols-outlined">search</span></button>
                </div>

                {results.length > 0 && (
                    <div className="space-y-3">
                        <h3 className="text-white font-bold px-2">Best Prices for "{query}"</h3>
                        {results.map((r, i) => (
                            <div key={i} className="liquid-panel p-4 rounded-[24px] border border-white/5 flex justify-between items-center">
                                <div className="flex items-center gap-3">
                                    <div className={`size-8 rounded-full flex items-center justify-center text-xs font-bold ${i === 0 ? 'bg-green-500 text-black' : 'bg-white/10 text-white'}`}>{i+1}</div>
                                    <span className="text-white font-bold">{r.store}</span>
                                </div>
                                <span className={`text-lg font-black ${i===0 ? 'text-green-400' : 'text-white'}`}>${r.price}</span>
                            </div>
                        ))}
                    </div>
                )}
            </main>
        </div>
    );
};
export default PriceCompareScreen;
