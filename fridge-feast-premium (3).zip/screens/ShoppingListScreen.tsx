
import React, { useState, useEffect } from 'react';
import { ShoppingListItem, ShoppingListCategory, Language } from '../types';
import Spinner from '../components/common/Spinner';
import { getTranslation } from '../constants';

const STORAGE_KEY = 'stitch_shopping_list';

const defaultList: ShoppingListCategory[] = [
    {
        name: 'Produce',
        items: []
    },
    {
        name: 'Dairy',
        items: []
    },
    {
        name: 'Pantry',
        items: []
    }
];

const ShoppingListScreen: React.FC<{onExit: () => void, lang: Language}> = ({ onExit, lang }) => {
    const [list, setList] = useState<ShoppingListCategory[]>([]);
    const [newItemName, setNewItemName] = useState('');
    const [isChecking, setIsChecking] = useState(false);
    const [loaded, setLoaded] = useState(false);
    
    // Estimated Cost Feature
    const [estimatedCost, setEstimatedCost] = useState(0);
    const budgetLimit = 50; // Example budget limit
    
    const t = (key: any) => getTranslation(lang, key);

    // Load from storage
    useEffect(() => {
        try {
            const stored = localStorage.getItem(STORAGE_KEY);
            if (stored) {
                setList(JSON.parse(stored));
            } else {
                setList(defaultList);
            }
        } catch (e) {
            setList(defaultList);
        } finally {
            setLoaded(true);
        }
    }, []);

    // Save to storage & Calc Cost
    useEffect(() => {
        if (loaded) {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
            
            // L32 Estimated Cost Logic (Mock calculation: random price between $2-$8 per item)
            let total = 0;
            list.forEach(cat => {
                cat.items.forEach(item => {
                    if (!item.checked) {
                        // In a real app, this would come from a database. Here we mock it.
                        // Hash string to get consistent mock price
                        const hash = item.name.split('').reduce((a,b)=>a+b.charCodeAt(0),0);
                        const mockPrice = 2 + (hash % 600) / 100; 
                        total += mockPrice;
                    }
                });
            });
            setEstimatedCost(total);
        }
    }, [list, loaded]);

    const toggleItemChecked = (itemId: string) => {
        setList(currentList => currentList.map(category => ({
            ...category,
            items: category.items.map(item => 
                item.id === itemId ? { ...item, checked: !item.checked } : item
            )
        })));
    };

    const handleAddItem = () => {
        if (!newItemName.trim()) return;
        setList(prev => {
            const manualCatExists = prev.some(c => c.name === 'Added Manually');
            const newItem: ShoppingListItem = {
                id: Date.now().toString(),
                name: newItemName,
                quantity: '1x', source: 'Added manually', checked: false, status: 'available'
            };
            
            if (manualCatExists) {
                return prev.map(c => c.name === 'Added Manually' ? { ...c, items: [newItem, ...c.items] } : c);
            } else {
                return [{ name: 'Added Manually', items: [newItem] }, ...prev];
            }
        });
        setNewItemName('');
    };

    const handleRemoveItem = (itemId: string) => {
        setList(prev => prev.map(cat => ({
            ...cat,
            items: cat.items.filter(i => i.id !== itemId)
        })).filter(cat => cat.items.length > 0 || cat.name !== 'Added Manually'));
    }

    const CategorySection: React.FC<{category: ShoppingListCategory}> = ({ category }) => {
        if (category.items.length === 0) return null;
        return (
            <div className="mb-6 animate-fade-in">
                <h2 className="text-[18px] font-bold text-primary mb-3 px-4 sticky top-0 liquid-panel backdrop-blur-md py-2 z-10 flex items-center gap-2 rounded-full mx-2 border-b border-white/5 shadow-sm">
                    {category.name}
                    <span className="text-xs font-medium text-text-dark-secondary bg-white/5 px-2 py-0.5 rounded-full">{category.items.length}</span>
                </h2>
                <div className="ios-list-group ml-4 mr-4 liquid-glass rounded-[40px] overflow-hidden border border-white/10">
                    {category.items.map((item, idx) => (
                        <div key={item.id} className={`ios-list-item group ${idx === category.items.length - 1 ? 'border-b-0' : 'border-b border-white/5'} hover:bg-white/5 transition-colors`}>
                            <button 
                                onClick={() => toggleItemChecked(item.id)}
                                className={`size-6 rounded-full border-[1.5px] flex items-center justify-center mr-3 transition-all duration-300 ${item.checked ? 'bg-primary border-primary' : 'border-white/20 hover:border-primary'}`}
                            >
                                {item.checked && <span className="material-symbols-outlined text-white text-sm font-bold">check</span>}
                            </button>
                            <div className="flex-1 min-w-0">
                                <span className={`text-[16px] font-medium text-white block truncate transition-all ${item.checked ? 'text-text-dark-muted line-through opacity-50' : ''}`}>{item.name}</span>
                                {(item.quantity && item.quantity !== '1x') && <span className="text-[12px] text-text-dark-secondary">{item.quantity} • {item.source}</span>}
                            </div>
                            <button onClick={() => handleRemoveItem(item.id)} className="text-text-dark-secondary hover:text-error transition-colors p-2 opacity-0 group-hover:opacity-100">
                                <span className="material-symbols-outlined text-xl">delete</span>
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        )
    };

    const clearChecked = () => {
        setList(prev => prev.map(cat => ({
            ...cat,
            items: cat.items.filter(i => !i.checked)
        })).filter(cat => cat.items.length > 0));
    };

    return (
        <div className="fixed inset-0 bg-transparent z-40 flex flex-col font-display">
            <header className="px-4 pt-safe-top pb-4 flex justify-between items-center liquid-glass z-50 sticky top-0 border-b border-white/5 rounded-b-[32px]">
                <button onClick={onExit} className="flex items-center gap-1 text-white text-[17px] font-semibold active:opacity-60 hover:text-primary transition-colors">
                    <span className="material-symbols-outlined text-2xl">chevron_left</span>
                    Back
                </button>
                <div className="flex items-center gap-3">
                     <button onClick={clearChecked} className="px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-bold text-text-dark-secondary hover:text-white hover:bg-white/10 transition-colors">
                        Clear Done
                    </button>
                </div>
            </header>

            <div className="px-6 py-6">
                 <h1 className="text-4xl font-black text-white leading-none tracking-tight">{t('shop')}</h1>
                 <div className="flex justify-between items-end mt-2">
                     <p className="text-text-dark-secondary text-sm font-medium">
                        {list.reduce((acc, cat) => acc + cat.items.filter(i => !i.checked).length, 0)} items remaining
                     </p>
                     
                     {/* Estimated Cost Display */}
                     <div className="text-right">
                         <p className="text-[10px] uppercase font-bold text-text-dark-secondary tracking-wider">Est. Total</p>
                         <p className={`text-xl font-black ${estimatedCost > budgetLimit ? 'text-red-400' : 'text-primary'}`}>
                             ${estimatedCost.toFixed(2)}
                         </p>
                     </div>
                 </div>
                 {estimatedCost > budgetLimit && (
                     <div className="mt-3 py-2 px-3 bg-red-500/10 border border-red-500/20 rounded-full flex items-center gap-2 animate-fade-in">
                         <span className="material-symbols-outlined text-red-400 text-sm">warning</span>
                         <span className="text-xs font-bold text-red-400">Budget Exceeded (${budgetLimit})</span>
                     </div>
                 )}
            </div>

            <main className="flex-1 overflow-y-auto no-scrollbar pb-44">
                {list.map(category => <CategorySection key={category.name} category={category} />)}
                
                {list.every(c => c.items.length === 0) && (
                    <div className="flex flex-col items-center justify-center py-20 opacity-30">
                        <span className="material-symbols-outlined text-7xl mb-4 text-white">shopping_basket</span>
                        <p className="text-white font-bold text-lg">Your list is empty</p>
                        <p className="text-sm mt-2">Add ingredients to get started</p>
                    </div>
                )}
            </main>

            {/* Floating Input Area */}
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black via-black/95 to-transparent z-20 safe-area-bottom">
                 <div className="liquid-glass rounded-full p-2 flex items-center gap-3 mb-4 border border-white/20 shadow-2xl">
                    <div className="size-10 rounded-full bg-white/5 flex items-center justify-center ml-1 border border-white/5">
                            <span className="material-symbols-outlined text-white/50">add</span>
                    </div>
                    <input 
                            type="text" 
                            value={newItemName}
                            onChange={(e) => setNewItemName(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleAddItem()}
                            placeholder="Add item..."
                            className="flex-1 bg-transparent border-none text-white placeholder:text-text-dark-muted focus:ring-0 p-0 text-[16px] h-10 font-medium"
                    />
                    <button 
                        onClick={handleAddItem}
                        disabled={!newItemName.trim()}
                        className="h-10 px-6 bg-primary text-white font-bold rounded-full disabled:opacity-50 disabled:bg-white/10 transition-all shadow-lg shadow-primary/20 hover:scale-105 active:scale-95"
                    >
                        Add
                    </button>
                </div>

                <button 
                    onClick={() => setIsChecking(true)}
                    className="w-full h-12 rounded-full bg-white/5 border border-white/10 text-white text-[15px] font-bold flex items-center justify-center gap-2 active:scale-[0.98] hover:bg-white/10 transition-all"
                >
                     {isChecking ? <Spinner className="text-white" /> : <><span className="material-symbols-outlined">inventory</span> Check Pantry Stock</>}
                </button>
            </div>
        </div>
    );
};

export default ShoppingListScreen;
