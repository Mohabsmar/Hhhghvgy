import React, { useState } from 'react';
import { askCulinaryExpert } from '../common/geminiService';
import Spinner from '../components/common/Spinner';

const CheeseBoardScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [occasion, setOccasion] = useState('');
    const [result, setResult] = useState('');
    const [loading, setLoading] = useState(false);

    const handleCreate = async () => {
        setLoading(true);
        const res = await askCulinaryExpert('Fromager', `Design a cheese board for: ${occasion}. List cheeses, meats, accompaniments, and wine pairings.`);
        setResult(res);
        setLoading(false);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Cheese Board</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6">
                <div className="text-center py-6">
                    <span className="material-symbols-outlined text-6xl text-yellow-200 mb-4">cookie</span>
                    <h2 className="text-2xl font-bold text-white">Perfect Pairings</h2>
                    <p className="text-text-dark-secondary">Describe your event or preferences.</p>
                </div>
                <input value={occasion} onChange={e => setOccasion(e.target.value)} placeholder="e.g. Date Night, 10 Guests" className="w-full h-14 bg-white/5 rounded-full px-6 text-white border border-white/10 text-center text-lg focus:border-yellow-400" />
                <button onClick={handleCreate} disabled={loading} className="w-full h-14 bg-yellow-500 rounded-full text-black font-bold text-lg shadow-lg shadow-yellow-500/20">{loading ? <Spinner className='text-black'/> : 'Build Board'}</button>
                {result && <div className="liquid-panel p-6 rounded-[32px] border border-white/5 text-white leading-relaxed whitespace-pre-wrap">{result}</div>}
            </main>
        </div>
    );
};
export default CheeseBoardScreen;