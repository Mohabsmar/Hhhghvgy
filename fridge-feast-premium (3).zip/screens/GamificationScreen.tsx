
import React, { useState } from 'react';
import { User, Language, Badge, AppScreen } from '../types';
import { BADGES, RANKS, getTranslation } from '../constants';

interface GamificationScreenProps {
    user: User;
    onExit: () => void;
    lang: Language;
    onNavigate?: (screen: AppScreen) => void;
}

const GamificationScreen: React.FC<GamificationScreenProps> = ({ user, onExit, lang, onNavigate }) => {
    const t = (key: any) => getTranslation(lang, key);
    // Mock user progress for visual density
    const currentXP = 3450;
    const currentLevel = 12;
    const nextLevelXP = 5000;
    const progress = (currentXP / nextLevelXP) * 100;
    const currentRank = RANKS.find(r => r.level <= currentLevel)?.name || 'Chef';

    const BadgeCard: React.FC<{badge: Badge, unlocked: boolean}> = ({ badge, unlocked }) => (
        <div className={`aspect-square rounded-[32px] p-4 flex flex-col items-center justify-center text-center gap-3 border transition-all duration-300 relative overflow-hidden group ${unlocked ? 'bg-surface-dark border-primary/30 shadow-lg shadow-primary/5' : 'bg-white/5 border-white/5 opacity-60 grayscale'}`}>
            <div className={`size-16 rounded-full flex items-center justify-center text-3xl mb-1 ${unlocked ? 'bg-primary/20 text-primary' : 'bg-white/10 text-white/20'}`}>
                <span className="material-symbols-outlined">{badge.icon}</span>
            </div>
            <div>
                <h4 className="font-bold text-white text-sm leading-tight line-clamp-1">{badge.name}</h4>
                <p className="text-[10px] text-text-dark-secondary mt-1 line-clamp-2">{badge.description}</p>
            </div>
            {unlocked && <div className="absolute inset-0 bg-gradient-to-t from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>}
        </div>
    );

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 border-b border-white/5 rounded-b-[40px]">
                <div className="flex items-center justify-between mb-4">
                    <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white hover:bg-white/10 transition-colors">
                        <span className="material-symbols-outlined">arrow_back</span>
                    </button>
                    <h1 className="text-xl font-black text-white tracking-wide uppercase">{t('gamification')}</h1>
                    <div className="size-10"></div> 
                </div>
            </header>

            <main className="flex-1 overflow-y-auto p-6 space-y-8 pb-32">
                {/* Level Card */}
                <div className="liquid-panel rounded-[40px] p-8 border border-primary/20 relative overflow-hidden text-center shadow-2xl">
                    <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-primary/20 to-transparent pointer-events-none"></div>
                    
                    <div className="relative z-10 flex flex-col items-center">
                        <div className="size-32 rounded-full border-4 border-primary/50 flex items-center justify-center bg-background-dark shadow-[0_0_40px_rgba(16,185,129,0.3)] mb-4 relative">
                            <span className="text-5xl font-black text-white">{currentLevel}</span>
                            <div className="absolute -bottom-3 bg-primary text-black text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">Level</div>
                        </div>
                        
                        <h2 className="text-3xl font-black text-white mb-1">{currentRank}</h2>
                        <p className="text-text-dark-secondary text-sm font-medium mb-6">{currentXP} / {nextLevelXP} XP</p>
                        
                        <div className="w-full h-4 bg-white/10 rounded-full overflow-hidden border border-white/5">
                            <div className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-1000 ease-out shadow-[0_0_15px_#10B981]" style={{width: `${progress}%`}}></div>
                        </div>
                        <p className="text-xs text-primary font-bold mt-3 uppercase tracking-wide">{Math.round(nextLevelXP - currentXP)} XP to next rank</p>
                    </div>
                </div>

                {/* View Leaderboard CTA */}
                <button 
                    onClick={() => onNavigate && onNavigate('leaderboard')}
                    className="w-full py-5 rounded-[32px] bg-gradient-to-r from-yellow-600/20 to-orange-600/20 border border-yellow-500/30 flex items-center justify-between px-6 hover:scale-[1.02] transition-transform active:scale-95 group"
                >
                    <div className="flex items-center gap-4">
                        <div className="size-12 rounded-2xl bg-yellow-500/20 flex items-center justify-center text-yellow-400">
                            <span className="material-symbols-outlined text-2xl">emoji_events</span>
                        </div>
                        <div className="text-left">
                            <h3 className="text-white font-bold text-lg">Global Leaderboard</h3>
                            <p className="text-yellow-400 text-xs font-bold uppercase tracking-wider">See your rank</p>
                        </div>
                    </div>
                    <span className="material-symbols-outlined text-white/50 group-hover:translate-x-1 transition-transform">arrow_forward_ios</span>
                </button>

                {/* Stats Row */}
                <div className="grid grid-cols-2 gap-4">
                    <div className="liquid-panel p-5 rounded-[32px] border border-white/5 flex flex-col items-center gap-2">
                        <span className="material-symbols-outlined text-3xl text-orange-400">local_fire_department</span>
                        <span className="text-2xl font-black text-white">12</span>
                        <span className="text-[10px] text-text-dark-secondary uppercase font-bold tracking-wider">Day Streak</span>
                    </div>
                    <div className="liquid-panel p-5 rounded-[32px] border border-white/5 flex flex-col items-center gap-2">
                        <span className="material-symbols-outlined text-3xl text-blue-400">menu_book</span>
                        <span className="text-2xl font-black text-white">45</span>
                        <span className="text-[10px] text-text-dark-secondary uppercase font-bold tracking-wider">Recipes Cooked</span>
                    </div>
                </div>

                {/* Badges Grid */}
                <div>
                    <h3 className="text-lg font-bold text-white mb-4 px-2 flex items-center gap-2">
                        <span className="material-symbols-outlined text-primary">military_tech</span>
                        Achievements
                        <span className="bg-white/10 text-white text-xs px-2 py-0.5 rounded-full">{BADGES.length}</span>
                    </h3>
                    <div className="grid grid-cols-3 gap-3">
                        {BADGES.map((badge, idx) => (
                            <BadgeCard key={badge.id} badge={badge} unlocked={idx < 5} />
                        ))}
                    </div>
                </div>
            </main>
        </div>
    );
};

export default GamificationScreen;
