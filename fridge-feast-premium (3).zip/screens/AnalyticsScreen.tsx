
import React from 'react';
import { User, Language } from '../types';
import { getTranslation } from '../constants';

interface AnalyticsScreenProps {
    user: User;
    onExit: () => void;
    lang: Language;
}

const AnalyticsScreen: React.FC<AnalyticsScreenProps> = ({ user, onExit, lang }) => {
    const t = (key: any) => getTranslation(lang, key);
    
    // Mock Data for Charts
    const weeklyCalories = [1800, 2100, 1950, 2400, 2200, 1600, 2000];
    const maxCal = Math.max(...weeklyCalories);

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 border-b border-white/5 rounded-b-[40px]">
                <div className="flex items-center justify-between mb-2">
                    <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white hover:bg-white/10 transition-colors">
                        <span className="material-symbols-outlined">arrow_back</span>
                    </button>
                    <h1 className="text-xl font-black text-white tracking-wide uppercase">{t('analytics')}</h1>
                    <div className="size-10"></div>
                </div>
            </header>

            <main className="flex-1 overflow-y-auto p-6 space-y-6 pb-32">
                
                {/* Hero Stat */}
                <div className="liquid-panel p-6 rounded-[36px] border border-white/5 bg-gradient-to-br from-primary/10 to-transparent">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="size-10 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                            <span className="material-symbols-outlined">savings</span>
                        </div>
                        <span className="text-sm font-bold text-white uppercase tracking-wider">Total Savings</span>
                    </div>
                    <h2 className="text-5xl font-black text-white">$248.50</h2>
                    <p className="text-xs text-text-dark-secondary mt-2 font-medium">Saved by cooking at home this month vs eating out.</p>
                </div>

                {/* Calorie Chart */}
                <div className="liquid-panel p-6 rounded-[36px] border border-white/5">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="font-bold text-white text-lg">Calorie Intake</h3>
                        <span className="text-xs font-bold text-text-dark-secondary bg-white/5 px-2 py-1 rounded-md">Last 7 Days</span>
                    </div>
                    <div className="flex items-end justify-between h-40 gap-2">
                        {weeklyCalories.map((cal, i) => (
                            <div key={i} className="flex flex-col items-center gap-2 flex-1 group">
                                <div className="w-full bg-white/5 rounded-t-lg relative overflow-hidden flex items-end h-full">
                                    <div 
                                        className="w-full bg-primary/50 group-hover:bg-primary transition-all duration-500 rounded-t-lg"
                                        style={{height: `${(cal / maxCal) * 100}%`}}
                                    ></div>
                                </div>
                                <span className="text-[10px] font-bold text-text-dark-secondary uppercase">{['M','T','W','T','F','S','S'][i]}</span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Cuisine Breakdown */}
                <div className="liquid-panel p-6 rounded-[36px] border border-white/5">
                    <h3 className="font-bold text-white text-lg mb-6">Top Cuisines</h3>
                    <div className="space-y-4">
                        {[
                            { name: 'Italian', count: 12, color: 'bg-green-500' },
                            { name: 'Mexican', count: 8, color: 'bg-red-500' },
                            { name: 'Japanese', count: 5, color: 'bg-orange-500' }
                        ].map((c, i) => (
                            <div key={i} className="flex items-center gap-4">
                                <div className={`size-10 rounded-xl ${c.color} bg-opacity-20 flex items-center justify-center text-white`}>
                                    <span className="font-bold text-sm">{i+1}</span>
                                </div>
                                <div className="flex-1">
                                    <div className="flex justify-between mb-1">
                                        <span className="font-bold text-white text-sm">{c.name}</span>
                                        <span className="text-xs font-bold text-text-dark-secondary">{c.count} meals</span>
                                    </div>
                                    <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                                        <div className={`h-full ${c.color} rounded-full`} style={{width: `${(c.count/25)*100}%`}}></div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Waste Reduction */}
                <div className="liquid-panel p-6 rounded-[36px] border border-white/5 flex items-center justify-between">
                    <div>
                        <h3 className="font-bold text-white text-lg">Waste Reduced</h3>
                        <p className="text-xs text-text-dark-secondary mt-1">Impact on the planet</p>
                    </div>
                    <div className="text-right">
                        <span className="text-3xl font-black text-emerald-400">4.2kg</span>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default AnalyticsScreen;
