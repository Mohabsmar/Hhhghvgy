
import React, { useState } from 'react';

const GUIDES = [
    { id: 'v60', title: 'V60 Pour Over', ratio: '1:16', steps: [{ t: 45, i: 'Bloom' }, { t: 90, i: 'Pour to 60%' }, { t: 60, i: 'Finish Pour' }] },
    { id: 'french', title: 'French Press', ratio: '1:15', steps: [{ t: 240, i: 'Steep' }, { t: 30, i: 'Press' }] },
    { id: 'espresso', title: 'Espresso', ratio: '1:2', steps: [{ t: 30, i: 'Extract' }] },
];

const CoffeeBarScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [activeGuide, setActiveGuide] = useState<any>(null);
    const [timer, setTimer] = useState(0);
    const [isRunning, setIsRunning] = useState(false);

    React.useEffect(() => {
        let interval: any;
        if(isRunning && timer > 0) interval = setInterval(() => setTimer(t => t - 1), 1000);
        else setIsRunning(false);
        return () => clearInterval(interval);
    }, [isRunning, timer]);

    const startStep = (time: number) => {
        setTimer(time);
        setIsRunning(true);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Coffee Bar</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6 overflow-y-auto">
                {!activeGuide ? (
                    <div className="grid gap-4">
                        {GUIDES.map(g => (
                            <button key={g.id} onClick={() => setActiveGuide(g)} className="liquid-panel p-6 rounded-[32px] border border-white/5 text-left hover:bg-white/5 transition-colors">
                                <h3 className="text-2xl font-bold text-white">{g.title}</h3>
                                <p className="text-primary font-bold text-sm mt-1">{g.ratio} Ratio</p>
                            </button>
                        ))}
                    </div>
                ) : (
                    <div className="space-y-8">
                        <button onClick={() => setActiveGuide(null)} className="text-sm font-bold text-text-dark-secondary hover:text-white">Back to Guides</button>
                        <div className="text-center">
                            <h2 className="text-3xl font-black text-white">{activeGuide.title}</h2>
                            <div className="mt-8 size-64 rounded-full border-4 border-white/10 mx-auto flex items-center justify-center bg-white/5">
                                <span className="text-7xl font-black text-white font-mono">{timer}s</span>
                            </div>
                        </div>
                        <div className="space-y-4">
                            {activeGuide.steps.map((s: any, i: number) => (
                                <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                                    <span className="font-bold text-white">{s.i}</span>
                                    <button onClick={() => startStep(s.t)} className="px-4 py-2 bg-primary text-black font-bold rounded-lg text-sm">Start {s.t}s</button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
};
export default CoffeeBarScreen;
