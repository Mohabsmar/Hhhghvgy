
import React, { useState, useEffect } from 'react';
import { KitchenTimer } from '../types';

const KitchenTimersScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [timers, setTimers] = useState<KitchenTimer[]>([]);
    const [newLabel, setNewLabel] = useState('');
    const [newMinutes, setNewMinutes] = useState(5);

    useEffect(() => {
        const interval = setInterval(() => {
            setTimers(prev => prev.map(t => {
                if (t.isRunning && t.remaining > 0) return { ...t, remaining: t.remaining - 1 };
                if (t.isRunning && t.remaining === 0) return { ...t, isRunning: false }; // Finished
                return t;
            }));
        }, 1000);
        return () => clearInterval(interval);
    }, []);

    const addTimer = () => {
        if(!newLabel) return;
        setTimers(prev => [...prev, { id: Date.now().toString(), label: newLabel, duration: newMinutes * 60, remaining: newMinutes * 60, isRunning: true }]);
        setNewLabel('');
    };

    const toggleTimer = (id: string) => {
        setTimers(prev => prev.map(t => t.id === id ? { ...t, isRunning: !t.isRunning } : t));
    };

    const deleteTimer = (id: string) => {
        setTimers(prev => prev.filter(t => t.id !== id));
    };

    const formatTime = (sec: number) => {
        const m = Math.floor(sec / 60).toString().padStart(2, '0');
        const s = (sec % 60).toString().padStart(2, '0');
        return `${m}:${s}`;
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Kitchen Timers</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6 overflow-y-auto">
                <div className="flex gap-2 mb-6">
                    <input value={newLabel} onChange={e => setNewLabel(e.target.value)} placeholder="Label (e.g. Pasta)" className="flex-1 bg-white/5 rounded-xl border-none text-white px-4" />
                    <input type="number" value={newMinutes} onChange={e => setNewMinutes(Number(e.target.value))} className="w-20 bg-white/5 rounded-xl border-none text-white px-2 text-center" />
                    <button onClick={addTimer} className="bg-primary text-white font-bold px-4 rounded-xl">Add</button>
                </div>
                
                <div className="grid gap-4">
                    {timers.map(timer => {
                        const progress = (timer.remaining / timer.duration) * 100;
                        return (
                            <div key={timer.id} className="liquid-panel p-4 rounded-[28px] border border-white/5 relative overflow-hidden">
                                <div className="absolute bottom-0 left-0 h-1 bg-primary transition-all duration-1000" style={{width: `${progress}%`}}></div>
                                <div className="flex justify-between items-center">
                                    <div>
                                        <h3 className="font-bold text-white text-lg">{timer.label}</h3>
                                        <p className="text-4xl font-black text-white font-mono mt-1">{formatTime(timer.remaining)}</p>
                                    </div>
                                    <div className="flex gap-3">
                                        <button onClick={() => toggleTimer(timer.id)} className={`size-12 rounded-full flex items-center justify-center ${timer.isRunning ? 'bg-yellow-500/20 text-yellow-400' : 'bg-green-500/20 text-green-400'}`}>
                                            <span className="material-symbols-outlined text-2xl">{timer.isRunning ? 'pause' : 'play_arrow'}</span>
                                        </button>
                                        <button onClick={() => deleteTimer(timer.id)} className="size-12 rounded-full bg-red-500/10 text-red-400 flex items-center justify-center">
                                            <span className="material-symbols-outlined">delete</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </main>
        </div>
    );
};
export default KitchenTimersScreen;
