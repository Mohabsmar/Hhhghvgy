
import React from 'react';
import { Recipe } from '../types';
import RecipeCard from '../components/common/recipe_generator/RecipeCard';

interface CookbookScreenProps {
  savedRecipes: Recipe[];
  onStartCooking: (recipe: Recipe) => void;
  onToggleSave: (recipe: Recipe) => void;
}

const CookbookScreen: React.FC<CookbookScreenProps> = ({ savedRecipes, onStartCooking, onToggleSave }) => {

  const isRecipeSaved = (recipeId: string) => savedRecipes.some(r => r.id === recipeId);

  return (
    <div className="px-4 pb-28 min-h-screen">
       <header className="flex items-center pt-4 pb-2 justify-between sticky top-0 bg-background-dark/80 backdrop-blur-sm z-30">
        <h1 className="text-text-dark text-2xl font-bold leading-tight tracking-[-0.015em] flex-1">
         My Cookbook
        </h1>
        <button className="flex items-center justify-center h-9 px-4 rounded-full bg-primary/20 text-primary text-sm font-semibold">
            <span className="material-symbols-outlined text-lg mr-1.5">add</span>
            New Collection
        </button>
      </header>
      
      {savedRecipes.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-[70vh] text-center px-8 animate-fade-in">
          <span className="material-symbols-outlined text-7xl text-primary/50 mb-4" style={{fontVariationSettings: `'FILL' 1`}}>
            menu_book
          </span>
          <h2 className="text-xl font-bold text-text-dark">Your Cookbook is Empty</h2>
          <p className="text-text-dark-secondary mt-2">
            Tap the heart icon on a recipe to save it to your cookbook.
          </p>
        </div>
      ) : (
        <div className="pt-4 animate-fade-in">
          <div className="grid grid-cols-1 gap-4">
            {savedRecipes.map(recipe => (
              <RecipeCard
                key={recipe.id}
                recipe={recipe}
                onSelect={() => onStartCooking(recipe)}
                isSaved={isRecipeSaved(recipe.id)}
                onToggleSave={onToggleSave}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CookbookScreen;
