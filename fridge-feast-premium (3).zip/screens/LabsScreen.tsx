import React, { useState } from 'react';
import { AppScreen } from '../types';

interface LabsScreenProps {
    onExit: () => void;
    onNavigate: (screen: AppScreen) => void;
}

const LabsScreen: React.FC<LabsScreenProps> = ({ onExit, onNavigate }) => {
    const [search, setSearch] = useState('');

    const features: { id: AppScreen, name: string, desc: string, icon: string, color: string, category: string }[] = [
        // Category: Precision Tools
        { id: 'unitConverter', name: 'Precision Converter', desc: 'Volume, mass, and temperature math.', icon: 'calculate', color: 'text-blue-400', category: 'Precision' },
        { id: 'kitchenTimers', name: 'Multi-Timers', desc: 'Sync 10+ burners simultaneously.', icon: 'timer', color: 'text-orange-400', category: 'Precision' },
        { id: 'sourdoughCalc', name: 'Sourdough Lab', desc: 'Hydration and starter ratios.', icon: 'bakery_dining', color: 'text-orange-200', category: 'Precision' },
        
        // Category: AI Sommeliers
        { id: 'winePairing', name: 'Wine Pairer', desc: 'Sommelier-grade bottle matches.', icon: 'wine_bar', color: 'text-purple-400', category: 'Drink' },
        { id: 'sommelierChat', name: 'Sommelier Chat', desc: 'Deep-dive wine discussions.', icon: 'forum', color: 'text-purple-300', category: 'Drink' },
        { id: 'mixology', name: 'Mixology AI', desc: 'Mood-based cocktail creation.', icon: 'local_bar', color: 'text-pink-400', category: 'Drink' },
        { id: 'coffeeBar', name: 'Barista Mode', desc: 'Perfect pour-over brew guides.', icon: 'coffee', color: 'text-amber-700', category: 'Drink' },
        { id: 'teaLounge', name: 'Tea Lounge', desc: 'Temperature & steep time logic.', icon: 'emoji_food_beverage', color: 'text-green-300', category: 'Drink' },
        
        // Category: Discovery
        { id: 'leftoverMagic', name: 'Iron Chef Mode', desc: '3 random ingredients, 1 masterpiece.', icon: 'auto_fix_high', color: 'text-indigo-400', category: 'Gen' },
        { id: 'substitutions', name: 'AI Substitutions', desc: 'Find alternatives for any missing item.', icon: 'sync_alt', color: 'text-green-400', category: 'Gen' },
        { id: 'seasonalGuide', name: 'Seasonal Atlas', desc: 'Produce cycles by hemisphere.', icon: 'eco', color: 'text-emerald-400', category: 'Gen' },
        { id: 'foraging', name: 'Wild Foraging', desc: 'Identify edible nature safely.', icon: 'forest', color: 'text-green-700', category: 'Gen' },
        
        // Category: Education
        { id: 'cookingSchool', name: 'Skills Lab', desc: 'Video-guided knife & heat skills.', icon: 'school', color: 'text-red-400', category: 'Edu' },
        { id: 'dictionary', name: 'Culinary Dict.', desc: 'Definitions of 5,000+ techniques.', icon: 'menu_book', color: 'text-yellow-400', category: 'Edu' },
        { id: 'butcheryGuide', name: 'Butchery 101', desc: 'Understand every primal cut.', icon: 'restaurant_menu', color: 'text-red-700', category: 'Edu' },
        { id: 'molecularGastronomy', name: 'Molecular Lab', desc: 'Foams, gels, and spherification.', icon: 'bubble_chart', color: 'text-purple-500', category: 'Edu' },

        // Category: Management
        { id: 'mealPrep', name: 'Prep Workflow', desc: 'Batch cooking task manager.', icon: 'bento', color: 'text-amber-400', category: 'Ops' },
        { id: 'priceCompare', name: 'Price Radar', desc: 'Cross-store cost comparison.', icon: 'price_check', color: 'text-green-500', category: 'Ops' },
        { id: 'applianceTracker', name: 'Appliance Care', desc: 'Service logs for your gear.', icon: 'home_repair_service', color: 'text-blue-300', category: 'Ops' },
        { id: 'knifeCare', name: 'Blade Health', desc: 'Sharpening schedule & angles.', icon: 'content_cut', color: 'text-gray-200', category: 'Ops' },
        { id: 'familySync', name: 'Family Network', desc: 'Cloud-sync pantry & plans.', icon: 'sync', color: 'text-blue-200', category: 'Ops' },

        // Category: Specialized
        { id: 'halalScanner', name: 'Compliance AI', desc: 'Halal/Kosher ingredient check.', icon: 'verified', color: 'text-emerald-600', category: 'Safe' },
        { id: 'allergyRadar', name: 'Allergy Radar', desc: 'Cross-contamination risks.', icon: 'warning', color: 'text-red-500', category: 'Safe' },
        { id: 'labelDecoder', name: 'Label Decoder', desc: 'Demystify additive names.', icon: 'fact_check', color: 'text-blue-500', category: 'Safe' },
        { id: 'tasteProfiler', name: 'Taste DNA', desc: 'Map your unique flavor profile.', icon: 'palette', color: 'text-teal-400', category: 'Bio' },
        { id: 'fermentationLog', name: 'Ferment Lab', desc: 'Microbiology for starters.', icon: 'science', color: 'text-lime-400', category: 'Bio' },
    ];

    const filtered = features.filter(f => f.name.toLowerCase().includes(search.toLowerCase()) || f.desc.toLowerCase().includes(search.toLowerCase()));

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-reveal overflow-hidden">
            {/* Header */}
            <div className="relative pt-safe-top pb-8 px-6 liquid-glass shrink-0 border-b border-white/10 rounded-b-[48px]">
                <div className="flex justify-between items-center mb-8 pt-4">
                    <button onClick={onExit} className="size-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white active:scale-90 transition-transform">
                        <span className="material-symbols-outlined">arrow_back</span>
                    </button>
                    <div className="text-center">
                        <h1 className="text-3xl font-black text-white tracking-tighter">Kitchen Labs</h1>
                        <p className="text-[10px] font-black text-primary uppercase tracking-[0.3em]">Experimental Suite</p>
                    </div>
                    <div className="size-12"></div>
                </div>
                
                <div className="relative group">
                    <div className="absolute inset-0 bg-primary/10 blur-xl opacity-0 group-focus-within:opacity-100 transition-opacity"></div>
                    <span className="material-symbols-outlined absolute left-5 top-1/2 -translate-y-1/2 text-white/30">search</span>
                    <input 
                        type="text" 
                        placeholder="Search 40+ specialized tools..." 
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                        className="w-full h-14 bg-white/5 rounded-[24px] pl-14 pr-6 text-white text-[15px] font-bold border border-white/10 focus:border-primary/40 focus:ring-0 transition-all relative z-10"
                    />
                </div>
            </div>

            <main className="flex-1 overflow-y-auto p-6 no-scrollbar pb-32">
                <div className="grid grid-cols-2 gap-4">
                    {filtered.map((feature, idx) => (
                        <button 
                            key={feature.id}
                            onClick={() => onNavigate(feature.id)}
                            className="liquid-panel p-6 rounded-[36px] border border-white/5 flex flex-col items-center text-center gap-4 group active:scale-[0.98] transition-all animate-slide-up"
                            style={{ animationDelay: `${idx * 40}ms`, animationFillMode: 'backwards' }}
                        >
                            <div className={`size-16 rounded-[22px] bg-white/5 flex items-center justify-center ${feature.color} border border-white/5 group-hover:scale-110 group-hover:rotate-3 transition-transform shadow-lg`}>
                                <span className="material-symbols-outlined text-3xl">{feature.icon}</span>
                            </div>
                            <div className="space-y-1">
                                <h3 className="text-[15px] font-black text-white leading-tight">{feature.name}</h3>
                                <p className="text-[10px] font-bold text-text-dark-secondary leading-snug line-clamp-2">{feature.desc}</p>
                            </div>
                            <div className="mt-auto pt-2">
                                <span className="text-[8px] font-black uppercase tracking-widest text-primary opacity-50 group-hover:opacity-100 transition-opacity">Enter Module</span>
                            </div>
                        </button>
                    ))}
                </div>
                
                {filtered.length === 0 && (
                    <div className="flex flex-col items-center justify-center py-20 opacity-30 text-center">
                        <span className="material-symbols-outlined text-6xl mb-4">search_off</span>
                        <p className="text-xl font-bold">No experiment found</p>
                        <p className="text-sm">Try searching for 'AI', 'Drink' or 'Lab'</p>
                    </div>
                )}
            </main>
        </div>
    );
};

export default LabsScreen;