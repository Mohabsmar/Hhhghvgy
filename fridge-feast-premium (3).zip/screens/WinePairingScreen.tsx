import React, { useState } from 'react';
import { recommendWine } from '../common/geminiService';
import Spinner from '../components/common/Spinner';

const WinePairingScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [dish, setDish] = useState('');
    const [result, setResult] = useState<any>(null);
    const [loading, setLoading] = useState(false);

    const handlePair = async () => {
        if(!dish) return;
        setLoading(true);
        const res = await recommendWine(dish);
        setResult(res);
        setLoading(false);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">AI Sommelier</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 flex flex-col items-center justify-center space-y-8">
                {!result ? (
                    <div className="w-full max-w-sm space-y-6">
                        <div className="text-center">
                            <span className="material-symbols-outlined text-7xl text-purple-400 mb-4">wine_bar</span>
                            <h2 className="text-2xl font-bold text-white">What are you eating?</h2>
                            <p className="text-text-dark-secondary">I'll find the perfect bottle.</p>
                        </div>
                        <input value={dish} onChange={e => setDish(e.target.value)} placeholder="e.g. Ribeye Steak" className="w-full h-14 bg-white/5 rounded-full px-6 text-white border border-white/10 text-center text-lg focus:border-purple-500" />
                        <button onClick={handlePair} disabled={loading} className="w-full h-14 bg-purple-600 rounded-full text-white font-bold text-lg shadow-lg shadow-purple-600/20">{loading ? <Spinner /> : 'Pair Wine'}</button>
                    </div>
                ) : (
                    <div className="w-full max-w-sm liquid-panel p-8 rounded-[40px] border border-white/10 text-center animate-fade-in">
                        <span className="text-xs font-bold text-purple-400 uppercase tracking-widest mb-2 block">{result.type} Wine</span>
                        <h2 className="text-3xl font-black text-white mb-4 leading-tight">{result.name}</h2>
                        <p className="text-white/80 leading-relaxed mb-6">{result.description}</p>
                        <div className="inline-block px-4 py-2 bg-white/10 rounded-full text-sm font-bold text-white">{result.priceRange}</div>
                        <button onClick={() => setResult(null)} className="mt-8 text-sm font-bold text-white/50 hover:text-white">Try Another</button>
                    </div>
                )}
            </main>
        </div>
    );
};
export default WinePairingScreen;