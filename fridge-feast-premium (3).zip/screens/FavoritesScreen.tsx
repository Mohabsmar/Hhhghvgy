
import React from 'react';
import { Recipe, Language } from '../types';
import RecipeCard from '../components/common/recipe_generator/RecipeCard';
import { getTranslation } from '../constants';

interface FavoritesScreenProps {
  savedRecipes: Recipe[];
  onSelectRecipe: (recipe: Recipe) => void;
  onToggleSave: (recipe: Recipe) => void;
  lang: Language;
}

const FavoritesScreen: React.FC<FavoritesScreenProps> = ({ savedRecipes, onSelectRecipe, onToggleSave, lang }) => {
  const t = (key: any) => getTranslation(lang, key);
  const isRecipeSaved = (recipeId: string) => savedRecipes.some(r => r.id === recipeId);

  return (
    <div className="px-4 pb-28 min-h-screen font-display">
       <header className="flex items-center pt-8 pb-4 justify-between sticky top-0 liquid-glass z-30 -mx-4 px-4 border-b border-white/5 rounded-b-[32px]">
        <h1 className="text-white text-2xl font-black leading-tight tracking-[-0.015em] flex-1">
         {t('saved')}
        </h1>
      </header>
      
      {savedRecipes.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-[70vh] text-center px-8 animate-fade-in opacity-50">
          <span className="material-symbols-outlined text-7xl text-white/50 mb-4" style={{fontVariationSettings: `'FILL' 1`}}>
            favorite
          </span>
          <h2 className="text-xl font-bold text-white">No Favorites Yet</h2>
          <p className="text-sm text-text-dark-secondary mt-1">Your saved recipes will appear here.</p>
        </div>
      ) : (
        <div className="pt-6 animate-fade-in">
          <div className="grid grid-cols-1 gap-6">
            {savedRecipes.map(recipe => (
              <RecipeCard
                key={recipe.id}
                recipe={recipe}
                onSelect={() => onSelectRecipe(recipe)}
                isSaved={isRecipeSaved(recipe.id)}
                onToggleSave={onToggleSave}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default FavoritesScreen;
