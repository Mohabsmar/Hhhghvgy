import React, { useState } from 'react';
import { askCulinaryExpert } from '../common/geminiService';
import Spinner from '../components/common/Spinner';

const SommelierChatScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [messages, setMessages] = useState<{role: 'user'|'model', text: string}[]>([{role: 'model', text: 'Hello. I am your personal Sommelier. What are you serving tonight?'}]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);

    const handleSend = async () => {
        if(!input.trim()) return;
        const userMsg = input;
        setMessages(prev => [...prev, {role: 'user', text: userMsg}]);
        setInput('');
        setLoading(true);
        const res = await askCulinaryExpert('Master Sommelier', `(Context: Previous msgs: ${JSON.stringify(messages)}) User: ${userMsg}`);
        setMessages(prev => [...prev, {role: 'model', text: res}]);
        setLoading(false);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Sommelier</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-4 space-y-4 overflow-y-auto pb-24">
                {messages.map((m, i) => (
                    <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] p-4 rounded-2xl ${m.role === 'user' ? 'bg-purple-600 text-white rounded-tr-none' : 'bg-surface-dark border border-white/10 text-white rounded-tl-none'}`}>
                            {m.text}
                        </div>
                    </div>
                ))}
                {loading && <div className="text-white/50 text-xs ml-4">Pouring...</div>}
            </main>
            <div className="absolute bottom-0 left-0 right-0 p-4 safe-area-bottom bg-background-dark/90 backdrop-blur">
                <div className="flex gap-2">
                    <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSend()} className="flex-1 h-12 bg-white/5 rounded-full px-6 text-white border border-white/10 focus:border-purple-500" placeholder="Ask about wine..." />
                    <button onClick={handleSend} className="size-12 rounded-full bg-purple-600 flex items-center justify-center text-white shadow-lg"><span className="material-symbols-outlined">send</span></button>
                </div>
            </div>
        </div>
    );
};
export default SommelierChatScreen;