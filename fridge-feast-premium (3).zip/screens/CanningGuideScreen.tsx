import React, { useState } from 'react';
import { askCulinaryExpert } from '../common/geminiService';
import Spinner from '../components/common/Spinner';

const CanningGuideScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [query, setQuery] = useState('');
    const [result, setResult] = useState('');
    const [loading, setLoading] = useState(false);

    const handleAsk = async () => {
        setLoading(true);
        const res = await askCulinaryExpert('Canning Safety Expert', `How do I safely can/preserve: ${query}? Include acidity info and processing time.`);
        setResult(res);
        setLoading(false);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Canning Safe</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6">
                <div className="text-center py-6">
                    <span className="material-symbols-outlined text-6xl text-gray-400 mb-4">kitchen</span>
                    <h2 className="text-2xl font-bold text-white">Preservation Guide</h2>
                </div>
                <input value={query} onChange={e => setQuery(e.target.value)} placeholder="e.g. Tomatoes, Salsa" className="w-full h-14 bg-white/5 rounded-full px-6 text-white border border-white/10 text-center text-lg focus:border-gray-500" />
                <button onClick={handleAsk} disabled={loading} className="w-full h-14 bg-gray-600 rounded-full text-white font-bold text-lg shadow-lg shadow-gray-600/20">{loading ? <Spinner /> : 'Get Guide'}</button>
                {result && <div className="liquid-panel p-6 rounded-[32px] border border-white/5 text-white leading-relaxed whitespace-pre-wrap">{result}</div>}
            </main>
        </div>
    );
};
export default CanningGuideScreen;