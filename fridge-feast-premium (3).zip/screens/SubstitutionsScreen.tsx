import React, { useState } from 'react';
import { findSubstitutions } from '../common/geminiService';
import Spinner from '../components/common/Spinner';

const SubstitutionsScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [query, setQuery] = useState('');
    const [data, setData] = useState<any>(null);
    const [loading, setLoading] = useState(false);

    const handleSearch = async () => {
        if(!query) return;
        setLoading(true);
        const res = await findSubstitutions(query);
        setData(res);
        setLoading(false);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Substitutions</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6">
                <div className="flex gap-2">
                    <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Missing ingredient..." className="flex-1 h-12 bg-white/5 rounded-full px-6 text-white border border-white/10" />
                    <button onClick={handleSearch} disabled={loading} className="size-12 rounded-full bg-primary flex items-center justify-center text-white shadow-lg">{loading ? <Spinner className='size-5' /> : <span className="material-symbols-outlined">search</span>}</button>
                </div>
                
                {data && (
                    <div className="space-y-4">
                        <h3 className="text-lg font-bold text-white px-2">Subs for {data.original}</h3>
                        {data.substitutes.map((s: any, i: number) => (
                            <div key={i} className="liquid-panel p-5 rounded-[24px] border border-white/5">
                                <div className="flex justify-between mb-2">
                                    <h4 className="font-bold text-white text-lg">{s.name}</h4>
                                    <span className="text-xs font-bold bg-white/10 px-2 py-1 rounded text-white">{s.ratio}</span>
                                </div>
                                <p className="text-sm text-text-dark-secondary">{s.notes}</p>
                            </div>
                        ))}
                    </div>
                )}
            </main>
        </div>
    );
};
export default SubstitutionsScreen;