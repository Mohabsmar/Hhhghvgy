
import React from 'react';
import { User } from '../types';

interface StatusBarEditorScreenProps {
    user: User;
    onUpdateUser: (user: Partial<User>) => void;
    onExit: () => void;
}

const StatusBarEditorScreen: React.FC<StatusBarEditorScreenProps> = ({ onExit }) => {
    return (
        <div className="fixed inset-0 bg-[#0F172A] z-50 flex flex-col items-center justify-center p-6">
            <h2 className="text-xl font-bold text-white mb-4">Status Bar Settings</h2>
            <p className="text-text-dark-secondary text-center mb-6">This feature has been removed.</p>
            <button onClick={onExit} className="px-6 py-2 bg-primary text-white rounded-full font-bold">Go Back</button>
        </div>
    );
};

export default StatusBarEditorScreen;
