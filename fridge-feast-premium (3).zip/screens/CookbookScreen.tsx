
import React from 'react';
import FavoritesScreen from './FavoritesScreen';
import { Recipe, Language } from '../types';

// This screen is an alias for Favorites/Saved Recipes
const CookbookScreen: React.FC<{
  savedRecipes: Recipe[];
  onStartCooking: (recipe: Recipe) => void;
  onToggleSave: (recipe: Recipe) => void;
  lang: Language;
}> = (props) => {
  return <FavoritesScreen 
    savedRecipes={props.savedRecipes}
    onSelectRecipe={props.onStartCooking} // Mapping prop name
    onToggleSave={props.onToggleSave}
    lang={props.lang}
  />;
};

export default CookbookScreen;
