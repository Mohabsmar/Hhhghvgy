
import React, { useState } from 'react';

const SourdoughCalcScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [flour, setFlour] = useState(500);
    const [water, setWater] = useState(350);
    const [starter, setStarter] = useState(100);
    const [starterHydration, setStarterHydration] = useState(100); // 100% hydration usually

    const calculate = () => {
        const starterFlour = starter / (1 + (starterHydration/100));
        const starterWater = starter - starterFlour;
        
        const totalFlour = flour + starterFlour;
        const totalWater = water + starterWater;
        
        const hydration = (totalWater / totalFlour) * 100;
        return hydration.toFixed(1);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Sourdough Calc</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-8">
                <div className="space-y-4">
                    <div className="flex justify-between items-center">
                        <label className="text-white font-bold">Flour (g)</label>
                        <input type="number" value={flour} onChange={e => setFlour(Number(e.target.value))} className="w-24 bg-white/10 rounded-xl px-3 py-2 text-white font-mono text-right" />
                    </div>
                    <div className="flex justify-between items-center">
                        <label className="text-white font-bold">Water (g)</label>
                        <input type="number" value={water} onChange={e => setWater(Number(e.target.value))} className="w-24 bg-white/10 rounded-xl px-3 py-2 text-white font-mono text-right" />
                    </div>
                    <div className="flex justify-between items-center">
                        <label className="text-white font-bold">Starter (g)</label>
                        <input type="number" value={starter} onChange={e => setStarter(Number(e.target.value))} className="w-24 bg-white/10 rounded-xl px-3 py-2 text-white font-mono text-right" />
                    </div>
                </div>

                <div className="liquid-panel p-8 rounded-[40px] border border-orange-500/20 text-center">
                    <p className="text-orange-400 text-xs font-bold uppercase tracking-widest mb-2">Total Hydration</p>
                    <h2 className="text-6xl font-black text-white">{calculate()}%</h2>
                    <p className="text-text-dark-secondary mt-4 text-sm">
                        {parseFloat(calculate()) > 75 ? "High Hydration - Open Crumb" : "Standard Hydration - Easy to Handle"}
                    </p>
                </div>
            </main>
        </div>
    );
};
export default SourdoughCalcScreen;
