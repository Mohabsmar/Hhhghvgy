
import React from 'react';

const COURSES = [
    { id: '1', title: 'Knife Skills 101', level: 'Beginner', progress: 0, image: 'https://images.unsplash.com/photo-1590779033100-9f60a05a013d?auto=format&fit=crop&w=400' },
    { id: '2', title: 'Mastering Heat', level: 'Intermediate', progress: 30, image: 'https://images.unsplash.com/photo-1556910103-1c02745a30bf?auto=format&fit=crop&w=400' },
    { id: '3', title: 'Sauces & Emulsions', level: 'Advanced', progress: 0, image: 'https://images.unsplash.com/photo-1472476443507-c7a392dd12c7?auto=format&fit=crop&w=400' },
];

const CookingSchoolScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Cooking School</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6 overflow-y-auto">
                {COURSES.map(course => (
                    <div key={course.id} className="liquid-panel rounded-[32px] overflow-hidden border border-white/5 group cursor-pointer hover:border-primary/50 transition-colors">
                        <div className="h-40 relative">
                            <img src={course.image} className="w-full h-full object-cover" />
                            <div className="absolute inset-0 bg-black/40"></div>
                            <div className="absolute top-4 right-4 bg-black/60 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-white uppercase">{course.level}</div>
                        </div>
                        <div className="p-6">
                            <h3 className="text-xl font-bold text-white mb-2">{course.title}</h3>
                            <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                                <div className="h-full bg-primary" style={{width: `${course.progress}%`}}></div>
                            </div>
                            <p className="text-xs text-text-dark-secondary mt-2 font-bold">{course.progress}% Complete</p>
                        </div>
                    </div>
                ))}
            </main>
        </div>
    );
};
export default CookingSchoolScreen;
