import React, { useState } from 'react';
import { askCulinaryExpert } from '../common/geminiService';
import Spinner from '../components/common/Spinner';

const HalalScannerScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [ingredients, setIngredients] = useState('');
    const [result, setResult] = useState('');
    const [loading, setLoading] = useState(false);

    const handleScan = async () => {
        setLoading(true);
        const res = await askCulinaryExpert('Halal Certifier', `Analyze this ingredient list for Halal/Kosher compliance: "${ingredients}". Flag any pork, alcohol, or haram additives.`);
        setResult(res);
        setLoading(false);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Halal Scanner</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6">
                <div className="text-center py-6">
                    <span className="material-symbols-outlined text-6xl text-emerald-500 mb-4">verified</span>
                    <h2 className="text-2xl font-bold text-white">Ingredient Check</h2>
                    <p className="text-text-dark-secondary">Paste ingredients below.</p>
                </div>
                <textarea value={ingredients} onChange={e => setIngredients(e.target.value)} placeholder="e.g. Gelatin, E120, Whey..." className="w-full h-32 bg-white/5 rounded-3xl p-4 text-white border border-white/10 focus:border-emerald-500 resize-none" />
                <button onClick={handleScan} disabled={loading} className="w-full h-14 bg-emerald-600 rounded-full text-white font-bold text-lg shadow-lg shadow-emerald-600/20">{loading ? <Spinner /> : 'Check Compliance'}</button>
                {result && <div className="liquid-panel p-6 rounded-[32px] border border-white/5 text-white leading-relaxed whitespace-pre-wrap">{result}</div>}
            </main>
        </div>
    );
};
export default HalalScannerScreen;