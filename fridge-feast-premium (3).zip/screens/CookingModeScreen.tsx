
import React, { useState, useEffect, useCallback } from 'react';
import { Recipe, Language } from '../types';
import { getTranslation } from '../constants';

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

const CookingModeScreen: React.FC<{ recipe: Recipe; onExit: () => void; onFinish: () => void, lang: Language }> = ({ recipe, onExit, onFinish, lang }) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [timerSeconds, setTimerSeconds] = useState<number>(0);
  const [initialSeconds, setInitialSeconds] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [isListening, setIsListening] = useState(false);
  
  const currentStepText = recipe.instructions[currentStepIndex];
  const isLastStep = currentStepIndex === recipe.instructions.length - 1;
  const t = (key: any) => getTranslation(lang, key);

  // Extract time from step text (e.g., "Cook for 10 minutes")
  useEffect(() => {
    const timeMatch = currentStepText.match(/(\d+)\s*(min|minute|sec|second)/i);
    if (timeMatch) {
        const val = parseInt(timeMatch[1]);
        const unit = timeMatch[2].toLowerCase();
        let seconds = 0;
        if (unit.startsWith('min')) seconds = val * 60;
        else seconds = val;
        
        setTimerSeconds(seconds);
        setInitialSeconds(seconds);
        setIsTimerRunning(false); // Auto-set but don't auto-start
    } else {
        setTimerSeconds(0);
        setInitialSeconds(0);
        setIsTimerRunning(false);
    }
  }, [currentStepIndex, currentStepText]);

  // Timer logic
  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | null = null;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds(sec => sec - 1);
      }, 1000);
    } else if (timerSeconds === 0 && isTimerRunning) {
        setIsTimerRunning(false);
        speak("Timer finished!");
    }
    return () => {
      if(interval) clearInterval(interval);
    };
  }, [isTimerRunning, timerSeconds]);

  const formatTime = (totalSeconds: number) => {
    const minutes = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, '0');
    const seconds = (totalSeconds % 60).toString().padStart(2, '0');
    return { minutes, seconds };
  };

  const { minutes, seconds } = formatTime(timerSeconds);

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      // Attempt to set voice based on language
      const voices = window.speechSynthesis.getVoices();
      const langCode = lang === 'en' ? 'en-US' : lang === 'tr' ? 'tr-TR' : lang === 'ar' ? 'ar-SA' : lang === 'zh' ? 'zh-CN' : lang === 'de' ? 'de-DE' : 'ru-RU';
      const voice = voices.find(v => v.lang.includes(langCode));
      if(voice) utterance.voice = voice;
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleVoiceCommand = useCallback((command: string) => {
    const cmd = command.toLowerCase();
    if (cmd.includes('next')) {
      setCurrentStepIndex(i => Math.min(i + 1, recipe.instructions.length - 1));
      speak('Next step.');
    } else if (cmd.includes('previous') || cmd.includes('back')) {
      setCurrentStepIndex(i => Math.max(i - 1, 0));
      speak('Previous step.');
    } else if (cmd.includes('start') || cmd.includes('resume')) {
      setIsTimerRunning(true);
      speak('Timer started.');
    } else if (cmd.includes('pause') || cmd.includes('stop')) {
      setIsTimerRunning(false);
      speak('Timer paused.');
    } else if (cmd.includes('repeat')) {
      speak(`Step ${currentStepIndex + 1}: ${currentStepText}`);
    } else if (cmd.includes('exit') || cmd.includes('quit')) {
      speak('Exiting cooking mode.');
      onExit();
    } else if (cmd.includes('finish') && isLastStep) {
        speak('Cooking finished. Enjoy your meal!');
        onFinish();
    }
  }, [currentStepIndex, recipe.instructions.length, currentStepText, onExit, onFinish, isLastStep]);

  useEffect(() => {
    if (!SpeechRecognition) return;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = lang === 'en' ? 'en-US' : lang === 'tr' ? 'tr-TR' : lang === 'ar' ? 'ar-SA' : lang === 'zh' ? 'zh-CN' : lang === 'de' ? 'de-DE' : 'ru-RU';

    recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        handleVoiceCommand(transcript);
    };
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    
    const voiceBtn = document.getElementById('voice-btn-main');
    const startListening = () => {
        if (!isListening) {
             speak("Listening");
             recognition.start();
        }
    };
    voiceBtn?.addEventListener('click', startListening);
    return () => voiceBtn?.removeEventListener('click', startListening);
  }, [isListening, handleVoiceCommand, lang]);

  const progressPercentage = ((currentStepIndex + 1) / recipe.instructions.length) * 100;

  const toggleTimer = () => {
      if (isTimerRunning) {
          setIsTimerRunning(false);
      } else {
          if (timerSeconds === 0 && initialSeconds > 0) {
              setTimerSeconds(initialSeconds);
          }
          setIsTimerRunning(true);
      }
  };
  
  // Circular Progress Props
  const radius = 90;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = initialSeconds > 0 
    ? circumference - ((initialSeconds - timerSeconds) / initialSeconds) * circumference 
    : 0;

  return (
    <div className="fixed inset-0 bg-background-dark/95 backdrop-blur-3xl text-white flex flex-col font-display animate-fade-in safe-area-inset-bottom z-50">
        {/* Background Ambient Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-2/3 bg-primary/10 blur-[120px] pointer-events-none rounded-full"></div>

        <header className="flex items-center justify-between p-6 z-10">
            <div className="flex flex-col">
                <h1 className="text-xs text-text-dark-secondary font-bold tracking-widest uppercase mb-1">{t('startCooking')}</h1>
                <p className="font-bold truncate max-w-[200px] text-primary text-lg leading-none">{recipe.recipeName}</p>
            </div>
            <button onClick={onExit} className="size-10 rounded-full bg-surface-dark border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors">
                <span className="material-symbols-outlined">close</span>
            </button>
        </header>

        <div className="w-full px-6 mb-2 z-10">
            <div className="flex justify-between text-xs font-bold text-text-dark-secondary mb-2">
                <span>{t('steps')} {currentStepIndex + 1}</span>
                <span>{recipe.instructions.length}</span>
            </div>
            <div className="w-full bg-surface-dark h-2 rounded-full overflow-hidden border border-white/5">
                <div 
                    className="bg-gradient-to-r from-primary to-secondary h-full rounded-full transition-all duration-500 ease-out shadow-[0_0_10px_rgba(139,92,246,0.5)]" 
                    style={{width: `${progressPercentage}%`}}
                ></div>
            </div>
        </div>

        <main className="flex-1 flex flex-col items-center px-8 relative z-10 space-y-6">
            <div className="min-h-[140px] flex items-center justify-center text-center pt-4 relative">
                <h2 className="text-2xl md:text-3xl font-bold leading-tight drop-shadow-xl transition-all duration-300">
                    {currentStepText}
                </h2>
                {/* Quotes decoration */}
                <span className="absolute top-0 -left-4 text-6xl text-primary/10 font-serif">"</span>
                <span className="absolute bottom-0 -right-4 text-6xl text-primary/10 font-serif rotate-180">"</span>
            </div>

            <div className="min-h-[340px] w-full flex items-center justify-center relative">
                {(timerSeconds > 0 || initialSeconds > 0) ? (
                    <div className="relative flex items-center justify-center animate-fade-in">
                        {/* SVG Circle Timer */}
                        <div className="relative size-72 flex items-center justify-center">
                            {/* Outer Glow Ring */}
                             <div className={`absolute inset-0 rounded-full border-2 border-primary/20 scale-110 transition-all duration-1000 ${isTimerRunning ? 'animate-pulse opacity-50' : 'opacity-0'}`}></div>

                            <svg className="size-full -rotate-90 transform" viewBox="0 0 200 200">
                                <defs>
                                    <linearGradient id="timerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                        <stop offset="0%" stopColor="#8B5CF6" />
                                        <stop offset="100%" stopColor="#EC4899" />
                                    </linearGradient>
                                    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                                        <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                                        <feMerge>
                                            <feMergeNode in="coloredBlur" />
                                            <feMergeNode in="SourceGraphic" />
                                        </feMerge>
                                    </filter>
                                </defs>
                                {/* Track */}
                                <circle
                                    cx="100"
                                    cy="100"
                                    r={radius}
                                    fill="none"
                                    stroke="rgba(255,255,255,0.05)"
                                    strokeWidth="8"
                                />
                                {/* Progress */}
                                <circle
                                    cx="100"
                                    cy="100"
                                    r={radius}
                                    fill="none"
                                    stroke="url(#timerGradient)"
                                    strokeWidth="8"
                                    strokeLinecap="round"
                                    filter="url(#glow)"
                                    className={`transition-all duration-1000 ease-linear ${isTimerRunning ? 'opacity-100' : 'opacity-60'}`}
                                    style={{
                                        strokeDasharray: circumference,
                                        strokeDashoffset: strokeDashoffset
                                    }}
                                />
                            </svg>
                            
                            {/* Digital Time Center */}
                            <div className="absolute inset-0 flex flex-col items-center justify-center">
                                <div className="flex items-baseline gap-0.5 text-shadow-lg font-mono">
                                    <span className="text-7xl font-bold tracking-tighter tabular-nums text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.3)]">{minutes}</span>
                                    <span className="text-7xl font-bold text-white/50 -translate-y-2">:</span>
                                    <span className="text-7xl font-bold tracking-tighter tabular-nums text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.3)]">{seconds}</span>
                                </div>
                                <div className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-black/40 backdrop-blur-md border border-white/10 mt-4 transition-all duration-300 ${isTimerRunning ? 'border-primary/50 bg-primary/10' : ''}`}>
                                    <span className={`size-2 rounded-full ${isTimerRunning ? 'bg-primary animate-pulse' : 'bg-text-dark-secondary'}`}></span>
                                    <span className={`text-xs font-bold tracking-widest uppercase ${isTimerRunning ? 'text-primary' : 'text-text-dark-secondary'}`}>
                                        {isTimerRunning ? 'Active' : 'Paused'}
                                    </span>
                                </div>
                            </div>
                        </div>

                        {/* Controls Floating Below */}
                        <div className="absolute -bottom-8 flex gap-4 z-20">
                            <button 
                                onClick={toggleTimer}
                                className={`h-16 px-10 rounded-full font-bold flex items-center gap-3 transition-all shadow-2xl hover:scale-105 active:scale-95 border backdrop-blur-xl ${isTimerRunning ? 'bg-surface-dark border-white/10 text-error hover:bg-error/10' : 'bg-white text-black border-white shadow-[0_0_30px_rgba(255,255,255,0.3)]'}`}
                            >
                                <span className="material-symbols-outlined text-3xl">{isTimerRunning ? 'pause' : 'play_arrow'}</span>
                            </button>
                            <button 
                                onClick={() => { setIsTimerRunning(false); setTimerSeconds(initialSeconds); }}
                                className="size-16 rounded-full bg-surface-dark border border-white/10 flex items-center justify-center text-white hover:bg-white/10 transition-all active:scale-95 shadow-lg backdrop-blur-xl group"
                            >
                                <span className="material-symbols-outlined text-2xl group-hover:rotate-[-180deg] transition-transform duration-500">restart_alt</span>
                            </button>
                        </div>
                    </div>
                ) : (
                     <div className="flex flex-col items-center justify-center gap-6 opacity-100 animate-fade-in">
                        <div className="relative size-48 rounded-full bg-gradient-to-b from-white/5 to-transparent border border-white/5 flex items-center justify-center">
                             <div className="absolute inset-0 rounded-full bg-primary/10 blur-2xl animate-pulse"></div>
                             <div className="size-32 rounded-full border border-white/10 flex items-center justify-center bg-surface-dark/50 backdrop-blur-sm relative z-10 shadow-inner">
                                 <span className="material-symbols-outlined text-6xl text-white/30 drop-shadow-[0_0_10px_rgba(255,255,255,0.2)]">skillet</span>
                             </div>
                             {/* Orbital Particles */}
                             <div className="absolute inset-0 animate-spin duration-[15s] opacity-50">
                                 <div className="absolute top-2 left-1/2 -translate-x-1/2 size-2 bg-white rounded-full shadow-[0_0_10px_rgba(255,255,255,0.8)]"></div>
                             </div>
                             <div className="absolute inset-0 animate-spin duration-[10s] opacity-30 reverse">
                                 <div className="absolute bottom-4 left-1/2 -translate-x-1/2 size-1.5 bg-primary rounded-full"></div>
                             </div>
                        </div>
                        <p className="text-xs font-bold text-text-dark-secondary uppercase tracking-[0.2em]">Manual Step</p>
                   </div>
                )}
            </div>
            
            {isLastStep && (
                <button 
                    onClick={onFinish}
                    className="mt-4 h-16 w-full max-w-xs rounded-full bg-gradient-to-r from-primary to-secondary text-white text-lg font-bold flex items-center justify-center gap-2 shadow-[0_0_30px_rgba(139,92,246,0.3)] hover:scale-105 active:scale-95 transition-all animate-bounce border border-white/20"
                >
                    <span className="material-symbols-outlined">check_circle</span>
                    Finish Cooking
                </button>
            )}
        </main>

        <footer className="flex items-center justify-center gap-10 p-8 pb-12 z-10 mt-auto">
            <button 
                onClick={() => {
                    setCurrentStepIndex(i => Math.max(i - 1, 0));
                    speak("Previous");
                }}
                disabled={currentStepIndex === 0}
                className="size-16 rounded-full glass-strong border border-white/10 text-white flex items-center justify-center disabled:opacity-30 active:scale-95 transition-all hover:bg-white/10 hover:border-white/30"
            >
                <span className="material-symbols-outlined text-3xl">arrow_back</span>
            </button>
             
             <button id="voice-btn-main" className={`size-24 rounded-[36px] bg-surface-dark border border-white/10 text-white flex items-center justify-center relative shadow-2xl transition-transform active:scale-95 hover:border-primary/50 group`}>
                <div className={`absolute inset-0 rounded-[36px] bg-primary/20 blur-xl transition-opacity duration-500 ${isListening ? 'opacity-100' : 'opacity-0'}`}></div>
                <div className={`absolute inset-0 rounded-[36px] border-2 border-primary transition-all duration-500 ${isListening ? 'scale-110 opacity-100' : 'scale-100 opacity-0'}`}></div>
                <span className={`material-symbols-outlined text-4xl relative z-10 transition-all duration-300 ${isListening ? 'text-red-400 scale-110' : 'text-primary group-hover:scale-110'}`}>mic</span>
            </button>
            
             <button 
                onClick={() => {
                    setCurrentStepIndex(i => Math.min(i + 1, recipe.instructions.length - 1));
                    speak("Next");
                }}
                disabled={currentStepIndex === recipe.instructions.length - 1}
                className="size-16 rounded-full glass-strong border border-white/10 text-white flex items-center justify-center disabled:opacity-30 active:scale-95 transition-all hover:bg-white/10 hover:border-white/30"
             >
                <span className="material-symbols-outlined text-3xl">arrow_forward</span>
            </button>
        </footer>
    </div>
  );
};

export default CookingModeScreen;
