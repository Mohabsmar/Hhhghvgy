
import React, { useState } from 'react';
import { SocialPost, Language, AppScreen } from '../types';
import { MOCK_POSTS, getTranslation } from '../constants';

interface CommunityScreenProps {
    onExit: () => void;
    lang: Language;
    onNavigate?: (screen: AppScreen) => void;
}

const CommunityScreen: React.FC<CommunityScreenProps> = ({ onExit, lang, onNavigate }) => {
    const [posts, setPosts] = useState<SocialPost[]>(MOCK_POSTS);
    const [activeTab, setActiveTab] = useState<'Following' | 'Trending'>('Trending');
    const t = (key: any) => getTranslation(lang, key);

    const handleLike = (postId: string) => {
        setPosts(prev => prev.map(p => {
            if (p.id === postId) {
                return { 
                    ...p, 
                    likes: p.isLiked ? p.likes - 1 : p.likes + 1,
                    isLiked: !p.isLiked 
                };
            }
            return p;
        }));
    };

    const PostCard: React.FC<{post: SocialPost}> = ({ post }) => (
        <div className="liquid-panel rounded-[32px] overflow-hidden border border-white/5 mb-6 animate-slide-up shadow-lg">
            <div className="flex items-center justify-between p-4">
                <button onClick={() => onNavigate && onNavigate('chefProfile')} className="flex items-center gap-3 group">
                    <img src={post.userAvatar} alt={post.userName} className="size-10 rounded-full border border-white/10 object-cover group-hover:border-primary transition-colors" />
                    <div className="text-left">
                        <h4 className="text-sm font-bold text-white leading-tight group-hover:text-primary transition-colors">{post.userName}</h4>
                        <p className="text-[10px] text-text-dark-secondary font-medium">{post.timestamp} • Gourmet</p>
                    </div>
                </button>
                <button className="text-white/40 hover:text-white transition-colors"><span className="material-symbols-outlined">more_horiz</span></button>
            </div>

            <div className="relative aspect-square w-full bg-black/20">
                <img src={post.imageUrl} alt="Post" className="w-full h-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-60"></div>
                <div className="absolute bottom-4 left-4 right-4">
                    <p className="text-white text-sm font-medium line-clamp-2 drop-shadow-md">{post.caption}</p>
                </div>
            </div>

            <div className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <button onClick={() => handleLike(post.id)} className="flex items-center gap-1.5 group">
                        <span className={`material-symbols-outlined text-2xl transition-all ${post.isLiked ? 'text-emerald-500 fill-current' : 'text-white group-hover:text-emerald-400'}`} style={{fontVariationSettings: `'FILL' ${post.isLiked ? 1 : 0}`}}>favorite</span>
                        <span className="text-sm font-bold text-white">{post.likes}</span>
                    </button>
                    <button className="flex items-center gap-1.5 group">
                        <span className="material-symbols-outlined text-2xl text-white group-hover:text-primary">chat_bubble</span>
                        <span className="text-sm font-bold text-white">{post.comments.length}</span>
                    </button>
                </div>
                <button className="text-white hover:text-primary">
                    <span className="material-symbols-outlined text-2xl">bookmark</span>
                </button>
            </div>
        </div>
    );

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 border-b border-white/5 rounded-b-[40px]">
                <div className="flex items-center justify-between mb-6 pt-4">
                    <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                    <h1 className="text-xl font-black text-white tracking-widest uppercase">Atelier Social</h1>
                    <div className="size-10"></div>
                </div>
                <div className="flex justify-center gap-8">
                    {['Trending', 'Following'].map(tab => (
                        <button key={tab} onClick={() => setActiveTab(tab as any)} className={`pb-2 text-xs font-black uppercase tracking-widest transition-all relative ${activeTab === tab ? 'text-primary' : 'text-white/30'}`}>
                            {tab}
                            {activeTab === tab && <div className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-primary rounded-full shadow-[0_0_10px_#10B981]"></div>}
                        </button>
                    ))}
                </div>
            </header>

            <main className="flex-1 overflow-y-auto p-4 pb-32 no-scrollbar">
                <div className="max-w-lg mx-auto">
                    {/* Story Ring Section - FIXED SWIPING */}
                    <div 
                        className="snap-carousel no-scrollbar mb-8 px-2 gap-5" 
                        data-scrollable="true"
                    >
                        <div onClick={() => onNavigate && onNavigate('createPost')} className="flex flex-col items-center gap-2 cursor-pointer snap-start">
                            <div className="size-16 rounded-full border-2 border-dashed border-primary/40 flex items-center justify-center bg-primary/5 hover:bg-primary/10 transition-colors">
                                <span className="material-symbols-outlined text-primary">add</span>
                            </div>
                            <span className="text-[8px] text-primary font-black uppercase tracking-widest">Share</span>
                        </div>
                        {[1,2,3,4,5,6,7].map(i => (
                            <div key={i} className="flex flex-col items-center gap-2 cursor-pointer snap-start" onClick={() => onNavigate && onNavigate('chefProfile')}>
                                <div className="size-16 rounded-full p-[2px] bg-gradient-to-tr from-emerald-400 to-emerald-900 shadow-lg">
                                    <img src={`https://i.pravatar.cc/150?img=${10+i}`} className="w-full h-full rounded-full border-2 border-black object-cover" />
                                </div>
                                <span className="text-[8px] text-white/40 font-black uppercase tracking-widest">Chef {i}</span>
                            </div>
                        ))}
                    </div>

                    {posts.map(post => <PostCard key={post.id} post={post} />)}
                </div>
            </main>

            <div className="absolute bottom-8 right-6 z-40 safe-area-bottom">
                <button onClick={() => onNavigate && onNavigate('createPost')} className="size-16 rounded-full bg-primary text-black shadow-2xl flex items-center justify-center hover:scale-110 active:scale-95 transition-all border border-white/20">
                    <span className="material-symbols-outlined text-3xl font-black">add_a_photo</span>
                </button>
            </div>
        </div>
    );
};

export default CommunityScreen;
