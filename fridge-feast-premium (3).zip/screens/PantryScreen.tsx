
import React, { useState, useEffect } from 'react';
import { PantryItem, Language } from '../types';
import { getTranslation } from '../constants';
import { db } from '../common/dbService';
import Spinner from '../components/common/Spinner';

interface PantryScreenProps {
    onExit: () => void;
    lang: Language;
}

const PantryScreen: React.FC<PantryScreenProps> = ({ onExit, lang }) => {
    const [items, setItems] = useState<PantryItem[]>([]);
    const [activeTab, setActiveTab] = useState<'All' | 'Fridge' | 'Freezer' | 'Pantry'>('All');
    const [searchQuery, setSearchQuery] = useState('');
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [loading, setLoading] = useState(true);
    
    // Form State
    const [newItemName, setNewName] = useState('');
    const [newItemQty, setNewQty] = useState(1);
    const [newItemUnit, setNewUnit] = useState('pcs');
    const [newItemLoc, setNewLoc] = useState<'Fridge' | 'Freezer' | 'Pantry'>('Fridge');
    const [newItemExpiry, setNewExpiry] = useState('');

    const t = (key: any) => getTranslation(lang, key);

    useEffect(() => {
        const fetch = async () => {
            const data = await db.getAllPantry();
            setItems(data);
            setLoading(false);
        };
        fetch();
    }, []);

    const handleAddItem = async () => {
        if (!newItemName) return;
        const newItem: PantryItem = {
            id: Date.now().toString(),
            name: newItemName,
            quantity: newItemQty,
            unit: newItemUnit,
            expiryDate: newItemExpiry,
            addedDate: new Date().toISOString(),
            location: newItemLoc,
            category: 'General',
            isStaple: false
        };
        await db.updatePantryItem(newItem);
        setItems([newItem, ...items]);
        setIsAddModalOpen(false);
        resetForm();
    };

    const resetForm = () => {
        setNewName(''); setNewQty(1); setNewUnit('pcs'); setNewExpiry('');
    };

    const handleDelete = async (id: string) => {
        await db.deletePantryItem(id);
        setItems(items.filter(i => i.id !== id));
    };

    const handleAdjustQty = async (id: string, delta: number) => {
        const item = items.find(i => i.id === id);
        if (item) {
            const updated = { ...item, quantity: Math.max(0, item.quantity + delta) };
            await db.updatePantryItem(updated);
            setItems(items.map(i => i.id === id ? updated : i));
        }
    };

    const filtered = items.filter(i => {
        const matchesTab = activeTab === 'All' || i.location === activeTab;
        const matchesSearch = i.name.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesTab && matchesSearch;
    });

    return (
        <div className="fixed inset-0 bg-black z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-6 liquid-glass sticky top-0 z-30 border-b border-white/5 rounded-b-[48px]">
                <div className="flex items-center justify-between mb-8 pt-4">
                    <button onClick={onExit} className="size-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white active:scale-90 transition-transform">
                        <span className="material-symbols-outlined">arrow_back</span>
                    </button>
                    <div className="text-center">
                        <h1 className="text-xl font-black text-white">Virtual Pantry</h1>
                        <p className="text-[10px] text-primary font-bold uppercase tracking-widest">Inventory Asset Control</p>
                    </div>
                    <button onClick={() => setIsAddModalOpen(true)} className="size-12 rounded-full bg-primary text-black border border-primary flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.4)] active:scale-90 transition-all">
                        <span className="material-symbols-outlined text-2xl font-bold">add</span>
                    </button>
                </div>
                
                <div className="space-y-6">
                    <div className="relative group">
                        <div className="absolute inset-0 bg-primary/10 blur-xl opacity-0 group-focus-within:opacity-100 transition-opacity"></div>
                        <span className="material-symbols-outlined absolute left-5 top-1/2 -translate-y-1/2 text-white/30">search</span>
                        <input 
                            type="text" 
                            placeholder="Locate ingredient..." 
                            value={searchQuery}
                            onChange={e => setSearchQuery(e.target.value)}
                            className="w-full h-14 bg-white/5 rounded-[24px] pl-14 pr-6 text-white text-[15px] font-bold border border-white/10 focus:border-primary/40 focus:ring-0 transition-all relative z-10"
                        />
                    </div>
                    <div className="flex p-1 bg-white/5 rounded-[22px] border border-white/5 overflow-x-auto no-scrollbar">
                        {['All', 'Fridge', 'Freezer', 'Pantry'].map(tab => (
                            <button 
                                key={tab}
                                onClick={() => setActiveTab(tab as any)}
                                className={`flex-1 py-3 min-w-[80px] rounded-[18px] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === tab ? 'bg-primary text-black shadow-lg' : 'text-white/40 hover:text-white'}`}
                            >
                                {tab}
                            </button>
                        ))}
                    </div>
                </div>
            </header>

            <main className="flex-1 overflow-y-auto p-6 space-y-4 pb-32 no-scrollbar">
                {loading ? (
                    <div className="flex flex-col items-center justify-center py-20">
                        <Spinner className="size-10 text-primary mb-4" />
                        <p className="text-white/20 font-black uppercase tracking-[0.2em] text-[10px]">Loading Vault...</p>
                    </div>
                ) : filtered.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-24 opacity-20">
                        <span className="material-symbols-outlined text-8xl mb-4">shelves</span>
                        <p className="text-white font-black uppercase tracking-widest text-sm">Larder Empty</p>
                    </div>
                ) : (
                    filtered.map(item => (
                        <div key={item.id} className="liquid-panel p-6 rounded-[36px] border border-white/5 flex items-center gap-5 group hover:border-primary/30 transition-colors animate-slide-up">
                            <div className="size-14 rounded-2xl bg-white/5 flex items-center justify-center text-primary border border-white/5 shadow-inner">
                                <span className="material-symbols-outlined text-3xl">restaurant</span>
                            </div>
                            <div className="flex-1 min-w-0">
                                <h3 className="font-black text-white text-lg truncate leading-tight">{item.name}</h3>
                                <div className="flex items-center gap-3 text-[10px] font-bold text-white/40 mt-1.5 uppercase tracking-widest">
                                    <span className="flex items-center gap-1"><span className="size-1.5 rounded-full bg-primary/50"></span>{item.location}</span>
                                    {item.expiryDate && <span className="text-orange-400">Exp: {item.expiryDate}</span>}
                                </div>
                            </div>
                            
                            <div className="flex items-center gap-3 bg-black/40 rounded-[22px] p-1.5 border border-white/5">
                                <button onClick={() => handleAdjustQty(item.id, -1)} className="size-9 rounded-full flex items-center justify-center text-white hover:bg-white/10 active:scale-90 transition-all">
                                    <span className="material-symbols-outlined">remove</span>
                                </button>
                                <span className="text-sm font-black text-white min-w-[30px] text-center">{item.quantity}</span>
                                <button onClick={() => handleAdjustQty(item.id, 1)} className="size-9 rounded-full flex items-center justify-center text-white hover:bg-white/10 active:scale-90 transition-all">
                                    <span className="material-symbols-outlined">add</span>
                                </button>
                            </div>

                            <button onClick={() => handleDelete(item.id)} className="size-10 rounded-full bg-red-500/10 flex items-center justify-center text-red-500 hover:bg-red-500 hover:text-black transition-all">
                                <span className="material-symbols-outlined text-xl">delete</span>
                            </button>
                        </div>
                    ))
                )}
            </main>

            {/* Premium Add Modal */}
            {isAddModalOpen && (
                <div className="fixed inset-0 bg-black/90 backdrop-blur-xl z-[60] flex items-end sm:items-center justify-center p-6 animate-fade-in" onClick={() => setIsAddModalOpen(false)}>
                    <div className="liquid-glass w-full max-w-md rounded-[56px] p-8 animate-slide-up border border-white/10 shadow-2xl space-y-8" onClick={e => e.stopPropagation()}>
                        <div className="flex justify-between items-center">
                            <div>
                                <h2 className="text-3xl font-black text-white tracking-tighter">New Asset</h2>
                                <p className="text-[10px] text-primary font-bold uppercase tracking-widest mt-1">Ingest into Inventory</p>
                            </div>
                            <button onClick={() => setIsAddModalOpen(false)} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white hover:bg-white/10"><span className="material-symbols-outlined">close</span></button>
                        </div>

                        <div className="space-y-6">
                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-4">Label</label>
                                <input className="w-full h-14 bg-white/5 rounded-[24px] px-6 text-white font-bold border border-white/10 focus:border-primary/50 transition-all" placeholder="e.g. A5 Wagyu" value={newItemName} onChange={e => setNewName(e.target.value)} />
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-4">Qty</label>
                                    <input type="number" className="w-full h-14 bg-white/5 rounded-[24px] px-6 text-white font-bold border border-white/10 focus:border-primary/50 transition-all text-center" value={newItemQty} onChange={e => setNewQty(Number(e.target.value))} />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-4">Unit</label>
                                    <select className="w-full h-14 bg-white/5 rounded-[24px] px-6 text-white font-bold border border-white/10 focus:border-primary/50 transition-all" value={newItemUnit} onChange={e => setNewUnit(e.target.value)}>
                                        <option value="pcs">pcs</option><option value="kg">kg</option><option value="g">g</option><option value="L">L</option><option value="ml">ml</option>
                                    </select>
                                </div>
                            </div>

                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-4">Store</label>
                                <div className="flex bg-white/5 p-1 rounded-[24px] border border-white/5">
                                    {['Fridge', 'Freezer', 'Pantry'].map(loc => (
                                        <button key={loc} onClick={() => setNewLoc(loc as any)} className={`flex-1 py-3 rounded-[20px] text-[10px] font-black uppercase tracking-widest transition-all ${newItemLoc === loc ? 'bg-primary text-black shadow-lg' : 'text-white/40 hover:text-white'}`}>{loc}</button>
                                    ))}
                                </div>
                            </div>

                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-4">Best Before</label>
                                <input type="date" className="w-full h-14 bg-white/5 rounded-[24px] px-6 text-white font-bold border border-white/10 focus:border-primary/50 transition-all" value={newItemExpiry} onChange={e => setNewExpiry(e.target.value)} />
                            </div>
                        </div>

                        <button onClick={handleAddItem} className="w-full h-16 bg-primary rounded-[28px] text-black font-black text-lg shadow-2xl shadow-primary/30 active:scale-95 transition-all uppercase tracking-widest">Commit to Vault</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default PantryScreen;
