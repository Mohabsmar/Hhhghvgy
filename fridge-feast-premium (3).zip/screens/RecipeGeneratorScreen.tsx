import React, { useState, useRef, useCallback, useEffect } from 'react';
import { generateRecipesFromIngredients } from '../common/geminiService';
import { Recipe, Filters, IngredientItem } from '../types';
import IngredientChip from '../components/common/IngredientChip';
import RecipeCard from '../components/common/recipe_generator/RecipeCard';
import GenerationLoader from '../components/common/recipe_generator/GenerationLoader';
import Spinner from '../components/common/Spinner';
import FilterModal from '../components/FilterModal';

interface RecipeGeneratorScreenProps {
    onExit: () => void;
    onSelectRecipe: (recipe: Recipe) => void;
    savedRecipes: Recipe[];
    onToggleSave: (recipe: Recipe) => void;
}

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = SpeechRecognition ? new SpeechRecognition() : null;
if (recognition) {
    recognition.continuous = false;
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
}

const RecipeGeneratorScreen: React.FC<RecipeGeneratorScreenProps> = ({ onExit, onSelectRecipe, savedRecipes, onToggleSave }) => {
  const [ingredients, setIngredients] = useState<IngredientItem[]>([
      { id: '1', name: 'Chicken Breast' },
      { id: '2', name: 'Broccoli' }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [filters, setFilters] = useState<Filters>({
    dietary: [],
    cuisine: [],
    difficulty: [],
    time: '',
  });
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  
  const inputRef = useRef<HTMLInputElement>(null);

  const handleAddIngredient = useCallback(() => {
    const newIngredientNames = inputValue.split(',').map(s => s.trim()).filter(Boolean);
    if (newIngredientNames.length > 0) {
        setIngredients(prev => {
             const newItems: IngredientItem[] = newIngredientNames.map(name => ({
                 id: `${name}-${Date.now()}-${Math.random()}`,
                 name: name
             }));
             const combined = [...prev, ...newItems];
             const unique = Array.from(new Set(combined.map(i => i.name.toLowerCase()))).map(lower => combined.find(i => i.name.toLowerCase() === lower)!);
             return unique;
        });
        setInputValue('');
    }
  }, [inputValue]);

  const handleRemoveIngredient = useCallback((id: string) => {
    setIngredients(prev => prev.filter(ing => ing.id !== id));
  }, []);

  const handleGenerateRecipes = async () => {
    if (ingredients.length === 0) {
      setError("Please add at least one ingredient to get started.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setRecipes([]);

    try {
      const ingredientNames = ingredients.map(i => i.name);
      const generatedRecipes = await generateRecipesFromIngredients(ingredientNames, filters);
      setRecipes(generatedRecipes);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleVoiceInput = () => {
    if (!recognition) {
        alert("Speech recognition is not supported in your browser.");
        return;
    }
    if (isListening) {
        recognition.stop();
        setIsListening(false);
    } else {
        recognition.start();
        setIsListening(true);
    }
  };

  useEffect(() => {
    if (!recognition) return;

    recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        const newIngredientNames = transcript.split(/,| and /).map((item: string) => item.trim()).filter(Boolean);
        setIngredients(prev => {
            const newItems: IngredientItem[] = newIngredientNames.map((name: string) => ({
                 id: `${name}-${Date.now()}-${Math.random()}`,
                 name: name
             }));
            const combined = [...prev, ...newItems];
            const unique = Array.from(new Set(combined.map(i => i.name.toLowerCase()))).map(lower => combined.find(i => i.name.toLowerCase() === lower)!);
            return unique;
        });
    };
    recognition.onerror = (event: any) => {
        console.error("Speech recognition error:", event.error);
        setIsListening(false);
    };
    recognition.onend = () => setIsListening(false);
  }, []);

  const isRecipeSaved = (recipeId: string) => savedRecipes.some(r => r.id === recipeId);
  const activeFilterCount = filters.dietary.length + filters.cuisine.length + filters.difficulty.length + (filters.time ? 1 : 0);

  return (
    <>
    <div className="fixed inset-0 bg-background-dark z-40 flex flex-col animate-slide-up">
      <header className="flex items-center p-4 justify-between flex-shrink-0">
        <button onClick={onExit} className="flex size-9 items-center justify-center rounded-full hover:bg-white/5 transition-colors">
            <span className="material-symbols-outlined">arrow_back</span>
        </button>
        <h1 className="text-text-dark text-xl font-bold">
         AI Recipe Generator
        </h1>
        <div className="w-9"/>
      </header>

      <main className="flex-1 px-4 space-y-6 overflow-y-auto no-scrollbar pb-28">
        <div className="bg-surface-dark border border-border-dark p-4 rounded-2xl space-y-3">
          <div className="flex justify-between items-center">
              <h2 className="font-bold text-text-dark">What's in your fridge?</h2>
              <button onClick={() => setIsFilterModalOpen(true)} className="relative flex items-center justify-center h-8 px-3 rounded-full bg-primary/20 text-primary text-sm font-semibold">
                  <span className="material-symbols-outlined text-lg mr-1.5">filter_list</span>
                  Filters
                  {activeFilterCount > 0 && <span className="absolute -top-1 -right-1 flex size-4 items-center justify-center rounded-full bg-secondary text-white text-xs font-bold">{activeFilterCount}</span>}
              </button>
          </div>
          <div className="relative w-full">
              <input
                ref={inputRef}
                className="form-input w-full rounded-lg text-text-dark focus:outline-0 focus:ring-2 focus:ring-primary border-none bg-surface-dark-secondary h-12 placeholder:text-text-dark-secondary/80 px-4 pr-24 text-base"
                placeholder="Add ingredients..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddIngredient()}
              />
              <div className="absolute inset-y-0 right-0 flex items-center">
                  {recognition && (
                    <button onClick={handleVoiceInput} className={`text-primary flex items-center justify-center h-full px-3 hover:text-primary-300 transition-colors ${isListening ? 'text-red-400' : ''}`}>
                      <span className={`material-symbols-outlined text-2xl ${isListening ? 'animate-pulse' : ''}`}>{isListening ? 'mic' : 'mic_none'}</span>
                    </button>
                  )}
                  <button onClick={handleAddIngredient} className="text-primary flex items-center justify-center h-full px-3 rounded-r-lg hover:text-primary-300 transition-colors">
                    <span className="material-symbols-outlined text-2xl">add_circle</span>
                  </button>
              </div>
          </div>
          <div className="flex flex-wrap gap-2 pt-1">
            {ingredients.map(ing => (
              <IngredientChip key={ing.id} ingredient={ing} onRemove={handleRemoveIngredient} />
            ))}
          </div>
        </div>
      
        <div className="w-full space-y-4">
          {isLoading && <GenerationLoader />}
          {error && (
              <div className="text-center p-8 bg-surface-dark rounded-2xl">
                  <span className="material-symbols-outlined text-5xl text-error mb-4">error</span>
                  <h3 className="text-lg font-semibold text-text-dark mb-2">Oops! Something went wrong.</h3>
                  <p className="text-text-dark-secondary">{error}</p>
              </div>
          )}
          {recipes.length > 0 && (
            <div>
              <h2 className="text-xl font-bold text-text-dark mb-4">Recommended For You</h2>
              <div className="grid grid-cols-1 gap-4">
                {recipes.map((recipe) => (
                  <RecipeCard 
                      key={recipe.id} 
                      recipe={recipe}
                      onSelect={() => onSelectRecipe(recipe)}
                      isSaved={isRecipeSaved(recipe.id)}
                      onToggleSave={onToggleSave}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-background-dark via-background-dark to-transparent z-20 pointer-events-none">
            <div className="max-w-md mx-auto pointer-events-auto">
                <button 
                    onClick={handleGenerateRecipes}
                    disabled={isLoading || ingredients.length === 0}
                    className="w-full h-14 rounded-full bg-primary text-white text-lg font-bold flex items-center justify-center gap-2 shadow-lg shadow-primary/20 hover:bg-primary-600 transition-all duration-300 disabled:bg-primary/50 disabled:cursor-not-allowed transform active:scale-95"
                >
                    {isLoading ? <Spinner /> : <><span className="material-symbols-outlined">auto_awesome</span><span>Generate Recipes</span></>}
                </button>
            </div>
      </div>
    </div>
    <FilterModal 
        isOpen={isFilterModalOpen}
        onClose={() => setIsFilterModalOpen(false)}
        filters={filters}
        setFilters={setFilters}
    />
    </>
  );
};

export default RecipeGeneratorScreen;