import React, { useState } from 'react';
import { askCulinaryExpert } from '../common/geminiService';
import Spinner from '../components/common/Spinner';

const SpiceBlenderScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [input, setInput] = useState('');
    const [result, setResult] = useState('');
    const [loading, setLoading] = useState(false);

    const handleBlend = async () => {
        setLoading(true);
        const res = await askCulinaryExpert('Spice Master', `Create a custom spice blend recipe for: ${input}. Include ratios and usage tips.`);
        setResult(res);
        setLoading(false);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Spice Blender</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6">
                <div className="text-center py-6">
                    <span className="material-symbols-outlined text-6xl text-red-400 mb-4">grain</span>
                    <h2 className="text-2xl font-bold text-white">Custom Rubs & Mixes</h2>
                    <p className="text-text-dark-secondary">What are you cooking?</p>
                </div>
                <input value={input} onChange={e => setInput(e.target.value)} placeholder="e.g. Grilled Salmon, Taco Meat" className="w-full h-14 bg-white/5 rounded-full px-6 text-white border border-white/10 text-center text-lg focus:border-red-500" />
                <button onClick={handleBlend} disabled={loading} className="w-full h-14 bg-red-600 rounded-full text-white font-bold text-lg shadow-lg shadow-red-600/20">{loading ? <Spinner /> : 'Generate Blend'}</button>
                {result && <div className="liquid-panel p-6 rounded-[32px] border border-white/5 text-white leading-relaxed whitespace-pre-wrap">{result}</div>}
            </main>
        </div>
    );
};
export default SpiceBlenderScreen;