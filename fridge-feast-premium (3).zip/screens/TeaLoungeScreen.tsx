
import React, { useState, useEffect } from 'react';

const TEAS = [
    { name: 'Green', temp: '80°C', time: 180 },
    { name: 'Black', temp: '100°C', time: 240 },
    { name: 'White', temp: '75°C', time: 150 },
    { name: 'Oolong', temp: '90°C', time: 210 },
    { name: 'Herbal', temp: '100°C', time: 300 },
];

const TeaLoungeScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [selectedTea, setSelectedTea] = useState<any>(null);
    const [timer, setTimer] = useState(0);
    const [isRunning, setIsRunning] = useState(false);

    useEffect(() => {
        let interval: any;
        if (isRunning && timer > 0) interval = setInterval(() => setTimer(t => t - 1), 1000);
        else if (timer === 0) setIsRunning(false);
        return () => clearInterval(interval);
    }, [isRunning, timer]);

    const startBrew = (tea: any) => {
        setSelectedTea(tea);
        setTimer(tea.time);
        setIsRunning(true);
    };

    const formatTime = (s: number) => `${Math.floor(s/60)}:${(s%60).toString().padStart(2,'0')}`;

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Tea Lounge</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-6 overflow-y-auto">
                {selectedTea && (
                    <div className="liquid-panel p-8 rounded-[40px] text-center border border-green-500/20 mb-6">
                        <h2 className="text-2xl font-bold text-white mb-1">{selectedTea.name} Tea</h2>
                        <p className="text-green-400 font-bold mb-6">{selectedTea.temp}</p>
                        <div className="text-7xl font-mono font-black text-white mb-6">{formatTime(timer)}</div>
                        <button onClick={() => setIsRunning(!isRunning)} className="px-8 py-3 rounded-full bg-green-500 text-black font-bold">
                            {isRunning ? 'Pause' : 'Resume'}
                        </button>
                    </div>
                )}
                
                <h3 className="text-white font-bold px-2">Select a Blend</h3>
                <div className="grid grid-cols-2 gap-4">
                    {TEAS.map(tea => (
                        <button key={tea.name} onClick={() => startBrew(tea)} className="p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 text-left transition-colors">
                            <span className="material-symbols-outlined text-green-300 mb-2">emoji_food_beverage</span>
                            <h4 className="font-bold text-white">{tea.name}</h4>
                            <div className="flex justify-between mt-2 text-xs text-text-dark-secondary">
                                <span>{tea.temp}</span>
                                <span>{Math.floor(tea.time/60)} min</span>
                            </div>
                        </button>
                    ))}
                </div>
            </main>
        </div>
    );
};
export default TeaLoungeScreen;
