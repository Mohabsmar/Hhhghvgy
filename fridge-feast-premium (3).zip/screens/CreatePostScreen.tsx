
import React, { useState, useRef } from 'react';
import { Language } from '../types';
import { getTranslation } from '../constants';

interface CreatePostScreenProps {
    onExit: () => void;
    lang: Language;
}

const CreatePostScreen: React.FC<CreatePostScreenProps> = ({ onExit, lang }) => {
    const [image, setImage] = useState<string | null>(null);
    const [caption, setCaption] = useState('');
    const [isSharing, setIsSharing] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const t = (key: any) => getTranslation(lang, key);

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setImage(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const handlePost = () => {
        setIsSharing(true);
        setTimeout(() => {
            setIsSharing(false);
            onExit();
        }, 1500);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 border-b border-white/5 flex justify-between items-center">
                <button onClick={onExit} className="text-white font-bold text-sm">Cancel</button>
                <h1 className="text-lg font-black text-white">{t('createPost')}</h1>
                <button 
                    onClick={handlePost} 
                    disabled={!image || isSharing}
                    className="bg-primary text-white px-5 py-2 rounded-full text-xs font-bold disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-primary/20"
                >
                    {isSharing ? 'Posting...' : t('post')}
                </button>
            </header>

            <main className="flex-1 overflow-y-auto p-6 space-y-6">
                
                {/* Image Uploader */}
                <div 
                    onClick={() => fileInputRef.current?.click()}
                    className={`aspect-square w-full rounded-[40px] border-2 border-dashed border-white/10 flex flex-col items-center justify-center cursor-pointer transition-all hover:bg-white/5 relative overflow-hidden group ${image ? 'border-none' : ''}`}
                >
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileSelect} />
                    
                    {image ? (
                        <>
                            <img src={image} className="w-full h-full object-cover" />
                            <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <span className="px-6 py-3 bg-white/20 backdrop-blur-md rounded-full text-white font-bold text-sm border border-white/20">Change Photo</span>
                            </div>
                        </>
                    ) : (
                        <div className="text-center space-y-4">
                            <div className="size-20 rounded-full bg-white/5 flex items-center justify-center mx-auto border border-white/5 group-hover:scale-110 transition-transform">
                                <span className="material-symbols-outlined text-4xl text-primary">add_a_photo</span>
                            </div>
                            <p className="text-text-dark-secondary font-medium">Tap to upload your dish</p>
                        </div>
                    )}
                </div>

                {/* Caption Input */}
                <div className="bg-surface-dark border border-white/5 rounded-[32px] p-2">
                    <textarea 
                        className="w-full bg-transparent border-none text-white placeholder:text-text-dark-secondary p-4 h-32 resize-none focus:ring-0 text-[16px]"
                        placeholder={t('captionPlaceholder')}
                        value={caption}
                        onChange={(e) => setCaption(e.target.value)}
                    ></textarea>
                    
                    <div className="flex gap-2 p-2 overflow-x-auto no-scrollbar">
                        <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 text-text-dark-secondary hover:text-white transition-colors text-xs font-bold border border-white/5">
                            <span className="material-symbols-outlined text-base">tag</span>
                            Add Tags
                        </button>
                        <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 text-text-dark-secondary hover:text-white transition-colors text-xs font-bold border border-white/5">
                            <span className="material-symbols-outlined text-base">location_on</span>
                            {t('location')}
                        </button>
                        <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 text-text-dark-secondary hover:text-white transition-colors text-xs font-bold border border-white/5">
                            <span className="material-symbols-outlined text-base">menu_book</span>
                            {t('tagRecipe')}
                        </button>
                    </div>
                </div>

                {/* Guidelines Tip */}
                <div className="p-4 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex gap-4">
                    <span className="material-symbols-outlined text-blue-400">tips_and_updates</span>
                    <div>
                        <h4 className="text-white font-bold text-sm">Pro Tip</h4>
                        <p className="text-text-dark-secondary text-xs mt-1">Photos with natural lighting get 40% more engagement. Try placing your dish near a window!</p>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default CreatePostScreen;
