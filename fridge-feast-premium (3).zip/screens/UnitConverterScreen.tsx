
import React, { useState } from 'react';
import { Language } from '../types';

const UNITS = {
    mass: ['g', 'kg', 'oz', 'lb'],
    volume: ['ml', 'l', 'cup', 'tbsp', 'tsp', 'fl oz'],
    temperature: ['C', 'F'],
    length: ['cm', 'in', 'm', 'ft']
};

const RATES: any = {
    mass: { g: 1, kg: 1000, oz: 28.3495, lb: 453.592 },
    volume: { ml: 1, l: 1000, cup: 236.588, tbsp: 14.787, tsp: 4.929, 'fl oz': 29.5735 },
    length: { cm: 1, m: 100, in: 2.54, ft: 30.48 }
};

const UnitConverterScreen: React.FC<{onExit: () => void}> = ({onExit}) => {
    const [category, setCategory] = useState<'mass' | 'volume' | 'temperature' | 'length'>('mass');
    const [amount, setAmount] = useState<string>('1');
    const [fromUnit, setFromUnit] = useState(UNITS.mass[0]);
    const [toUnit, setToUnit] = useState(UNITS.mass[1]);

    const convert = () => {
        const val = parseFloat(amount);
        if (isNaN(val)) return '---';
        if (category === 'temperature') {
            if (fromUnit === 'C' && toUnit === 'F') return ((val * 9/5) + 32).toFixed(1);
            if (fromUnit === 'F' && toUnit === 'C') return ((val - 32) * 5/9).toFixed(1);
            return val.toFixed(1);
        }
        const base = val * RATES[category][fromUnit];
        const result = base / RATES[category][toUnit];
        return result.toFixed(2);
    };

    const handleCategoryChange = (c: any) => {
        setCategory(c);
        setFromUnit(UNITS[c as keyof typeof UNITS][0]);
        setToUnit(UNITS[c as keyof typeof UNITS][1]);
    };

    return (
        <div className="fixed inset-0 bg-background-dark z-50 flex flex-col font-display animate-slide-up">
            <header className="px-6 pt-safe-top pb-4 liquid-glass sticky top-0 z-30 flex justify-between items-center border-b border-white/5">
                <button onClick={onExit} className="size-10 rounded-full bg-white/5 flex items-center justify-center text-white"><span className="material-symbols-outlined">arrow_back</span></button>
                <h1 className="text-xl font-black text-white">Unit Converter</h1>
                <div className="size-10"></div>
            </header>
            <main className="flex-1 p-6 space-y-8">
                <div className="flex bg-white/5 p-1 rounded-2xl border border-white/5">
                    {Object.keys(UNITS).map(c => (
                        <button key={c} onClick={() => handleCategoryChange(c)} className={`flex-1 py-3 rounded-xl text-xs font-bold capitalize transition-all ${category === c ? 'bg-primary text-white shadow-lg' : 'text-white/50 hover:text-white'}`}>{c}</button>
                    ))}
                </div>
                
                <div className="liquid-panel p-8 rounded-[40px] border border-white/5 space-y-8">
                    <div className="flex flex-col items-center">
                        <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="bg-transparent text-6xl font-black text-white text-center w-full focus:outline-none placeholder:text-white/20" />
                        <div className="flex items-center gap-4 mt-4">
                            <select value={fromUnit} onChange={e => setFromUnit(e.target.value)} className="bg-white/10 text-white rounded-xl px-4 py-2 border-none font-bold text-lg focus:ring-primary">
                                {UNITS[category].map(u => <option key={u} value={u} className="text-black">{u}</option>)}
                            </select>
                            <span className="material-symbols-outlined text-white/50">arrow_forward</span>
                            <select value={toUnit} onChange={e => setToUnit(e.target.value)} className="bg-white/10 text-white rounded-xl px-4 py-2 border-none font-bold text-lg focus:ring-primary">
                                {UNITS[category].map(u => <option key={u} value={u} className="text-black">{u}</option>)}
                            </select>
                        </div>
                    </div>
                    
                    <div className="h-px bg-white/10"></div>
                    
                    <div className="text-center">
                        <p className="text-text-dark-secondary font-bold uppercase tracking-widest text-sm mb-2">Result</p>
                        <p className="text-5xl font-black text-primary">{convert()} <span className="text-2xl text-white/50">{toUnit}</span></p>
                    </div>
                </div>
            </main>
        </div>
    );
};
export default UnitConverterScreen;
