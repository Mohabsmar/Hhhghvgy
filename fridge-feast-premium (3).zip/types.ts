export type Language = 'en' | 'tr' | 'ar' | 'zh' | 'de' | 'ru' | 'es' | 'fr' | 'it' | 'ja';

export interface NavBarConfig {
  style: 'floating' | 'fixed';
  width: number;
  height: number;
  borderRadius: number;
  bottomOffset: number;
  horizontalOffset: number;
  backgroundColor: string;
  iconColor: string;
  activeIconColor: string;
  showLabels: boolean;
  blurEffect: boolean;
  borderColor: string;
  borderWidth: number;
  backgroundOpacity: number;
  containerPosition: 'left' | 'center' | 'right';
  verticalPosition: 'top' | 'bottom';
}

export type QuickAccessId = 'scanner' | 'chat' | 'shopping' | 'favorites' | 'planner' | 'stores' | 'settings' | 'pantry' | 'community' | 'analytics' | 'gamification' | 'timers' | 'converter' | 'wine' | 'cocktails' | 'coffee' | 'seasonal' | 'substitutions' | 'school' | 'dictionary' | 'leftovers' | 'taste' | 'fermentation' | 'party' | 'family' | 'labs';

export interface UserPreferences {
  dietary: string[];
  cuisine: string[];
  difficulty: 'Easy' | 'Medium' | 'Hard';
  notifications: boolean;
  language: Language;
  nutritionDisplay: 'percentage' | 'numbers';
  nutritionUnit: 'weight' | 'calories';
  nutritionChartType: 'donut' | 'bar'; 
  quickAccess: QuickAccessId[];
  navBar: NavBarConfig;
  dataSaver: boolean;
  incognito: boolean;
  themeMode: 'system' | 'dark' | 'light';
}

export interface User {
  name: string;
  email: string;
  photoUrl: string;
  preferences: UserPreferences;
  xp: number;
  level: number;
  rank: string;
  badges: string[];
  stats: UserStats;
}

export interface UserStats {
    recipesCooked: number;
    streakDays: number;
    moneySaved: number;
    wasteReduced: number;
    cuisinesExplored: string[];
    totalCaloriesCooked: number;
    weeklyActivity: number[];
}

export interface Recipe {
  id: string;
  recipeName: string;
  description: string;
  prepTime: string;
  cookTime: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  ingredients: { amount: string; name: string }[];
  instructions: string[];
  imageUrl?: string;
  servings: number;
  origin?: string;
  history?: string;
  calorieBreakdown?: string;
}

// Added missing ShoppingListItem interface
export interface ShoppingListItem {
  id: string;
  name: string;
  quantity: string;
  source: string;
  checked: boolean;
  status: 'available' | 'out-of-stock';
}

// Added missing ShoppingListCategory interface
export interface ShoppingListCategory {
  name: string;
  items: ShoppingListItem[];
}

export interface IngredientItem {
  id: string;
  name: string;
  imageUrl?: string;
  isLoading?: boolean;
}

export interface Filters {
  dietary: string[];
  cuisine: string[];
  difficulty: string[];
  time: string;
}

export interface ScanResult {
  foodName: string;
  calories: number;
  protein?: number;
  carbs?: number;
  fat?: number;
  description: string;
  origin: string;
  nutrients: { name: string; amount: string }[];
}

export interface Store {
  id: string;
  name: string;
  address: string;
  isOpen: boolean;
  distance?: string;
  type?: string;
  mapUri?: string;
}

export interface Substitution {
    original: string;
    substitutes: { name: string, ratio: string, notes: string }[];
}

export interface SeasonalProduce {
    month: string;
    hemisphere: string;
    fruits: string[];
    vegetables: string[];
}

export interface CulinaryTerm {
    term: string;
    definition: string;
    category: string;
    pronunciation: string;
}

export interface TasteProfile {
    archetype: string; 
    description: string;
    scores: {
        sweet: number;
        salty: number;
        sour: number;
        bitter: number;
        umami: number;
        spicy: number;
    };
}

export type AppScreen = 
  | 'home' 
  | 'discover' 
  | 'shopping' 
  | 'scanner' 
  | 'profile' 
  | 'mealPlan' 
  | 'recipeDetail' 
  | 'cooking' 
  | 'favorites' 
  | 'stores' 
  | 'chat'
  | 'navBarEditor'
  | 'pantry'
  | 'community'
  | 'gamification'
  | 'analytics'
  | 'leaderboard'
  | 'createPost'
  | 'chefProfile'
  | 'labs' 
  | 'unitConverter'
  | 'kitchenTimers'
  | 'substitutions'
  | 'seasonalGuide'
  | 'winePairing'
  | 'mixology'
  | 'partyPlanner'
  | 'coffeeBar'
  | 'cookingSchool'
  | 'dictionary'
  | 'leftoverMagic'
  | 'tasteProfiler'
  | 'fermentationLog'
  | 'dietaryReport'
  | 'familySync'
  | 'mealPrep'
  | 'priceCompare'
  | 'farmersMarket'
  | 'molecularGastronomy'
  | 'foodPhotography'
  | 'teaLounge'
  | 'spiceBlender'
  | 'cheeseBoard'
  | 'sourdoughCalc'
  | 'homeBrew'
  | 'canningGuide'
  | 'foraging'
  | 'butcheryGuide'
  | 'knifeCare'
  | 'applianceTracker'
  | 'gardenTracker'
  | 'halalScanner'
  | 'allergyRadar'
  | 'sommelierChat'
  | 'labelDecoder';

export interface AppAction {
    type: 'NAVIGATE' | 'GENERATE_RECIPE' | 'OPEN_SCANNER' | 'VIEW_RECIPE' | 'START_COOKING' | 'OPEN_CHAT';
    payload?: any;
}

export interface NavItemDef {
    id: AppScreen;
    label: string;
    icon: string;
}

export interface Badge {
    id: string;
    name: string;
    description: string;
    icon: string;
    requirement: string;
    xpReward: number;
    category: string;
}

export interface LeaderboardEntry {
    id: string;
    name: string;
    rank: number;
    xp: number;
    avatar: string;
    badges: number;
    streak: number;
}

export interface SocialPost {
    id: string;
    userId: string;
    userName: string;
    userAvatar: string;
    imageUrl: string;
    caption: string;
    likes: number;
    isLiked?: boolean;
    comments: any[];
    timestamp: string;
    tags: string[];
    recipeId?: string;
}

export interface PantryItem {
    id: string;
    name: string;
    quantity: number;
    unit: string;
    expiryDate: string;
    addedDate: string;
    location: 'Fridge' | 'Freezer' | 'Pantry';
    category: string;
    isStaple: boolean;
}

export interface KitchenTimer {
    id: string;
    label: string;
    duration: number;
    remaining: number;
    isRunning: boolean;
}

export interface PartyPlan {
    guests: number;
    duration: number;
    type: string;
    foodRequirements: string[];
    drinkRequirements: string[];
}